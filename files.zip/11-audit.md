# 11. Audit

## Is agent audit needed?

The internet has substantial audit infrastructure. Application-layer logging is universal: syslog, structured JSON logs, and log aggregation platforms (Splunk, Elastic, Datadog, Loki) collect activity records across every serious system. Security Information and Event Management platforms (Splunk Enterprise Security, IBM QRadar, ArcSight, Microsoft Sentinel) aggregate logs across an organization's systems for security monitoring and compliance reporting. Cloud providers offer built-in audit trails (AWS CloudTrail, GCP Cloud Audit Logs, Azure Activity Log) that record every API call in cloud environments. Compliance frameworks (SOX, HIPAA, PCI-DSS, GDPR) impose specific audit requirements with well-established reporting patterns. Blockchain networks provide immutable transaction ledgers with cryptographic guarantees. Certificate Transparency (RFC 6962) established the transparency-log pattern for TLS certificate issuance. SCITT (RFC 9943, Supply Chain Integrity, Transparency, and Trust) generalizes the transparency-log pattern for supply chain integrity claims. Sigstore provides signing infrastructure for software supply chain artifacts. Verifiable data structures work in COSE and elsewhere provides the cryptographic primitives for tamper-evident records.

Do agents need their own audit primitive on top of all of that? A skeptic could argue no. SCITT was published as an IETF standard in 2025. It supports append-only signed statements with transparency proofs. Combine SCITT for high-consequence records, application logging for routine activity, SIEM for aggregation, and CloudTrail for cloud API access. The combination covers every audit case an application needs. Nothing new required.

The counter-argument runs at two levels.

At the layer level, most existing audit infrastructure is application-layer. Application logs are written by the application itself, in whatever format the application chose, with whatever attribution the application recorded. The application controls the logs. If the application is buggy, the logs may be incomplete. If the application is compromised, the logs may be falsified. If the application is decommissioned, the logs may be lost. SIEM aggregation helps by centralizing logs, but it depends on applications to send logs faithfully and on the SIEM operator to preserve them accurately. Cloud audit trails are more reliable within one cloud provider's environment, but they cover only actions that go through that provider's API and leave gaps where activity crosses provider boundaries or happens at layers below the API.

At the design level, existing audit infrastructure was built for use cases that differ from agent coordination in specific ways. Compliance frameworks are periodic and coarse-grained: quarterly SOX reports, annual HIPAA audits, event-driven GDPR data-access records. SCITT is designed for supply chain claims where each claim is a discrete high-consequence event (a software artifact release, a supplier certification). Certificate Transparency records certificate issuance events, one per certificate. Blockchain records transactions, one per state change on the chain. None of these were designed for per-agent per-action attribution at wire speed with delegation-chain preservation across organizational boundaries.

Agent audit needs specific properties that follow from what agents actually do:

The first is cryptographic attribution to the acting agent. Application logs typically say "process 12345 wrote this line" or "user X performed action Y." Agent audit needs the record to say, cryptographically and verifiably, "agent A (with this specific Agent-ID) performed this specific action at this specific time under this specific delegation from principal P." The attribution is bound to the agent's substrate identity, verifiable by anyone with the agent's public key, and independent of whether the logging infrastructure is trusted.

The second is delegation-chain preservation. When agent A delegates to agent B, and agent B invokes tool C, and tool C makes an external call, the audit record for the external call needs to preserve the whole chain: original principal, agent A, agent B, tool C. Application logs typically record only the immediate caller. SCITT records claims yet lacks native encoding for the causal chain that led to the claim. Substrate audit needs the chain because accountability questions ("who really authorized this?") depend on being able to walk the chain back to the origin.

The third is selective disclosure. Investigation of a specific incident should never require disclosure of unrelated activity by the same agent or principal. If an auditor is investigating whether agent A performed action X on date D, the audit substrate should support proving that specific claim (that action X happened or that no such action occurred) without revealing the whole history of agent A's other actions. Verifiable data structures (Merkle trees, transparency logs) support this through inclusion proofs, but the design has to make selective disclosure a first-class property.

The fourth is per-agent hash chaining. Each agent's sequence of actions should form a tamper-evident hash-chained record, so that inserting, deleting, or reordering actions after the fact leaves cryptographic evidence. This is a common pattern in high-integrity systems (git commits form hash chains; blockchain transactions form hash chains) but has to be built into the substrate audit primitive to work uniformly across all agent activity.

The fifth is cross-boundary verification. Audit evidence should be verifiable across organizational boundaries without requiring cooperation from the entity being audited. If an external auditor investigates an incident that crossed from Company A's agent to Company B's agent to Company C's tool, they should be able to verify what happened at each step from the substrate records rather than depending on each company to voluntarily produce logs in a mutually agreed format.

The notary journal analogy captures the core idea. In many jurisdictions, notaries are legally required to keep a chronological journal of every notarization they perform. The journal contains, for each entry, the notary's identity, the date and time, the type of notarization, the identity of the parties involved, and a signature. The journal is a per-notary, chronological, tamper-evident record that has legal weight independent of any central authority. If a dispute arises about whether a specific document was notarized, the journal provides the evidence. The journal never becomes a central registry; each notary keeps their own. The journal never functions as a summary; it is the primary record. Substrate agent audit has the same shape: per-agent, chronological, tamper-evident, cryptographically self-authenticating, with legal-instrument-grade weight in dispute resolution.

The chain of custody analogy captures the cross-boundary property. In evidence handling, each transfer of physical evidence from one custodian to another is recorded and signed. The record follows the evidence. Any party at any point in the chain can look back and see who has held the evidence, when transfers occurred, and whether any handoff was undocumented. Chain of custody makes evidence usable in court because it preserves the causal chain from collection to presentation. Agent audit needs the same property: each agent's participation in a workflow is recorded in a way that follows the workflow, so anyone examining the workflow later can trace what happened at each step across whatever organizational boundaries the workflow crossed.

The aviation black box analogy captures the completeness dimension. Every commercial aircraft carries a flight data recorder that captures continuous, detailed information about the aircraft's state and the flight crew's actions. When an incident happens, investigators recover the black box and reconstruct exactly what occurred. The black box records without selection; it captures everything, and investigators query the record for the specific information relevant to the incident. The record is tamper-resistant by design because the value of the black box depends on trusting its contents. Agent audit at high-consequence layers needs the same completeness property: enough detail preserved that investigators can reconstruct specific incidents from the record.

The answer is yes, agent audit is needed as a substrate primitive distinct from application-layer logging and from higher-level transparency services like SCITT. The primitive must provide:

- **Wire-level attribution records.** Every substantive action produces an audit record at the substrate layer, cryptographically bound to the acting agent's identity, generated as part of the action rather than reconstructed later from application logs.
- **Delegation-chain preservation.** Every audit record carries the delegation chain that produced the action, so investigators can walk from any action back to the originating principal.
- **Per-agent hash chaining.** Each agent's sequence of actions forms a tamper-evident hash-chained record, so tampering with any historical entry leaves cryptographic evidence.
- **Selective disclosure.** The substrate supports proofs that a specific action occurred (or that no such action occurred) without requiring disclosure of unrelated activity by the same agent.
- **Cross-boundary verifiability.** Audit evidence is verifiable across organizational boundaries without depending on cooperation from the entity being audited.
- **Composition with transparency services.** Where high-consequence records need to be publicly verifiable, the substrate composes cleanly with existing transparency services (SCITT, CT) rather than replacing them.

## Why it is needed

Every other primitive in this document produces records. Identity creates identifiers. Authorization issues credentials. Delegation records contracts. Trust computes scores. Discovery returns candidate lists. Communication carries messages. Session persists state. Semantics defines meaning. Tools handle invocations. Commerce generates transactions. Without a substrate audit primitive, all of these records live in whatever application-layer format their respective applications chose, aggregated in whatever ways their operators decided, preserved for whatever periods their retention policies specified. When an investigation later asks what actually happened, the answer depends on whoever holds the relevant application logs. Substrate audit makes the records themselves substrate primitives, tamper-evident, cross-verifiable, and independent of any specific application layer above them. It is what turns the coordination substrate from a real-time coordination surface into a coordination surface with reliable memory.

## The core use case: investigating what happened when an agent decision went wrong

An organization deploys agents to handle a range of business processes. One morning, the finance team discovers that a payment authorization went to a supplier that should have been blacklisted after a prior compliance incident. The payment cleared. Money moved. Someone made this happen, or something made this happen, and the organization needs to understand exactly what occurred.

Investigation requires answering several questions in sequence:

- Which specific agent submitted the payment authorization?
- Under what delegation was that agent operating?
- What information did the agent see when it made the decision?
- Did the agent check the blacklist, and what response did the blacklist service return?
- Did any delegation upstream authorize the payment despite the blacklist, or did the check fail silently?
- Was the blacklist database current at the time of the check?
- Are there other actions the agent took that raise similar concerns?

Without a substrate audit primitive:

- The investigation begins by requesting logs from the applications involved. Each application produces logs in its own format, at whatever granularity its developers chose, with whatever attribution its architecture supported.
- The payment system's logs show that a payment was authorized, but the attribution is to a service account rather than to a specific agent under a specific delegation.
- Whether the agent framework's logs preserve which specific delegation was active when the decision happened depends on the specific framework implementation. Reconstructing the delegation chain requires piecing together records from multiple systems that use different identifiers.
- The blacklist service's logs show that a check was made, but linking that check to the specific payment decision requires correlation by timestamp and by request parameters, with reliability that varies across implementations.
- If any of the involved systems have rotated logs, been decommissioned, or been affected by a bug that dropped log entries, the corresponding evidence is unavailable.
- Cross-organizational aspects (the supplier is an external party) require the external organization's cooperation to produce their own logs. If the supplier is uncooperative, the internal investigation stalls.
- The whole investigation depends on trusting that every application's logs are complete and unaltered. This trust is warranted for well-run applications but hard to verify from outside the application.

With a substrate audit primitive:

- Every action taken by the agent produced a substrate-level audit record cryptographically bound to the agent's Agent-ID, containing the specific action, the delegation chain that authorized it, the input parameters, the substrate verb invoked, the target agent or tool, and a timestamp.
- The audit records form a per-agent hash chain. The investigator can request the specific record for the payment authorization and verify the record's integrity, without trusting the storage system that holds it.
- The record shows the full delegation chain: originating principal, downstream delegations, current delegation. The investigator traces the chain to see where authority came from at each hop.
- The record shows what the agent invoked immediately before the payment authorization: a QUERY to the blacklist service, the parameters used, the substrate identity of the blacklist service, the response the blacklist service returned, and the timestamp. If the blacklist service returned "blocked" and the payment happened anyway, the investigator sees this immediately.
- If the blacklist service is operated by an external organization, the substrate audit record from the query includes the blacklist service's own signature on the response. The investigator verifies the response cryptographically without needing the external organization's cooperation.
- Selective disclosure lets the investigator prove exactly what happened for this specific payment without exposing unrelated activity by the same agent or principal.

The notary journal parallel maps directly. If a document appears with a notary's stamp, an investigator can request the notary's journal for the date and time in question. The journal shows whether the notarization occurred, who was present, what document was notarized, and the notary's contemporaneous notes. The journal is the primary evidence. Substrate audit records serve the same role for agent action: the primary evidence lives in a per-agent chronological tamper-evident record, and investigation queries the record for the specific event under examination.

The chain of custody parallel captures the multi-hop case. If evidence was collected at a scene, transferred to a lab, analyzed by a specialist, and presented in court, the chain of custody documentation shows each transfer, each custodian, and each period of possession. Any missing link makes the evidence inadmissible. Substrate audit for agent workflows preserves the same chain: which agent held the coordination context, what actions each agent took, what handoffs happened between agents, and what tools each agent invoked. Any missing link is visible in the record.

Human employees rarely need this specific substrate primitive because human action is typically bounded by physical presence, workplace policies, and the natural friction of manual work. When investigation is required, existing tools (interviews, documents, digital forensics on specific systems) are adequate for the scale involved. Software rarely needs this primitive because software components typically run inside single organizations with their own logging and their own compliance frameworks. Neither model handles the case of agent action that crosses organizational boundaries, executes at machine speed, involves multi-hop delegation chains, and requires cross-verifiable evidence for high-consequence disputes. That is the common case at agent scale, and it is what substrate audit addresses.

The application-layer logging and centralized transparency approaches work cleanly when the audit scope is bounded by one application's activity or by one high-consequence event stream. They fragment when the scope needs to span many agents, many delegation chains, many organizations, and many transaction types. Substrate audit makes evidence portable across boundaries, verifiable across parties, and integrable with the other coordination primitives naturally.

Higher-consequence needs (formal legal-instrument-grade audit records for regulatory compliance, cross-jurisdictional audit federation with mutual verification agreements, real-time compliance monitoring across delegation chains, verifiable time-of-action attestations for time-sensitive regulatory reporting, integration with existing transparency services (SCITT, CT) for high-consequence public records, privacy-preserving audit that lets regulated agents demonstrate compliance without disclosing sensitive operational data) build on this base. Without the base, agent activity leaves records only where applications happen to log them and only in formats those applications happen to use. Investigation, compliance, and dispute resolution reduce to trusting whoever holds the relevant logs, and trust is difficult to establish across organizational boundaries at agent scale.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Investigate what a specific agent did at a specific time
- Trace an action back through the delegation chain to its origin
- Verify that a claimed action actually happened
- Prove either that an action occurred or that no record exists for it
- Support audit across organizations
- Monitor compliance in real time across delegation chains
- Prove compliance without exposing unrelated operational data
- Provide hash-chained per-agent action sequences
- Integrate with existing transparency services (SCITT, Certificate Transparency)
- Support long-term audit archival with tamper evidence

---

[← Commerce](10-commerce.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Governance →](12-governance.md)
