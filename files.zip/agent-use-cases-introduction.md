# Foundational Use Cases for Agent Coordination

**Author:** Chris Hood
**Version:** 0.2 draft
**Status:** All twelve primitives (Identity §1, Authorization §2, Delegation §3, Trust §4, Discovery §5, Communication §6, Session §7, Semantics §8, Tools §9, Commerce §10, Audit §11, Governance §12) have been reworked to the "is it needed / why / core use case" format. This is v0.2 of the document. Feedback on any specific primitive is welcome.
**Purpose:** An opinionated framing of the use cases that agent systems must address for a coherent internet of agents to exist. Protocol-agnostic. One architect's view.

---

## Opening

The IETF landscape currently contains over 225 individual submissions targeting AI agent standards. Most propose new protocols. Most tie those protocols to specific enterprise objectives, product lines, or organizational agendas. Few step back to ask what problems agent systems actually need solved, independent of which particular protocol solves them.

Beneath the volume of proposals sits a familiar problem from product development: solutions arriving before the design is clear. Every protocol author is building. Few authors have paused to establish what a coherent internet of agents actually needs, or whether the primitives everyone assumes are required are actually required at all. Cryptographic delegation formats, transparency log integrations, and semantic method vocabularies all show up in drafts before the underlying question has been examined: is this primitive needed, and if so, why?

This document takes the earlier step. It examines twelve primitives that recur across current proposals and, for each, asks two questions. First, is the primitive needed? The answer varies by primitive and requires argument rather than assertion. Existing internet identifiers (IP addresses, domain names, email addresses) already serve many purposes; a new agent primitive requires justification rather than assumption. Second, if the primitive is needed, what is the simplest concrete use case that demonstrates the need? Use cases here are described at the primitive layer rather than the protocol layer, and are kept deliberately simple. Cryptographic properties, transparency guarantees, and revocation semantics belong to solutions; this document stays with the problems those solutions address.

The document is opinionated. It reflects one architect's judgment about which primitives matter, what the honest skeptical case is for each, and which use case best illustrates the need. Consensus documents converge on the least controversial framing, which is often the least useful. Readers will disagree with specific selections. Disagreement about which use cases matter is a more productive conversation than disagreement about which protocol wins.

The document is also protocol-agnostic. Multiple protocols may address the same use case. A specific protocol may address use cases across multiple primitives. Neither shape is inherently correct. The framing exists to make comparison tractable and to keep the conversation grounded in problems rather than solutions.

## Scope

Each primitive is presented in two forms. The core use case is one concrete scenario, chosen because it demonstrates the need cleanly and can be visualized without technical background. Additional use cases follow as an illustrative list in simpler language, covering the range of scenarios the primitive addresses. Neither is exhaustive. Both lists are open to contribution: readers whose favored use case is missing are welcome to propose additions. The goal is to validate that each primitive is required and to sketch its scope. Complete enumeration of every possible scenario belongs to solution proposals rather than to this framing.

## The Twelve Primitives

The primitives, in the order they appear:

1. **Identity**: who is this?
2. **Authorization**: what may this actor do here, now?
3. **Delegation**: who authorized whom to do what on whose behalf?
4. **Trust**: how much should this claim be believed?
5. **Discovery**: how does one agent find another?
6. **Communication**: how do agents exchange messages reliably?
7. **Session**: how is state maintained across time?
8. **Semantics**: what does the actor mean?
9. **Tools**: how does an agent invoke a capability outside the agent scope?
10. **Commerce**: how do agents transact with money?
11. **Audit**: what happened, and can it be verified after the fact?
12. **Governance**: what rules govern the agent, and who enforces them?

Each primitive is examined in the main document with a common three-part structure. First, is the primitive needed? This section presents the honest skeptical case, the counter-argument, and the answer. Second, if the answer is yes, why is the primitive needed at the coordination-surface level? Third, the core use case: a single concrete scenario that demonstrates the primitive's necessity, kept simple enough that anyone can visualize it without technical background. Solutions are deferred; the document focuses on the problems that require solving rather than the solutions themselves.

## Summary Table

| # | Primitive | Core reason (one sentence) | Core use case (one sentence) |
|---|-----------|----------------------------|------------------------------|
| 1 | Identity | Every internet participant category has an identity; agents need one that is verifiable, portable, and durable across infrastructure change. | Managing an organization's agent fleet at scale, the way SKUs manage inventory and employee numbers manage workforces. |
| 2 | Authorization | OAuth and IAM handle machine-to-machine credentials well but lose the causal chain when actions cross organizational boundaries. | Booking a trip across three organizations while preserving a paper trail from the principal to every downstream commitment. |
| 3 | Delegation | The word "agent" itself embeds delegation; the framework establishing authority is architecturally distinct from the runtime check on any specific action. | An executive delegates authority for two weeks of purchases, meetings, and reviews before going on vacation. |
| 4 | Trust | PKI verifies identity; reputation systems evaluate services; neither provides substrate-level graduated trust portable across contexts. | Choosing among twenty tax-preparation agents claiming the same capability, when some are inexperienced and some are fraudulent. |
| 5 | Discovery | DNS is a publishing model that returns names to addresses; agent-native discovery is scanning intrinsic metadata by capability. | Finding a legal-Japanese-to-English translator with the right price, trust tier, and delivery timeline. |
| 6 | Communication | HTTP is a content substrate designed for browser-to-server delivery; agents need a coordination substrate with intent, attribution, and multi-modal streams. | A bidirectional booking conversation between an assistant agent and a travel-service agent. |
| 7 | Session | HTTP cookies and TLS resumption handle minute-to-hour web sessions; agent coordination often spans days or weeks with pauses and process restarts. | A week-long market research task with human review at key points. |
| 8 | Semantics | Schema languages describe structure; nothing at the wire provides shared coordination-verb meaning between arbitrary agents. | Two agents from different companies complete a purchase without prior integration. |
| 9 | Tools | MCP works for tool invocation, but the tool-versus-agent boundary is arbitrary; separate stacks fragment identity, discovery, and authorization. | An agent composes a calendar tool, an email tool, and another organization's agent in one workflow with a single delegation chain and one audit trail. |
| 10 | Commerce | Existing payment infrastructure was designed for human-initiated transactions; agent commerce needs discovery-time pricing, delegated purchase authority, and machine-scale economics. | An assistant agent purchases office supplies within a delegated monthly budget. |
| 11 | Audit | SCITT and Certificate Transparency are transparency services for periodic high-consequence claims; agent audit needs per-agent per-action attribution at wire speed with delegation-chain preservation. | Investigating a payment that went to a blacklisted supplier, tracing back through the delegation chain. |
| 12 | Governance | Contract law scales through human deliberation; agents transact faster than human review; substrate governance binds agent action to accountable natural or legal persons through legal-instrument-grade evidence. | A commercial dispute where a court must determine whether an agent had authority to bind its principal to the contested terms. |

## How the Primitives Compose

The twelve primitives carry different levels of load and stand in a natural dependency structure. Reading the sections in order (1 through 12) reflects that structure. The relationships are worth naming explicitly so the document reads as a coherent frame rather than as twelve independent essays.

**Identity anchors everything.** Every other primitive references the acting agent's identity. Without identity, no other primitive has a subject.

**Delegation frames authority; Authorization checks specific actions.** Delegation is the framework (established at some earlier time); Authorization is the runtime check on any specific action. Both compose with Identity: authority always attaches to a specific identity, and every runtime check references a specific delegation chain.

**Discovery feeds Trust and Authorization.** Discovery returns candidates. Trust filters them. Authorization checks the specific action. The three compose into every "which agent should perform this action" decision, and all three depend on Identity underneath.

**Communication, Session, and Semantics carry the action.** Communication moves messages between endpoints. Session persists coordination state across time. Semantics defines what messages mean. The three compose into every multi-message coordination and inherit Identity and delegation context from earlier primitives.

**Tools extends the coordination surface.** Tools are substrate participants that use the same Identity, Discovery, Semantics, and Communication primitives as agents, with specific constraints (typically stateless, integrity-critical, capability-first-discoverable). The primitive is uniform addressing rather than a separate protocol stack.

**Commerce composes the earlier primitives around money.** Discovery finds merchants. Trust filters them. Delegation frames purchase authority. Communication carries the transaction. Semantics defines the verbs. Commerce is what the earlier primitives look like when money changes hands, with specific properties (discovery-time pricing, machine-scale economics, substrate-level receipts) that human-oriented payment infrastructure was never designed to serve.

**Audit records everything.** Every primitive produces records; Audit is the substrate primitive that makes those records tamper-evident, cross-verifiable, and usable across organizational boundaries. Audit closes the loop between action and later investigation.

**Governance closes the loop with legal-instrument-grade evidence.** Audit produces attribution: cryptographic evidence that a specific agent performed a specific action under a specific delegation. Governance binds attribution to accountable persons that legal systems can act on. Without Governance, cryptographic attribution stops at the substrate boundary and legal action cannot proceed.

The composition matters for how solution proposals get evaluated. Most proposals address one or two primitives at a time. Reading a proposal against the composition frame makes it easier to see which primitives it depends on, which it provides, and which remain unaddressed.

---

## How to Read and Use This Document

The primitives and analyses in the main document are one architect's view. They reflect the author's judgment about which primitives matter for a coordination substrate that agent systems require at scale. Readers will disagree with specific selections. That is expected.

This document is offered as a common frame for evaluating agent standards proposals. When reading a new draft, working group scope, or BoF charter, one useful test is: which of these primitives does the proposal address? What use case within the primitive does it solve? Does the proposal justify the primitive it addresses, or is the primitive assumed? A proposal that names its primitive, names the use case, and grounds both in a real deployment need is easier to evaluate than one that describes solution mechanics without stating what problem the mechanics address.

The document is deliberately protocol-agnostic. Multiple protocols may address the same use case. A specific protocol may address use cases across multiple primitives; another may address a single use case in depth. Neither shape is inherently correct. The framing exists to make comparison tractable.

The document is deliberately opinionated. Consensus documents converge on the least controversial framing, which is often the least useful. This document takes positions the author is prepared to defend and welcomes correction where the positions turn out to be wrong.

## Feedback

Corrections, disagreements, and additions are welcome. Commentary is best framed as a specific claim about a specific primitive or use case, so that the framing can be refined iteratively rather than argued in aggregate.
