# 5. Discovery

## Is agent discovery needed?

The internet has one dominant discovery mechanism: the Domain Name System. DNS is decades old, universally deployed, and works. Every service on the internet today is discoverable through DNS. A client that knows a domain resolves it to an address and connects. Extensions have accumulated over time: SVCB and HTTPS records for service binding, TXT records for arbitrary metadata, DNSSEC for integrity, DANE for trust anchoring, TLSA records for certificate binding, well-known URI conventions for structured metadata under a domain. Agents are software running on servers; servers live under domains; DNS resolves domains. If agents need to be discovered, extend DNS.

Do agents need their own discovery primitive on top of all of that? A skeptic could argue no. Point DNS records at the agent's endpoint. Publish agent metadata under a well-known path. Use DNSSEC to prove integrity, DANE to anchor trust. This is a well-understood pattern. Nothing new required.

The counter-argument turns on what DNS was designed to answer. DNS answers one specific question: "given a name, find an address." Agent deployments frequently need to answer questions DNS was never designed to serve:

- **Capability-based lookup.** "Given a task I need done, find agents that can do it." The requester has no name to look up. They have a need.
- **Attribute-based filtering.** "Find agents in this industry, in this region, at this trust tier, within this price range." The requester has constraints rather than a name.
- **Identity-first resolution.** "Given a stable Agent-ID that survives infrastructure changes, find the agent's current endpoint." The requester has an identity; DNS resolves names to addresses, but when the agent's identity takes any form other than a domain name, DNS has no place to start.

These are three different questions. DNS handles the first (given a name) well. It handles the next two awkwardly, through extensions and conventions that were bolted on rather than designed in. At small scale, the awkwardness is manageable. At scale, with millions of agents crossing organizational boundaries and needing to be found by capability rather than by name, the paradigm strains.

There is a deeper paradigm assumption most discovery discussions inherit without examining. DNS-first discovery is a publishing model. A domain owner must actively configure records for the agents they want to expose. Nothing is discoverable until someone publishes it. Discovery is a lookup against what someone published. If a domain owner never publishes a record for a given agent, the agent is invisible to DNS-based discovery, regardless of the agent's actual capabilities. And DNS-first discovery treats the domain (or the IP address underneath it) as the primary addressable entity. The agent is a service running under a domain, and the domain is what participants discover, verify, and connect to. When the agent moves between domains (moves companies, changes hosting, gets deployed to a new region), its identity dissociates from its history. Every downstream primitive (identity, authorization, delegation, trust, attribution) has to be reconstructed under the new domain.

Agent-native discovery inverts both assumptions. The Agent-ID is the primary addressable entity. Endpoints and domains are secondary lookup results: they are where the agent currently is, rather than what the agent is. When the agent moves between hosting environments, the Agent-ID persists, and the discovery lookup returns the new endpoint. Identity survives infrastructure change. Every downstream primitive continues to attach to a stable reference. And agents carry metadata about themselves (capabilities, attributes, availability, credentials, trust indicators) as intrinsic properties of the Agent-ID. Discovery becomes scanning and filtering across intrinsic metadata rather than looking up what was published. Adding an agent to the ecosystem makes it discoverable by its properties automatically, without a separate publishing step.

Four specific problems with DNS-first discovery become visible once these paradigm assumptions are named:

1. **No starting-domain problem.** DNS requires a domain to begin. A client that has no domain (a client wanting to find translation agents worldwide, or a client responding to an intent from an anonymous principal) has no place to start. DNS answers the domain-anchored case cleanly and has no answer for the domainless case.

2. **Central-registry paradox.** Cross-organization capability search requires an index of agents by capability. If the index is centralized, it is a single point of control and failure. If the index is federated, no single query has global reach. Existing DNS-based proposals wrestle with this and the wrestling never fully resolves, because DNS was designed around domain hierarchies rather than capability partitions.

3. **Domain-bound identity.** An agent identified by a domain name inherits the domain's history: certificate authorities, DNSSEC anchoring, historical records. Move the agent to a different domain and its identity is a new identity as far as the receiver can tell. Identity should survive infrastructure change; DNS-first identity fails that test.

4. **Static endpoint assumption.** DNS records point to addresses. Agents may move between addresses frequently, may run across multiple addresses simultaneously, may operate through relays and rendezvous points without a stable directly reachable endpoint at all. DNS handles static endpoints natively; dynamic and relay-mediated endpoints require workarounds.

At small scale, DNS-based discovery is sufficient. An organization publishing agents under its own domain, expected to be discovered by clients that know the domain, gets everything it needs from DNS extensions. At scale, with agents crossing organizational boundaries, discoverable by capability rather than by name, and requiring identity that survives infrastructure change, DNS-based discovery reaches its limits.

Four analogies from familiar systems make the design gap concrete. Each one shows a different aspect of what agent discovery needs.

**Yellow Pages.** Before the Yellow Pages, finding a plumber in an unfamiliar city required knowing a plumber by name, or driving around looking for signs. The White Pages offered no help: they were organized by name, and a client with no name had no way in. The Yellow Pages introduced capability-based lookup: plumbers listed themselves under a category, and any client with the need "I need a plumber" could find candidates without knowing any specific plumber's name. The Yellow Pages never replaced the White Pages; both existed side by side because they served different discovery patterns. DNS is the White Pages of the internet. What agents need at scale is the Yellow Pages equivalent alongside it: capability-based lookup that complements name-based lookup rather than replacing it.

**Filesystems.** When a file is added to a filesystem, the filesystem indexes it automatically. Search operations work across intrinsic file metadata: name, type, size, date, tags, extension, and content on filesystems that support content indexing. The file carries the metadata that makes it findable. The user never separately publishes the file to make it discoverable; the user adds it, and the filesystem discovers it. Compare this with a newspaper classified ad: an item is unfindable until the owner publishes an ad describing it. If the owner never publishes, the item stays invisible to buyers, even if it exists and would match a buyer's criteria perfectly. DNS follows the classified-ad model. Agent discovery can follow the filesystem model.

**Music libraries.** When a song is added to a music library, the library scans its metadata tags (artist, album, genre, year, duration, custom labels) and organizes the song into playlists, filters, and search views automatically. The song carries the descriptors that make it discoverable. The user never separately registers the song's genre with a directory service; the genre is intrinsic to the file. Music libraries work because the metadata travels with the media, so adding one song makes it findable through every attribute the metadata expresses. Agent-native discovery can work the same way: metadata about an agent travels with the agent, and adding an agent to the ecosystem makes it findable through every attribute the metadata expresses.

**Email spam filtering.** Much of the email arriving in any given inbox is illegitimate. Spam arrives in inboxes constantly, and on any given day the volume of spam may exceed the volume of legitimate messages. Yet users successfully sort through email because a trust score, in the form of a spam filter, sorts most of the spam automatically. Trusted senders bypass filters. Unknown senders receive intermediate scores. Known bad actors get blocked outright. The receiver only sees messages worth considering. Agent discovery with a substrate trust primitive works the same way: the substrate returns candidates, the trust score filters most of the spam, and the individual sees only candidates worth considering. Without a substrate trust primitive at discovery time, every application must build its own spam filter for agents, and every user must inspect every candidate individually.

The answer is yes, agent discovery is needed as a substrate primitive distinct from DNS. It must support:

- Name-based lookup (given an Agent-ID, find the current endpoint)
- Capability-based lookup (given a task need, find agents that can perform it)
- Attribute-based filtering (industry, region, trust tier, price range, availability)
- Identity-first architecture (Agent-ID as primary, endpoint as secondary, identity persists across infrastructure change)
- Intrinsic metadata (agents carry their descriptors with them, so discovery scans and filters across intrinsic properties rather than against a separately published registry)

## Why it is needed

Agent discovery gives principals a way to find agents that fit their needs, whether the principal already knows the specific agent they want or has only a task and criteria. Traditional DNS handles name-based lookup well. It handles capability-based lookup awkwardly, attribute-based filtering worse, and identity-first resolution barely at all, and it operates entirely within a publishing model that requires domain owners to configure each exposure. Every other primitive in this document depends on discovery working: authorization requires knowing the target, delegation specifies who is being delegated to, trust evaluates candidates, communication needs an endpoint. Discovery is the gateway to every coordination act that follows. Without a substrate primitive that supports lookup across all five discovery patterns, coordination at scale reduces to what DNS can express, and DNS was designed for a different problem.

## The core use case: finding capable agents in an open market

An individual needs help with a specific task, such as translating a legal document from Japanese to English with attention to jurisdiction-specific terminology. They have a clear need with clear criteria: language pair, subject specialization, price range, delivery timeline. They have no specific translation agent in mind. They have no starting domain to query. They have never used a translation agent before.

Without agent discovery at the substrate:

- The individual searches the general web for translation services, sifting through advertisements, seo-optimized pages, and unrelated results.
- Each translation service is discovered independently through its own website. Comparing across services requires visiting each one in turn.
- Trust signals differ across sites. One site displays reviews from one platform; another displays certifications from a different body; a third has neither.
- Cross-organization filtering (agents that specialize in legal Japanese-English translation, priced under a specific ceiling, delivering within a specific timeline) requires reading through many sites manually and holding the criteria in memory.
- The individual has no way to filter by trust tier or by verified capability at query time. Filtering happens after the fact, once the individual has already committed attention to specific candidates.

With agent discovery at the substrate:

- The individual queries the substrate with the criteria directly: "capability: legal-translation, language-pair: ja-en, trust tier: verified or better, price ceiling: $X per page, delivery: within Y days."
- The substrate returns a candidate list of agents that satisfy the constraints. The list may include agents from many different organizations, each identified by a stable Agent-ID rather than by domain.
- Each candidate carries the metadata needed to compare: capability description, verified attributes, current trust score, pricing, availability. The metadata travels with the agent; the substrate scans and filters across it.
- The individual filters, compares, and selects from the candidates without visiting individual websites first. The final selection is made against a normalized view of the market, rather than against whichever candidates showed up in a search-engine ranking.
- The trust score filters most of the low-quality and adversarial candidates before the individual sees the results, in the same way an email spam filter sorts inboxes.
- If a selected agent later moves organizations, the Agent-ID persists. The individual's prior interactions with the agent remain attached to the identity that survived the move.

The restaurant-evaluation pattern is a familiar version of the same trade-off. Given two nearby restaurants, one averaging 3 stars and one averaging 5 stars, most people pick the 5-star option. But volume matters: a restaurant with 500 reviews averaging 3 stars tells a different story than a restaurant with 10 reviews averaging 5 stars. The first has broad evidence at a modest average; the second has thin evidence at a high average. Price factors in as well: a 4-star restaurant at $50 per person compares differently against a 5-star restaurant at $20 per person than either compares against the other in isolation. Humans make these multi-dimensional evaluations regularly and instinctively. Agent discovery needs to support the same evaluation model at wire speed. When Agent A offers a capability at a 5-star trust tier and Agent B offers the same capability for free at a 2-star trust tier, the requester should see capability, trust, price, and evidence volume side by side rather than being forced to select on any single axis. Discovery that returns candidates with intrinsic metadata across multiple dimensions is what makes this evaluation possible.

The corporate analog is B2B procurement. When a company needs a new vendor for a specific service, the procurement team begins without a specific vendor name in mind. They begin with a capability need, a set of constraints (budget, region, compliance regime, certifications), and a criteria list. They query business directories, industry associations, procurement databases, and request-for-proposal networks. Each of these is a form of capability-based discovery: given a need with attributes, return qualified providers. The procurement team then evaluates the candidates against additional criteria (trust, history, references) before selecting a vendor. Agent discovery needs the same properties at wire speed: capability and attribute-based lookup that returns qualified candidates, each carrying enough metadata to support comparison, before any specific relationship is established.

Human employees rarely need agent-scale discovery because they operate within a fixed set of known peers inside a bounded organization. When they need to find someone with a specific skill, they ask a manager or check an internal directory. Software rarely needs agent-scale discovery because software is typically installed with its dependencies pre-configured and its endpoints hardcoded. Neither model handles the case of an entity needing to find capable counterparts across organizational boundaries with no prior relationship. That is the common case at agent scale, and it is what discovery addresses.

The DNS-first approach works cleanly when the requester knows the domain and the domain owner has published a record for the specific agent. It works less cleanly when the requester has only a capability need, works less cleanly still when the agent has no fixed domain or has changed domains, and fails entirely when the agent has metadata that the domain owner never published to DNS. Agent discovery inverts the primary entity and the discovery model together: Agent-ID becomes the addressable substrate identity, and metadata travels with the agent rather than being separately published. This inversion is what enables capability-based lookup at scale, identity persistence across infrastructure changes, cross-organization search without a central registry, and adversarial filtering at query time rather than after the fact.

Higher-consequence needs (adversarial discovery under spam and impersonation pressure, cross-domain federation of discovery substrates, discovery of agents behind relays and rendezvous points, freshness guarantees on capability advertisements, coordination between substrate discovery and application-layer capability descriptions) build on this base. Without the base, agent coordination at scale reduces to whatever DNS-based patterns can express, and the patterns fall short in exactly the ways that matter most as agent populations grow.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Look up a specific agent by Agent-ID (name-based lookup)
- Look up an agent by domain (domain-based lookup)
- Find agents that can solve a specific type of problem (capability-based lookup)
- Find agents matching multiple attributes (region, language, industry)
- Find tools with specific capabilities
- Find agents that can invoke specific tools
- Filter results by trust tier
- Filter results by price ceiling
- Filter results by availability window
- Discover agents that operate through relays (no fixed endpoint)
- Discover agents carrying specific certifications
- Refresh discovery results as metadata changes

---

[← Trust](04-trust.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Communication →](06-communication.md)
