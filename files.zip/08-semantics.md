# 8. Semantics

## Is agent semantics needed?

The internet has substantial semantic infrastructure. OpenAPI describes REST API contracts. JSON Schema validates structured data. Protocol Buffers define typed messages. gRPC provides schema-based RPC. GraphQL types queries and responses. The semantic web produced RDF, OWL, and SPARQL for shared meaning through formal ontologies. Modern MCP tool descriptions and A2A agent cards provide machine-readable definitions of what agents can do. Every serious API has a schema; every serious agent framework has tool descriptions; every serious data pipeline validates types. And underneath all of that, natural language processing has become powerful enough that agents can exchange plain text messages and interpret them with large language models on either side.

Do agents need their own semantics primitive on top of all of that? A skeptic could argue no. Combine OpenAPI for contract definition, JSON Schema for validation, MCP tool descriptions for agent capabilities, and LLM interpretation for anything unstructured. This combination covers the semantic problem. Any two agents can either agree on a contract in advance or figure it out through language interpretation at runtime. Nothing new required.

The counter-argument turns on the distinction between structure and meaning. Schema languages describe structure. They specify field names, types, and shapes. They say nothing about what the fields mean or what the message is trying to accomplish. An OpenAPI specification tells you that a POST to /orders takes a JSON body with a customer_id string and an items array; it leaves unspecified what "order" means at the coordination level, what the seller is agreeing to by processing it, or how the same concept relates to a POST to /purchases on another server that takes different field names for essentially the same operation.

Every application defines its own vocabulary. One shopping platform calls the operation "buy." Another calls it "purchase." A third calls it "order." A fourth calls it "reserve" and treats the actual purchase as a separate operation. Each vocabulary is internally coherent but different from every other. Agents from different platforms must either translate between vocabularies or negotiate a shared vocabulary before any coordination can happen. This is per-pair integration work that scales quadratically with the number of platforms.

Natural language processing can bridge the gap, and it currently does bridge the gap in many agent stacks. Agent A sends "please buy 10 units of product X for $50 each." Agent B interprets that natural language, executes the operation, and responds in natural language. The LLM handles the semantic translation on both sides. This works, but it comes at real cost: expensive inference on every message, non-deterministic interpretation that occasionally produces the wrong action, difficulty auditing what actually happened, and no cryptographic binding between the request and the executed action. Language interpretation at every step is a workaround for the absence of a shared substrate vocabulary rather than a design.

The semantic web attempted to solve this at the ontology level. RDF, OWL, and SPARQL let anyone publish a shared ontology and let anyone else adopt it. The vision was that shared meaning would emerge from a distributed graph of interconnected definitions. The vision never became widely deployed reality. The reasons are worth naming. Ontology adoption requires community-scale coordination that rarely materialized. Ontology matching between similar-but-different vocabularies became a research problem in itself. Applications preferred bespoke schemas they controlled over shared ontologies they had to agree on. Twenty-five years after the vision was articulated, the web is still an internet of bespoke schemas rather than an internet of shared meaning.

The counter-argument is that agents need a smaller, more focused version of what the semantic web tried to build: a shared vocabulary of coordination verbs at the substrate level, closed enough to be practical, open enough to extend for domain specialization. Rather than a general-purpose ontology that describes all possible meaning, agents need a small set of coordination primitives that any agent can rely on any other agent to understand.

HTTP itself provides the closest analog. HTTP has methods: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS. That is essentially the entire semantic vocabulary of HTTP, and everyone who touches HTTP knows what each method means without prior negotiation. A GET is a retrieval. A POST is a submission. A DELETE is a removal. HTTP defined these once, at the substrate, and every HTTP client and server implements them with consistent semantics. The methods carry meaning at the wire. Any two HTTP endpoints can coordinate at the method level without discussing what GET means. HTTP's semantic vocabulary is narrow (nine methods) and universal (every HTTP participant understands them). That combination makes coordination possible at scale.

Agent coordination needs the same shape at a different layer. HTTP methods describe content operations (retrieve, submit, remove content). Agent semantic verbs need to describe coordination operations: query for information, discover capabilities, delegate authority, execute action, collaborate on task, purchase a good, confirm a commitment. The exact vocabulary is a design choice, but the property matters more than the specific words. A small closed set of coordination verbs, universally understood, embedded in messages at the wire, enables coordination between any two agents without prior negotiation.

Traffic signs make the point at a more concrete level. A stop sign means stop, everywhere in the world. A one-way arrow means one-way traffic. A pedestrian crossing sign means pedestrians may cross here. Drivers from any country recognize these signs and act on them without translation. The traffic sign vocabulary is small, visual, and universal. It works because every road authority uses the same signs with the same meanings. Coordination among millions of drivers happens through this shared vocabulary. If every country defined its own signs, international driving would require a lookup table.

Aviation English extends the point to safety-critical coordination. Air traffic control worldwide uses a standardized vocabulary of terms and phrases. "Cleared for takeoff" means one thing precisely. "Roger" means received and understood. "Wilco" means will comply. "Mayday" means life-threatening emergency. Pilots and controllers from different countries, different airlines, and different backgrounds coordinate through this vocabulary in real time. The vocabulary is small, closed, and unambiguous. Aviation would be impossible at global scale without it. Air traffic coordination requires the same property agent coordination requires: shared meaning that requires no prior negotiation between specific participants.

Musical notation extends further into the abstract. A note on a staff means the same pitch and duration to any trained musician. A time signature means the same rhythmic structure. A dynamic marking means the same volume. Musicians from any tradition, on any instrument, can read the same score and coordinate a performance. Musical notation is a shared vocabulary that carries meaning without prior negotiation between the composer and the performer. Agent semantics is the coordination equivalent.

The answer is yes, agent semantics is needed as a substrate primitive distinct from application-layer schemas and from language interpretation. The primitive must provide:

- **A closed vocabulary of coordination verbs.** Small enough to be memorable and universally implementable. Focused coordination primitives rather than general-purpose ontology.
- **Universal shared meaning.** Every verb means the same thing to every participant. No per-pair negotiation. No context-dependent interpretation.
- **Wire-level embedding.** Verbs appear as first-class message primitives, so receivers dispatch and audit on the verb without parsing prose or reverse-engineering an application-specific schema.
- **Typed parameters.** Each verb carries typed parameters with defined shapes, so the wire message conveys both what the sender wants and what data supports it.
- **Extensibility for domain specialization.** Domains that need additional vocabulary (medical, legal, financial, industrial) can add specialized verbs without breaking base-vocabulary interoperability.
- **Deterministic interpretation.** Given a verb and its parameters, the receiver's understanding of the message is exact. No language interpretation ambiguity between sender and receiver.

## Why it is needed

Communication carries messages between agents. Semantics defines what those messages mean. The two primitives are complementary: an agent can send a message with the right delivery properties (attribution, session context, real-time flow) and still be misunderstood if the receiver cannot interpret the intent. Semantics is what makes the message actionable. Without shared semantics at the substrate, every agent-to-agent interaction requires either prior contract negotiation (custom API, custom schema, custom vocabulary) or runtime language interpretation (LLM parsing on both sides). Both approaches work at small scale and both fail at agent-population scale. Prior negotiation scales quadratically with the number of participants; language interpretation is expensive, non-deterministic, and hard to audit. A substrate semantics primitive makes coordination between any two agents possible without either burden.

## The core use case: two agents from different organizations completing a purchase without prior integration

An assistant agent at Company A needs to purchase office supplies on behalf of its principal. It discovers a supplier agent operated by Company B through the discovery primitive. The two agents have never interacted before. Neither company has integrated with the other. The assistant agent has authority to complete the purchase within a budget.

Without a substrate semantics primitive:

- Before any coordination can begin, the assistant agent must discover Company B's API contract. It reads through the supplier's OpenAPI specification, learns what operations exist, learns what field names Company B uses, learns what response formats to expect, and adapts its own code to match.
- If Company B uses different vocabulary from Company A (Company B calls it "reserve then commit"; Company A expects "purchase"), the assistant must translate between vocabularies at the application layer.
- Alternatively, the two agents fall back to natural language. The assistant sends "I would like to purchase 10 units of item ABC-123 at your listed price." The supplier's LLM interprets, generates a proposed order, sends it back in natural language. The assistant's LLM interprets the response, extracts the price and terms, and formulates a natural-language confirmation. Each interpretation step costs LLM inference and introduces potential misinterpretation.
- The interpreted actions have no cryptographic binding to the intent. If the supplier later delivers the wrong item, there is no substrate-level record of what was actually requested, only two separately generated natural-language messages and whatever application-layer parsing they produced.
- Company A must build this integration for every supplier it wants to work with. Company B must publish and maintain contracts for every buyer. The integration burden scales with the product of buyers and sellers.

With a substrate semantics primitive:

- The assistant agent sends a QUERY verb with typed parameters (item description, quantity, price constraints). The supplier's response uses a shared PROPOSE verb with typed parameters (offered items, prices, terms).
- Both agents understand what QUERY and PROPOSE mean because the substrate defines them, rather than because the two companies negotiated. Neither had to publish or consume a bespoke contract.
- The assistant sends PURCHASE with the specific proposal it accepts. The supplier confirms with COMMITMENT. Both verbs have precise substrate-defined semantics.
- Every verb is bound cryptographically to the sending agent, and the resulting transaction record contains verifiable substrate-level evidence of what was requested and what was agreed. Dispute resolution can rely on this evidence rather than reconstructing intent from natural language.
- Any assistant agent can coordinate with any supplier agent using the same substrate verbs. The integration burden collapses from N times M (buyers times sellers) to N plus M (each side implements the substrate vocabulary once).

The HTTP methods parallel is direct. Any HTTP client can GET any HTTP resource because both sides understand GET without prior negotiation. If HTTP had never defined GET, POST, PUT, and DELETE at the substrate, every web server would define its own retrieval and submission conventions, and every client would need per-server integration. The web would be a collection of bespoke protocols rather than a shared substrate. HTTP methods made the web work. Agent semantic verbs can make agent coordination work at the same scale.

The traffic sign parallel captures the everyday version. When you drive into a town you have never visited, you understand the traffic signs immediately. Stop means stop. Yield means yield. Speed limit means speed limit. You never need to consult a local translation guide or negotiate with the traffic authority. The shared vocabulary makes driving possible in unfamiliar places. Agent coordination needs the same property: an agent should be able to coordinate with agents it has never met, using shared vocabulary that requires no per-pair negotiation.

Human coordination rarely needs this exact primitive because humans already share natural language, which carries enormous accumulated shared meaning at the cost of ambiguity and interpretation overhead that humans handle gracefully. Software rarely needs this primitive because software components are typically integrated within a single system where the developer defines the vocabulary once for all components. Neither model handles the case of software entities that need to coordinate across organizational boundaries, at wire speed, with cryptographic binding between intent and action, and without either prior integration work or expensive language interpretation. That is the common case at agent scale, and it is what semantics addresses.

The application-layer schema approach and the LLM interpretation approach both work at small scale. The application-layer approach breaks down when the number of participating platforms grows, because every pair needs its own integration. The LLM interpretation approach breaks down when the coordination volume grows, because every message costs inference and introduces interpretation risk. A substrate semantics primitive makes coordination scale linearly rather than quadratically, and makes intent verifiable rather than interpretive.

Higher-consequence needs (domain-specific vocabulary extensions with defined semantics, formal verification of verb behavior in receivers, vocabulary versioning and backward compatibility, semantic overlays that translate between the substrate vocabulary and legacy domain vocabularies, cross-cultural semantic considerations where verb semantics may need to reflect regulatory or cultural context) build on this base. Without the base, agent coordination reduces to either bespoke integrations (application layer) or language interpretation (LLM at every message), and neither scales to the coordination volume agent populations will produce.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Coordinate with an agent you have never worked with before
- Verify that a specific action was requested with specific meaning
- Extend the vocabulary for a specific domain (medical, legal, financial)
- Handle versioning of shared vocabulary with backward compatibility
- Translate between the substrate vocabulary and a legacy vocabulary
- Confirm the receiver understood the request the same way the sender meant
- Handle multi-step workflows (query, propose, negotiate, commit)
- Support explicit refusal (an agent declines a request)
- Support conditional acceptance (accept only if X)
- Coordinate across industries using a shared base vocabulary

---

[← Session](07-session.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Tools →](09-tools.md)
