# 1. Identity

## Is agent identity needed?

Every existing category of internet participant has some form of identity. Servers have IP addresses. People have email addresses. Companies have domain names. Phone lines have phone numbers. Employees have employee numbers. In each case, the identity serves a real purpose that the deployment could hardly function without.

Do agents need their own identity primitive? A skeptic could argue that agents are software running on servers, and the server already has an IP address. When agent A calls agent B, the call resolves to an IP, just like every other network call today. Introducing an agent identity layer looks at first like anthropomorphizing software. A background process on a server has no identity of its own; why should an agent process?

The counter-argument is inventory at scale. An organization running one agent can identify it by the server that hosts it. An organization running one thousand agents cannot. A single server may host dozens of agents. A single agent may span multiple servers, or move between servers as infrastructure changes. Without a stable identifier tied to the agent itself rather than to the substrate hosting it, the organization loses the ability to answer basic operational questions: which agents exist, which agent took this action, who deployed it, is it still active, has it been retired.

A related and increasingly common frame is agents as employees. Organizations are deploying agents in roles that used to be performed by humans: analyst, customer service representative, procurement clerk, security monitor. Every human in those roles carries an employee identifier that attaches to HR systems, payroll, access control, badge readers, and performance tracking. Agents performing the same functions inherit the same operational requirements. If an agent behaves organizationally as an employee, the organization needs an identifier for that agent for the same reasons it needs identifiers for its human employees: onboarding, role assignment, action attribution, incident investigation, and eventual retirement.

At small scale, agent identity is optional. At scale, it becomes essential. Every serious agent deployment is heading toward scale.

The answer is yes, agent identity is needed. The reasoning is less about the agent itself and more about the deployment context around the agent: managing large agent populations, or agents in employee-like roles, becomes impractical without a stable per-agent identifier.

## Why it is needed

Agent identity gives operators, users, and receivers the ability to distinguish one agent from another as a first-class fact rather than an inference from context. That simple property makes several practical concerns tractable: knowing which agents exist, tracking what each has done, assigning them to roles, managing the lifecycle of the fleet, and connecting downstream primitives (authorization, delegation, trust, audit) to a stable reference. Every other primitive in this document depends on identity as its anchor. Without identity, the rest of the coordination surface has nothing to attach to.

## The core use case: inventory and workforce management at scale

An organization deploys a thousand agents across its operations. Some handle customer service, some perform procurement, some monitor security, some run research tasks. Each agent takes actions on behalf of the organization. The operator needs to answer basic questions:

- Which agents exist?
- What is each agent supposed to do?
- Which agent performed a specific action?
- When was an agent deployed, updated, or retired?

Without a stable per-agent identifier, none of these questions can be answered reliably. Server names, process identifiers, endpoint addresses, and container instance IDs all change when infrastructure changes. Agent identity provides the stable reference point that lets the organization treat its agent fleet as a manageable inventory rather than a collection of anonymous processes.

Two familiar analogies apply. The first is retail: an online store with a thousand products in its catalog assigns each product a SKU. The SKU carries no other information about the product. It is simply the identifier that lets every other system (pricing, inventory, shipping, returns, analytics) attach cleanly to a specific product. The second is the employee number: when an agent takes on a role that used to be performed by a human, the employee identifier model brings a well-understood management framework with it, including hiring, role assignment, performance review, and eventual separation. Both analogies require the same primitive. An organization treating agents as products, or as workers, or as some combination of the two, needs a stable per-agent identifier before any of the higher-level management concerns can be addressed.

Higher-consequence needs (cryptographic verification, delegation lineage, trust scoring, audit trails) build on this base. Without the base, they cannot be built at all.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Verify which organization created an agent
- Tell two similar agents apart
- Track an agent across infrastructure changes (moved servers, changed cloud provider)
- Attribute a specific action to a specific agent
- Retire an agent while preserving its history
- Enforce the agent's declared role
- Prevent one agent from impersonating another
- Enable one agent to introduce another
- Manage many agents in one organization at once

---

[README](README.md) &nbsp;·&nbsp; [Authorization →](02-authorization.md)
