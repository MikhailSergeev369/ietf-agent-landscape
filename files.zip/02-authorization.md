# 2. Authorization

## Is agent authorization needed?

The internet already has substantial authorization infrastructure. OAuth 2.0 handles user-to-service authorization at massive scale. SPIFFE handles workload identity for service-to-service authorization. JSON Web Tokens carry scoped claims. Every enterprise identity system supports role-based and attribute-based access control. Frameworks such as Cedar, OPA, and Zanzibar handle policy evaluation. The general problem of "does this actor have authority to perform this action here" has been the subject of decades of work.

Underneath the standards is an even older pattern. Software has always required authorization to run. Operating systems ask permission before installing a package. Code signing verifies the source. Antivirus and endpoint detection systems watch for software behaving outside sanctioned scope. Every deployment of software in every organization for the last several decades has operated within this pattern: a human owner grants authorization to specific software to run, and monitoring watches for deviation from the sanctioned behavior.

Do agents need their own authorization primitive on top of all of that? A skeptic could argue that agents are software, and the existing model already covers them. An organization installs an agent the same way it installs any other application. A human owner grants the agent access to specific resources through the organization's existing IAM system. The agent runs under those permissions. If the agent misbehaves, existing monitoring catches it. When the agent calls an external service, it presents an OAuth token from the organization's identity provider. Standard stuff. Nothing new required.

Human employees fit the same pattern. Every employee in a company has access rights granted by an authorized human at the company. HR onboarding provisions those rights. The organization's access-control systems enforce them. Employees who exceed their authority are subject to well-established processes. Agent access rights, in this framing, are just another instance of the employee access-rights model. An agent taking on employee-like work inherits the employee-authorization pattern; agents change none of that.

At small scale, this framing holds. A single agent running on a single machine with a single owner presenting a single token to a single receiver looks exactly like traditional software, and traditional software authorization is sufficient.

The counter-argument turns on chains and cross-organization scope. An employee's access rights are scoped to their employer's systems. A given employee never sub-delegates their expense authority to another employee who sub-delegates to a vendor's finance system. Agent deployments do exactly this constantly. A user grants an assistant agent authority to book travel. The assistant delegates to a travel-booking service operated by a different organization. The travel-service delegates to a hotel booking system operated by yet another organization. The chain crosses three organizations in a single agent invocation, and each hop needs authority derived from the original grant.

Three problems emerge as a result. First, existing IAM systems were designed for a single organization's employees and applications, and were never built to carry authority across organizational boundaries in a form receivers can verify locally. Second, receivers cannot call back to every identity provider in the chain for every action; the round-trip cost is prohibitive at agent speeds. Third, and most important, the causal chain of authority (who originally authorized this action, and under what constraints) is lost when each hop presents a fresh token issued in isolation. Cryptographic lineage that survives the crossings is what agent authorization requires and what existing systems lack.

There is also a threat-model dimension. When an agent claims a capability and presents a token, the receiver needs to verify more than the token itself. The chain of authority behind the token must also be trustworthy. A capability claim from an agent whose delegation chain traces back to a legitimate principal is a different risk than a capability claim from an agent whose provenance cannot be established. Existing authorization infrastructure verifies the token; it cannot verify the chain. This is why substrate discovery and substrate authorization are architecturally paired: capability claims without lineage are exactly the attack surface a threat model highlights.

The answer is yes, agent authorization is needed as a primitive distinct from generic scoped tokens and traditional IAM. The primitive must carry chain lineage across organizational boundaries, must be verifiable at the receiver without external callbacks, and must support attenuation across hops. Existing infrastructure is one component of the solution rather than the solution itself.

## Why it is needed

Agent authorization gives receivers a way to answer three questions at the point of action, without calling back to any external service: what is this agent authorized to do here, who authorized it, and where in the chain did the authority originate. That combination is what distinguishes an agent authorization primitive from a generic scoped access token or an employee access right. Without it, receivers must trust the immediately preceding hop and lose all visibility into the causal chain of authority. This is unacceptable for high-consequence agent actions such as spending money, executing transactions, or modifying critical state, especially when the chain crosses organizational boundaries and adversarial capability claims are a real risk.

## The core use case: bounded delegation with a paper trail across organizations

An organization gives an assistant agent authority to spend up to $500 per month on travel booking for a specific employee. The assistant discovers that the best available package requires booking through a travel-service operated by a different company, which in turn needs to reserve a specific hotel from a hotel chain and a specific flight from an airline. Three organizations are now in the chain: the assistant's employer, the travel-service, and the hotel chain (the airline is a fourth). The trip proceeds. A month later, the employee's finance team reconciles the corporate card statement and sees a hotel charge for $237. Their job is simple: verify that this charge was authorized, connect it to the delegation that authorized it, and confirm the monthly total remains within the $500 cap.

That simple job is where existing infrastructure breaks down. The corporate card statement shows a merchant name (the hotel) and an amount. Nothing on the statement connects the charge back to the assistant that initiated the booking, the delegation that authorized the assistant, or the $500 monthly ceiling that scopes the delegation. To answer the finance team's question, someone has to email the travel-service vendor to request the booking record. That record references the assistant agent that submitted the booking. To confirm the assistant's authority, someone has to check with the internal agent management system. To confirm the running monthly total, someone has to aggregate charges across every vendor the assistant used that month. What should be one query becomes three phone calls and several days of reconciliation.

OAuth and IAM handle the credential problem at each boundary but lose the causal chain at every hop. When the travel-service requests a hotel reservation on the assistant's behalf, the hotel booking system receives an OAuth token from the travel-service that says "this token is authorized to reserve hotel rooms up to a specific ceiling." The token carries no information about which employee's monthly budget this reservation should draw from, whose approval structure authorized it, or how the reservation relates to any parent authority. Each token is internally consistent within its scope. The chain from the employee's delegation to the assistant to the travel-service to the hotel is severed at every boundary. From the substrate's perspective, four separate authorization events happened, each valid in isolation, none causally connected to any other.

The paper trail is what makes corporate spending authority work at scale in the pre-agent world. A purchase order references its parent approval; the parent approval references the budget line; the budget line references the approved plan. Any auditor examining a specific charge can walk backward through the chain and verify that the charge is within authorized bounds at every level, without needing to call the vendors involved. Agent authorization needs the same property at wire speed, and it needs to work across organizational boundaries where the parent authorization was granted in one system and the child action was enforced in another. Substrate authorization carries the causal chain end-to-end, so the finance team's reconciliation is one query against substrate records rather than three phone calls to three vendors.

Human employee access rights avoid this problem because human employees rarely chain their spending authority across three organizations in one action; when they do, they file expense reports that manually reconstruct the chain. Software authorization avoids this problem because software runs within the boundaries of a single operating system's permission model. Agents cross both boundaries constantly and at machine speed. The primitive is needed for the specific case that emerges when both scale and chained cross-organization delegation are present, and the case is common in every serious agent deployment.

Higher-consequence needs (attenuation semantics, revocation propagation across the chain, cross-organization delegation with different trust anchors, verification against a threat model) build on this base. Without the base, delegation between agents at scale reduces to a chain of independently issued tokens with no causal linkage between them, which fails as delegation in any meaningful sense.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Check whether an agent may perform a specific action
- Preserve the chain of who authorized what across organizational boundaries
- Revoke an agent's authority
- Check cumulative spending against a budget cap
- Delegate authority for a specific type of action
- Delegate a narrower authority than the delegator holds
- Set an authority to expire at a specific time
- Check whether an authorization is still current
- Verify authority without contacting the original authorizer

---

[← Identity](01-identity.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Delegation →](03-delegation.md)
