# 6. Communication

## Is agent communication needed?

The internet has robust communication infrastructure. HTTP handles request-response for the web. WebSockets provide bidirectional streams. gRPC delivers structured RPC with type safety. MQTT handles publish-subscribe for IoT and telemetry. SMTP handles asynchronous messaging. TLS secures everything at the transport layer. JSON and Protobuf handle structured data serialization. Every communication pattern in common use is already covered by a well-supported standard. Agents today use these protocols directly. MCP runs on HTTP. A2A runs on HTTP. ACP runs on HTTP. The current agent ecosystem is built on the existing communication stack, and the stack works.

Do agents need their own communication primitive on top of all of that? A skeptic could argue no, and the case is stronger than it first appears. The current agent ecosystem is the proof of concept. MCP, A2A, and ACP all run on HTTP. All have working implementations. All have growing production use. HTTP's request-response model already handles most coordination patterns. WebSockets extend it to bidirectional streams within the same session model. JWT tokens carry attribution. Cookies persist session state. MIME types have handled multi-modal content for decades. Rather than invent a new coordination substrate that would fragment the ecosystem further, the skeptic argues, standardize conventions on top of HTTP: publish an "agent coordination conventions" specification, define headers for attribution and delegation, adopt JSON schemas for messages. Every runtime already has HTTP client libraries and JSON parsers. The path of least fragmentation is to build on what already works.

The counter-argument earns its ground precisely because the skeptic's case is strong. HTTP does work. Existing agent stacks do have real ecosystems. Building on HTTP is a defensible direction. The problem shows up when the ecosystem grows.

The interoperability tax has a specific shape. Every agent stack that exists today has its own conventions for the coordination primitives that HTTP omits natively: attribution, delegation lineage, session context, semantic verbs, multi-modal binding. MCP has one convention set. A2A has another. ACP has a third. Each set is internally coherent, defined by its authors for its specific ecosystem. Across stacks, an agent from one stack has to bridge to reach an agent from another. Adding a new stack multiplies the translation surfaces: to add stack N, integrations must be built against each of the existing N-1 stacks. The burden grows as N times M for N stacks interacting with M other stacks. This is exactly the quadratic scaling problem HTTP itself avoided at the web layer. HTTP made web coordination possible because every client and server implemented HTTP the same way. Every convention set built on top of HTTP recreates the pre-HTTP fragmentation, just one layer higher.

The deeper architectural point is that HTTP was designed for a different primary payload. HTTP is a content substrate. Its primary payload is documents intended for human consumption. Its content types (HTML, images, video files, PDFs), its caching semantics, its content negotiation, its status codes for resource state (success, redirect, missing resource, server error), and its methods (GET, PUT, POST, DELETE) all serve that purpose. HTTP was designed to move documents from servers to browsers, and the browser renders the document for a human.

Agent communication has different primary needs. The primary payload is intent (what the sender wants to accomplish) plus context (what the receiver needs to fulfill it), rather than content for a human to read. The interaction is bidirectional coordination between two software entities that both understand structured messages, rather than one-way content delivery to a human interface. Attribution matters at every message because both parties are acting on behalf of other principals, and the chain of delegation must remain visible. Multi-modal payloads (voice, video, structured data streams, text) appear alongside message exchange for coordination purposes, rather than as content packages to be delivered.

The pattern shows up whenever a general-purpose protocol is stretched to serve a specialized coordination need. Email over the postal service works, but it stretches paper mail beyond what the postal service was designed to do. Voice over telegraph works, but it stretches telegraph beyond dot-dash. Both of those cases produced dedicated protocols (SMTP for email, phone networks for voice) once the specialized use case grew large enough to justify a purpose-built layer. Agent coordination is now at that scale.

Consider the postal service parallel more directly. The postal system carries envelopes between addresses. Every envelope has attribution (sender address, recipient address), delivery guarantees (first class, certified, express), and coordination properties (return receipts, tracking numbers). The envelope structure is the coordination primitive; the letter inside is the content. The postal service works because both the envelope and the delivery process are purpose-built for the coordination need. If someone tried to deliver mail by attaching letters to newspaper delivery trucks (a content-delivery substrate for newspapers), it would work at small scale, break down at any real volume, and force senders and receivers to reconstruct addressing and delivery reliability at the application layer.

HTTP is the newspaper delivery truck. It moves content from servers to human-facing applications, extremely well. Agent coordination is the mail service that agent-native communication needs to build. The primitive should carry intent structure at the wire, attribution at every message, multi-modal streams natively, and integration with the other substrate primitives (identity, authorization, delegation, trust) as first-class fields rather than as application-layer conventions.

The SMS parallel makes the point at a smaller scale. When SMS emerged in the 1990s, existing communication infrastructure already covered synchronous voice (phone calls) and asynchronous text (email, letters). A skeptic at the time could have argued that SMS was unnecessary: use email for text, use voice calls for real-time coordination, done. But SMS filled a distinct coordination pattern that neither voice calls nor email served well: real-time-ish, bidirectional, message-oriented, attribution-native (the phone number is intrinsic), delivery-confirmed. SMS became one of the most-used communication protocols in history because the coordination pattern was real and existing protocols served it poorly. Agent coordination is in the same position now.

The answer is yes, agent communication is needed as a substrate primitive distinct from HTTP and from application-layer conventions on top of HTTP. The primitive must carry:

- **Structured intent at the wire.** Messages carry semantic verbs (query, delegate, execute, and others) plus typed parameters, so receivers dispatch and audit without parsing prose or reverse-engineering an application-specific format.
- **Attribution end-to-end.** Every message carries verifiable attribution to the sending identity and to the delegation chain behind it. Intermediaries can inspect attribution without decrypting the message payload; receivers can verify attribution independently of any transport session.
- **Bidirectional coordination.** Real-time bidirectional streams are first-class, alongside request-response and asynchronous messaging. Coordination between two agents may span many messages in either direction within a single exchange.
- **Multi-modal payloads.** Voice, video, structured data streams, and text messages coexist within the same coordination context, without requiring separate connections or protocol switches.
- **Substrate integration.** Identity, authorization, delegation, trust, and attribution primitives are carried natively with the message, rather than being reconstructed by the application layer above the transport.

## Why it is needed

Agent communication is the vehicle for every coordination act between agents. Discovery finds a candidate. Trust filters it. Authorization checks the specific action. Delegation frames the mandate. Communication is where the coordination actually happens: the message goes from sender to receiver, carrying with it everything the receiver needs to evaluate and respond. If communication fails to carry the coordination primitives natively, every application must rebuild them. The rebuilding fragments across implementations, breaks interoperability, and creates security gaps at the boundaries between reconstructions. Substrate communication makes coordination properties portable across applications and verifiable end-to-end.

## The core use case: coordinating a task through real-time bidirectional exchange

An assistant agent is working with a travel-service agent to book a business trip on behalf of the assistant's principal. The exchange is a coordinated conversation rather than a single API call:

- Assistant: "Book a trip to Tokyo for my principal, March 15 to 20, direct flights preferred, hotel under $200 per night, total budget $2,500."
- Travel-service: "I have 3 flight options and 5 hotels matching the criteria. Here are the details."
- Assistant: "Let me check flight options 1 and 3 against my principal's calendar."
- Assistant: "Option 3 works. Which of the 5 hotels fits best with that flight's arrival time?"
- Travel-service: "For flight option 3, hotels A and C have availability. Hotel A is closer to the meeting locations you specified in prior bookings."
- Assistant: "Book flight option 3 and hotel A."
- Travel-service: "Confirmed. Total: $1,847. Confirmation numbers and itinerary follow."

Every message in this exchange carries information that the substrate must handle:

- **Who is speaking.** The assistant's identity, verified. The travel-service's identity, verified. The principal's identity, referenced through the assistant's delegation chain.
- **On whose behalf.** The assistant is acting under a delegation from the principal. The delegation chain and its scope are visible on every message.
- **What the intent is.** Book. Check availability. Recommend. Confirm. Each message carries a semantic intent alongside any body data.
- **What the context is.** Prior messages in the exchange, the delegation framework, the principal's stored preferences, the travel-service's prior bookings referenced in the recommendation.
- **What modality.** Structured data (flight options, hotel details, confirmation numbers) interleaved with natural-language coordination text. Voice or video could join the same exchange if the assistant needed to confirm something audibly.

Without a substrate communication primitive:

- The assistant and travel-service must have agreed on a specific API contract in advance (REST endpoints, JSON schemas, parameter names, response formats). Any change to the API requires coordinated updates on both sides.
- The exchange breaks into a series of independent HTTP requests. Each request must carry enough state to reconstruct the coordination context, which typically means large opaque session tokens and cookie-based state management on both sides.
- Attribution is reconstructed from JWT tokens or from application-layer identity headers, and the delegation chain is either lost or must be encoded as an application convention that receivers might parse or ignore.
- Multi-modal payloads require separate channels or protocol switching mid-exchange, which forces the application to manage multiple connections and reassemble the coordination logic across them.
- Trust and authorization decisions happen out-of-band, at the boundaries between individual HTTP requests, with the application layer responsible for maintaining consistency.

With a substrate communication primitive:

- The assistant and travel-service exchange messages using shared semantic verbs (search, evaluate, book, confirm). Both parties understand what each verb means without prior API negotiation. New verbs can be added to the vocabulary as needed, with clear semantics.
- The exchange is a single coordinated session. Context persists across messages naturally, without requiring the application to encode and decode session tokens on every message.
- Attribution rides with every message, cryptographically bound to the sending identity and referencing the delegation chain. Any receiver, and any intermediary, can verify attribution locally.
- Multi-modal payloads flow within the same coordination context. Structured data, natural-language text, voice, and video coexist as first-class message types.
- Substrate primitives (identity, delegation, trust, attribution) are inspected at message-level rather than being reconstructed by the application.

The postal service parallel captures the shift. Under an HTTP-only approach, the assistant is stuffing letters into newspapers hoping the delivery truck brings them to the right person. Under a substrate communication primitive, the assistant is putting letters in envelopes with proper addressing and delivery service, and the postal system handles the coordination. Both approaches move bytes from A to B. Only the second treats the coordination properties (attribution, delivery reliability, addressing, service class) as substrate primitives rather than application concerns.

Human employees rarely need this specific primitive because human coordination already has purpose-built communication channels for different needs. Business meetings for real-time multi-party coordination. Email for asynchronous formal communication. Phone calls for urgent bidirectional coordination. Chat for casual asynchronous coordination. Formal letters and contracts for legal-instrument-grade communication. Each channel evolved for its specific coordination pattern. Software rarely needs this primitive because software components typically call each other through pre-agreed API contracts (function calls, RPC, message queues) with pre-negotiated schemas. Neither model handles the case of agents coordinating across organizational boundaries in real time, exchanging structured intent with delegation lineage intact, across multiple modalities, without pre-negotiated API contracts. That is the common case at agent scale, and it is what agent communication addresses.

The HTTP-and-application-layer approach works cleanly when both parties are running the same agent stack, have agreed on a specific API contract, and are exchanging simple structured messages under a single principal. It works less cleanly when the parties come from different agent stacks with different conventions, when the exchange spans multiple modalities, when delegation chains need to be preserved across many messages, and when new coordination patterns emerge that fell outside the original API design. Substrate communication makes coordination portable across stacks, across modalities, across delegation chains, and across evolving patterns without requiring every application to reinvent the coordination primitives.

Higher-consequence needs (long-lived coordination sessions that survive transport interruption, encrypted multi-modal streams with per-modality trust properties, cross-organization coordination across trust boundaries, real-time media coordination with per-participant attribution, coordination-layer intermediaries that inspect attribution without decrypting payloads) build on this base. Without the base, agent coordination reduces to whatever any two agent stacks can negotiate at the application layer over HTTP, and interoperability across stacks becomes an integration project rather than a substrate property.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Send a structured intent from one agent to another
- Hold a bidirectional conversation across many messages
- Broadcast a coordination message to many recipients
- Mix multi-modal content (voice, video, structured data) in one exchange
- Preserve who is speaking when a message passes through an intermediary
- Support real-time streaming between agents
- Support asynchronous messaging with delivery guarantees
- Handle message ordering and duplicates
- Encrypt messages at the substrate layer
- Coordinate messages from many senders in one exchange

---

[← Discovery](05-discovery.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Session →](07-session.md)
