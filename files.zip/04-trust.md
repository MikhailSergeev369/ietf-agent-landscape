# 4. Trust

## Is agent trust needed?

Trust in software systems has a long history. Public key infrastructure uses certificate authorities to verify identity and by extension to establish a chain of trust. TLS certificates encode a trust path from the browser to the site. Code signing lets recipients verify that software comes from a claimed source. Reputation systems on major platforms (eBay ratings, Yelp reviews, Amazon reviews, GitHub stars) let users evaluate whether a specific product, service, or repository is worth engaging with. Insurance ratings agencies produce standardized measures of firm-level trust for the financial sector. Credit bureaus produce standardized measures of individual-level trust for consumer lending.

Do agents need their own trust primitive on top of all of that? A skeptic could argue no. PKI already verifies identity: the agent's certificate proves who it is. Reputation systems already exist for evaluating services: an application can look up the agent's rating on whatever platform tracks it. Trust is subjective anyway; it belongs at the application layer where product decisions live, rather than at a coordination substrate. Combining existing PKI infrastructure with application-layer reputation covers the trust problem.

The counter-argument is that identity and trust answer different questions. Identity answers "who is this?", a factual question about the entity's origin that cryptographic verification can settle definitively. Trust answers "how much should I believe them?", a question about the entity's likely behavior that evidence can inform but never fully settle. Both are necessary; neither substitutes for the other. Knowing that an agent is authentically issued by Company X reveals nothing about whether Company X's agents behave reliably. Knowing that an agent has good reviews on one platform reveals nothing about whether it behaves the same way in a different context.

Application-layer reputation systems fail for agents at scale for four reasons:

1. **Duplication.** Every application reinvents trust independently. Yelp scores mean nothing on eBay. Amazon reviews mean nothing on GitHub. There is no portable trust measure across contexts.

2. **Non-portability.** An agent's reputation in one marketplace fails to follow it into another. A well-behaved shopping agent has to earn its trust from scratch every time it moves into a new domain, which fails to scale to millions of agents operating across many contexts.

3. **Manipulability.** Application-layer reputation is prone to abuse: fake reviews, sybil attacks, purchased ratings, coordinated brigading. Without a substrate-level trust primitive with cryptographic backing, reputation is only as reliable as the platform enforcing it.

4. **Adversarial threat model.** A recent public observation captured the concern precisely: capability claims from agents immediately raise security questions about whether an agent that says it can do something can actually be trusted to do it. Capability claims without a trust primitive underneath are exactly the attack surface. A receiver needs some way to evaluate whether a claimant's capability claim is worth acting on before granting access.

The credit score analogy is direct. A credit score is a standardized, portable, graduated trust measure computed from multiple verification paths (payment history, credit utilization, length of history, credit mix). It carries a graduated value along a defined range. It is fresh. Lenders make consistent, automated decisions using it across the industry. Consumer credit worked poorly before credit bureaus produced this substrate; every lender had to independently assess trustworthiness with limited information. Agent trust is currently in the pre-credit-bureau state: every application must independently assess whether an agent is worth engaging with, using inconsistent evidence.

The threat model dimension makes the primitive urgent. Discovery returns candidates. Authorization checks specific actions. But between the two, some evaluation must happen: which candidates are worth authorizing? Without a trust primitive, that evaluation either happens per-application (duplicated, non-portable) or fails to happen at all (blind acceptance of all discovered candidates). Neither result is acceptable at scale, and neither result is defensible under an adversarial threat model.

The answer is yes, agent trust is needed as a primitive distinct from identity and from application-layer reputation. The primitive must be substrate-level (portable across contexts), verifiable at the receiver (without callbacks), graduated (a value along a defined range rather than binary), and fresh (bounded staleness on trust state).

## Why it is needed

Agent trust gives receivers a standardized way to evaluate whether a claim (of capability, of behavior, of intent) is worth acting on. Identity gives you a name; trust gives you a measure. Authorization gives you scope; trust gives you the evidence to decide whether the scope is worth granting. Delegation gives you the mandate; trust gives you the evidence that the mandate is being executed by a party worth mandating. Every subsequent coordination decision reads trust as an input, even when the decision itself is called something else. Without trust as a distinct primitive, coordination reduces to either blind acceptance of claims (which fails under adversarial conditions) or wholesale rejection of new relationships (which fails to scale beyond hand-curated allowlists).

## The core use case: selecting a trustworthy agent from many claimants

An individual needs an agent to help with tax preparation. They query the substrate and receive twenty agents that claim tax preparation capability. Some are legitimate services with strong track records. Some are inexperienced but honest. Some are outright fraudulent, seeking to harvest sensitive financial data or provide deliberately wrong advice. The individual must decide which agents are trustworthy enough to hire.

Without a trust primitive at the substrate:

- The individual must independently research each agent, reading reviews on whichever platform tracks that agent, checking certifications manually where they exist, and relying on out-of-band signals like domain reputation and word of mouth.
- Each research effort is duplicated for every new agent the individual considers, and none of the research is portable to the next selection decision.
- Fraudulent agents can present professional-looking certificates, buy fake reviews, and appear on paid rating lists. The signal-to-noise ratio is poor.
- The individual has no reliable way to distinguish "verified by an independent authority" from "self-asserted."

With a trust primitive at the substrate:

- Each agent carries a trust score computed from multiple verification paths: professional certification (CPA firms verified by state boards), operational track record (previous transactions logged in transparency logs), independent verification (industry associations that audit member behavior), and organizational backing (which company owns the agent, and what is that company's own trust profile).
- The score is standardized, graduated, and portable. A tax-preparation agent with a high score is trustworthy in the same measurable way regardless of which application queries.
- The individual can filter at discovery time: "return only tax-preparation agents with a trust score above X and freshness within Y hours."
- Fraudulent agents can still appear in the marketplace, but their trust scores reflect the absence of independent verification. The individual sees the difference at discovery time, before granting access, before delegating any authority.

The credit score parallel makes the primitive concrete. A consumer applying for a mortgage rarely researches the lender's assessment methodology themselves. The lender pulls the credit score, applies its own thresholds, and decides. The consumer receives a standardized offer based on a standardized measure. Both parties benefit from a substrate-level trust primitive that no individual application had to build.

The corporate analog is vendor selection. When a company evaluates a new vendor, it uses standardized signals: financial ratings (S&P, Moody's), industry certifications (ISO 27001, SOC 2), insurance ratings, and reference checks. Each signal comes from an independent authority. The evaluation combines them into a decision. Agent trust needs the same properties at wire speed: multiple standardized signals, independent verification, portable across contexts, graduated in value.

Human employees rarely need this specific primitive because the employment relationship itself carries trust context. The employer has HR records, references, background checks, and ongoing performance data. Employees who behave poorly are subject to disciplinary process. Software rarely needs this primitive because software is typically installed by an authorized human who has already made the trust decision at install time. Neither model handles the case of agents encountering each other across organizational boundaries with no prior relationship. That is the common case at scale, and it is the case Trust addresses.

Higher-consequence needs (trust score computation methodology, revocation of trust across multiple verification paths, cross-domain trust anchor composition, trust for anonymous or pseudonymous agents, adversarial-resistance guarantees against sybil and manipulation attacks) build on this base. Without the base, agent coordination at scale reduces to either "trust everyone by default" (which fails immediately under adversarial pressure) or "trust nothing" (which fails to scale beyond hand-curated allowlists).

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Decide whether a capability claim is worth acting on
- Filter search results by trust tier at query time
- Detect reputation manipulation (fake reviews, sybil attacks)
- Combine multiple verification paths into one score
- Require a minimum trust level for certain classes of action
- Downgrade trust when behavior degrades
- Verify certification claims against issuing authorities
- Carry trust across contexts (portable trust)
- Handle trust decay over time
- Tell verified claims apart from self-asserted claims

---

[← Delegation](03-delegation.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Discovery →](05-discovery.md)
