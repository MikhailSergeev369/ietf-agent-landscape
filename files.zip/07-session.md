# 7. Session

## Is agent session needed?

Session infrastructure has existed on the internet since the earliest web applications. HTTP cookies carry session state across requests. TLS session resumption avoids full handshakes on reconnection. WebSocket persistent connections maintain real-time state between client and server. OAuth refresh tokens keep authorization state alive across long periods. Application-layer session tables in databases hold user state across many interactions. Every serious web application manages session state today, and the tools for managing it are mature.

Do agents need their own session primitive on top of all of that? A skeptic could argue no. Combine HTTP cookies for state, TLS session resumption for cryptographic continuity, WebSocket connections for real-time, and OAuth refresh tokens for auth persistence. The combination covers the session case for any application, agent or otherwise. Nothing new required.

The counter-argument turns on the assumptions built into traditional web session infrastructure. Web sessions were designed for a specific interaction pattern: a human user opens a browser, interacts with a service for minutes or hours, and closes the session when they finish. Cookies persist within that scale. TLS resumption optimizes for reconnection within a short window. WebSocket connections stay open while the browser tab remains active. OAuth refresh tokens extend the pattern but still assume the same shape: single user, single service, session-length measured in hours or perhaps days.

Agent sessions break these assumptions in six specific ways.

First, **duration**. A single agent coordination task may span days, weeks, or months. A market research task waits for external data delivery. A grant application waits for co-signers. A legal filing waits for court schedules. The coordination stays coherent across the wait, but the wait exceeds any timeout a traditional session was designed for.

Second, **endpoint-bound state**. Traditional session state lives at one endpoint (server-side session table, browser cookie jar). Agent sessions frequently span multiple agents in a delegation chain. When an assistant agent delegates a research task to a research agent, which in turn calls a data agent, the coherent coordination context spans three endpoints. Traditional sessions cannot represent this without application-layer coordination code.

Third, **transport fragility**. Cookies invalidate when the browser closes. TLS session resumption tickets expire. WebSocket connections drop under network partition. Traditional session state assumes the underlying transport is roughly continuous during the session. Agent sessions must survive process restarts, container migrations, infrastructure changes, and long dormancy where nothing is transported at all.

Fourth, **cryptographic continuity**. Traditional session tokens can be exchanged, refreshed, or reissued, but there is no built-in mechanism to prove that a resumed session is cryptographically continuous with the original. For high-consequence coordination (approvals, contracts, financial commitments), the receiver needs proof that today's message comes from the same session that started three weeks ago, cryptographically bound, without depending on trust in the server that manages the session table.

Fifth, **transactional semantics**. Web sessions rarely need commit-or-rollback semantics; the browsing user rarely needs to roll back a shopping cart cleanly. Agent coordination often does. When an agent commits a partial purchase across three sub-agents, and one leg fails, the coordination needs to unwind cleanly. Traditional session state offers no primitive for this; each application implements its own transactional semantics on top of session tokens.

Sixth, **suspend and resume**. A long-running agent task may need to pause for hours or days waiting for human input, external event triggers, or scheduled continuation. When the task resumes, it must pick up exactly where it left off, with all coordination context intact, without re-authenticating, re-establishing delegation, or reloading state from scratch. Traditional session infrastructure was designed for continuous use rather than intentional pause-and-resume.

The video game save-state analogy is the cleanest one. When you save a game, you can close the console, come back tomorrow or next month, load the save file, and continue exactly where you left off. Every element of your progress is preserved: your character's inventory, your position in the world, your relationships with non-player characters, your active quests. Load the save file and the game continues as if you had never left. That is the property agent coordination needs. Traditional web sessions have nothing like it; they behave more like a phone call where hanging up ends the conversation and calling back starts a new one.

Bank accounts capture a different aspect. Your account persists across time, across bank employees, across your own devices, across bank system upgrades. The account holds transaction history, balance state, authorized users, and preferences. You can walk into any branch, log into any app, or call any support line, and the account state is available. This is state persistence across time and across access contexts. Traditional web sessions are ephemeral by comparison; the bank account model is what agent sessions need for long-lived coordination.

Medical patient records extend the analogy to multi-party persistence. A patient's medical history persists across visits, providers, hospital systems, insurance changes, and even across decades. Any authorized provider can access the record, add to it, and reference prior entries. The record itself is the coherent state; providers are participants in the record over time. This is closer to what an agent coordination session looks like when multiple agents participate across a long-running task.

The answer is yes, agent session is needed as a substrate primitive distinct from traditional web session infrastructure. The primitive must support:

- **Long-duration persistence.** Coordination sessions that survive intended pauses of days, weeks, or months without losing state.
- **Multi-endpoint span.** Sessions that carry coherent coordination context across multiple agents in a delegation chain.
- **Interruption tolerance.** State that survives transport failure, process restart, infrastructure migration, and long dormancy.
- **Cryptographic continuity.** Resumed sessions provably continuous with the original, verifiable by any receiver without trusting the server that manages the session state.
- **Transactional semantics.** Support for commit-or-rollback where the coordination workflow requires it.
- **Suspend and resume.** First-class operations that pause a session gracefully and resume it with full context preserved.

## Why it is needed

Communication handles individual messages between agents. Session handles state that persists across many messages over time. The two primitives are complementary rather than overlapping: an exchange of five messages may happen entirely within one session or across five separate sessions, and the same substrate must support both patterns. Without a session primitive, every application that coordinates agent tasks over time must build its own state persistence, its own reconnection logic, its own cryptographic continuity proofs, and its own transactional semantics. The rebuilding fragments across applications, breaks interoperability across stacks, and creates security gaps at the boundaries between reconstructions. A substrate session primitive makes long-lived coordination state portable and verifiable end-to-end.

## The core use case: a research task that spans days with human review at key points

An assistant agent is preparing a market research report for its principal. The task will take about a week and involves multiple stages of work interleaved with human input.

**Day 1.** The assistant agent begins the task. It delegates data-gathering to a research agent operated by a subscription intelligence service. The research agent begins pulling data from multiple sources. The assistant agent produces preliminary observations and sends a status update to the principal.

**Day 2.** The principal reviews the preliminary observations overnight and sends feedback in the morning. "Focus more on the enterprise segment. Also, add competitor pricing analysis." The assistant agent receives the feedback, adjusts the research direction, and re-delegates to the research agent with the new criteria.

**Day 3.** The research agent finishes data collection. The assistant agent begins analysis, drafts findings, and identifies two questions that need principal input. It sends the questions to the principal and pauses the coordination.

**Day 4.** The principal is traveling and unavailable for most of the day. The session waits. At the end of the day, the principal responds to the two questions.

**Day 5.** The assistant agent resumes, incorporates the principal's answers, and produces a draft report. It sends the draft to the principal for review.

**Day 6.** The principal reviews the draft, marks up changes, and returns it. The assistant agent works through the revisions.

**Day 7.** Final report delivered.

The entire seven-day workflow is one coherent coordination session. It survives:

- Six overnight pauses (transport connections drop, processes restart)
- One full-day pause while the principal is traveling
- Multiple delegation hops (assistant to research agent and back)
- Infrastructure changes (if the assistant agent moves servers mid-week)
- Multiple message exchanges within each active day

Without a session primitive at the substrate:

- The application must serialize coordination state to a database at the end of each active period and reload it at the start of the next. Every serialization boundary is a potential integrity failure.
- The assistant agent must re-authenticate, re-establish delegation from the principal, and re-verify the research agent's identity at the start of each day. Each re-authentication is a friction point and a place where the coordination might fail to resume.
- The research agent's participation must be tracked separately, in a different session table or state store, since traditional session infrastructure cannot span multiple endpoints coherently.
- Cryptographic proof that today's coordination is continuous with what was set up on day 1 must be constructed from scratch at every resumption. There is no substrate primitive that carries this continuity natively.
- If the assistant agent's process restarts, the application must reconstruct the coordination context from persisted state. Anything that was in memory at the time of the restart may be lost or must be recomputed.

With a session primitive at the substrate:

- The session is a substrate object with a stable identifier that persists across time. Reattaching to it uses the same primitive whether one hour or one week has passed.
- The delegation chain (principal to assistant, assistant to research agent) is bound into the session at establishment. Reattaching preserves the delegation context without requiring re-authentication at each step.
- All participating agents share coherent coordination context through the session, and any participant can reattach and inspect current session state.
- Cryptographic continuity is provided by the substrate: any receiver evaluating a message from the resumed session can verify it is continuous with the session that was established on day 1.
- Suspend and resume are first-class substrate operations. The session pauses gracefully at the end of each active period and resumes at the start of the next, with state intact.

The video game save-state parallel maps directly. On day 1, the assistant agent saves the coordination state to a session. Each day, it loads the save state, continues the work, and saves again. On day 7, the final delivery is the completion of the game. The save state made the whole week-long task tractable as one coherent workflow rather than seven independent restarts.

Human employees rarely need this specific primitive because human work is naturally suspended and resumed by the humans themselves. A researcher stops work at the end of the day, remembers where they left off, and continues in the morning. The state persistence happens inside the researcher's mind and any personal notes they took. Software rarely needs this primitive because software components typically run continuously or complete their work in one execution. When software does need long-lived state, it uses application-specific databases with application-specific schemas, custom to the workflow. Neither model handles the case of coordination that spans multiple agents across time, requires cryptographic proof of continuity, and needs to survive infrastructure change without application-layer reconstruction. That is the common case for any serious long-running agent workflow, and it is what session addresses.

Traditional web session infrastructure works cleanly when the interaction is a single user with a single service over minutes or hours. It works less cleanly when the coordination spans multiple agents, needs to survive intended pauses of days, and requires cryptographic continuity that no application-layer reconstruction can provide. Substrate session makes long-lived coordination state portable across time, across participants, and across infrastructure changes without requiring every application to invent its own persistence layer.

Higher-consequence needs (coordinated sessions across trust boundaries with per-participant state visibility rules, session-level transaction atomicity across delegation chains, session state that outlives specific participating agents through delegation-chain succession, encrypted session state that receivers can decrypt with substrate-level keys, cross-organization session federation) build on this base. Without the base, agent coordination reduces to what application-layer session tokens can express, and application-layer session tokens were designed for a shorter, simpler pattern of interaction.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Maintain state across a coordination that runs for days or weeks
- Pause a session for external input (human approval, awaited event)
- Resume a session with full context intact
- Prove a resumed session is continuous with the original
- Support sessions where multiple agents participate
- Support commit-or-rollback across a session
- Recover a session after a process restart
- Enable session participation by agents from different organizations
- Control which participants see which parts of session state
- Handle session state that outlives specific participants

---

[← Communication](06-communication.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Semantics →](08-semantics.md)
