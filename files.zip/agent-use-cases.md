# Foundational Use Cases for Agent Coordination

**Author:** Chris Hood
**Version:** 0.2 draft
**Status:** All twelve primitives (Identity §1, Authorization §2, Delegation §3, Trust §4, Discovery §5, Communication §6, Session §7, Semantics §8, Tools §9, Commerce §10, Audit §11, Governance §12) have been reworked to the "is it needed / why / core use case" format. This is v0.2 of the document. Feedback on any specific primitive is welcome.
**Purpose:** An opinionated framing of the use cases that agent systems must address for a coherent internet of agents to exist. Protocol-agnostic. One architect's view.

---

## Opening

The IETF landscape currently contains over 225 individual submissions targeting AI agent standards. Most propose new protocols. Most tie those protocols to specific enterprise objectives, product lines, or organizational agendas. Few step back to ask what problems agent systems actually need solved, independent of which particular protocol solves them.

Beneath the volume of proposals sits a familiar problem from product development: solutions arriving before the design is clear. Every protocol author is building. Few authors have paused to establish what a coherent internet of agents actually needs, or whether the primitives everyone assumes are required are actually required at all. Cryptographic delegation formats, transparency log integrations, and semantic method vocabularies all show up in drafts before the underlying question has been examined: is this primitive needed, and if so, why?

This document takes the earlier step. It examines twelve primitives that recur across current proposals and, for each, asks two questions. First, is the primitive needed? The answer varies by primitive and requires argument rather than assertion. Existing internet identifiers (IP addresses, domain names, email addresses) already serve many purposes; a new agent primitive requires justification rather than assumption. Second, if the primitive is needed, what is the simplest concrete use case that demonstrates the need? Use cases here are described at the primitive layer rather than the protocol layer, and are kept deliberately simple. Cryptographic properties, transparency guarantees, and revocation semantics belong to solutions; this document stays with the problems those solutions address.

The document is opinionated. It reflects one architect's judgment about which primitives matter, what the honest skeptical case is for each, and which use case best illustrates the need. Consensus documents converge on the least controversial framing, which is often the least useful. Readers will disagree with specific selections. Disagreement about which use cases matter is a more productive conversation than disagreement about which protocol wins.

The document is also protocol-agnostic. Multiple protocols may address the same use case. A specific protocol may address use cases across multiple primitives. Neither shape is inherently correct. The framing exists to make comparison tractable and to keep the conversation grounded in problems rather than solutions.

## Scope

Each primitive is presented in two forms. The core use case is one concrete scenario, chosen because it demonstrates the need cleanly and can be visualized without technical background. Additional use cases follow as an illustrative list in simpler language, covering the range of scenarios the primitive addresses. Neither is exhaustive. Both lists are open to contribution: readers whose favored use case is missing are welcome to propose additions. The goal is to validate that each primitive is required and to sketch its scope. Complete enumeration of every possible scenario belongs to solution proposals rather than to this framing.

## The Twelve Primitives

The primitives, in the order they appear:

1. **Identity**: who is this?
2. **Authorization**: what may this actor do here, now?
3. **Delegation**: who authorized whom to do what on whose behalf?
4. **Trust**: how much should this claim be believed?
5. **Discovery**: how does one agent find another?
6. **Communication**: how do agents exchange messages reliably?
7. **Session**: how is state maintained across time?
8. **Semantics**: what does the actor mean?
9. **Tools**: how does an agent invoke a capability outside the agent scope?
10. **Commerce**: how do agents transact with money?
11. **Audit**: what happened, and can it be verified after the fact?
12. **Governance**: what rules govern the agent, and who enforces them?

Each primitive is examined below with a common three-part structure. First, is the primitive needed? This section presents the honest skeptical case, the counter-argument, and the answer. Second, if the answer is yes, why is the primitive needed at the coordination-surface level? Third, the core use case: a single concrete scenario that demonstrates the primitive's necessity, kept simple enough that anyone can visualize it without technical background. Solutions are deferred; this document focuses on the problems that require solving rather than the solutions themselves.

## Summary Table

| # | Primitive | Core reason (one sentence) | Core use case (one sentence) |
|---|-----------|----------------------------|------------------------------|
| 1 | Identity | Every internet participant category has an identity; agents need one that is verifiable, portable, and durable across infrastructure change. | Managing an organization's agent fleet at scale, the way SKUs manage inventory and employee numbers manage workforces. |
| 2 | Authorization | OAuth and IAM handle machine-to-machine credentials well but lose the causal chain when actions cross organizational boundaries. | Booking a trip across three organizations while preserving a paper trail from the principal to every downstream commitment. |
| 3 | Delegation | The word "agent" itself embeds delegation; the framework establishing authority is architecturally distinct from the runtime check on any specific action. | An executive delegates authority for two weeks of purchases, meetings, and reviews before going on vacation. |
| 4 | Trust | PKI verifies identity; reputation systems evaluate services; neither provides substrate-level graduated trust portable across contexts. | Choosing among twenty tax-preparation agents claiming the same capability, when some are inexperienced and some are fraudulent. |
| 5 | Discovery | DNS is a publishing model that returns names to addresses; agent-native discovery is scanning intrinsic metadata by capability. | Finding a legal-Japanese-to-English translator with the right price, trust tier, and delivery timeline. |
| 6 | Communication | HTTP is a content substrate designed for browser-to-server delivery; agents need a coordination substrate with intent, attribution, and multi-modal streams. | A bidirectional booking conversation between an assistant agent and a travel-service agent. |
| 7 | Session | HTTP cookies and TLS resumption handle minute-to-hour web sessions; agent coordination often spans days or weeks with pauses and process restarts. | A week-long market research task with human review at key points. |
| 8 | Semantics | Schema languages describe structure; nothing at the wire provides shared coordination-verb meaning between arbitrary agents. | Two agents from different companies complete a purchase without prior integration. |
| 9 | Tools | MCP works for tool invocation, but the tool-versus-agent boundary is arbitrary; separate stacks fragment identity, discovery, and authorization. | An agent composes a calendar tool, an email tool, and another organization's agent in one workflow with a single delegation chain and one audit trail. |
| 10 | Commerce | Existing payment infrastructure was designed for human-initiated transactions; agent commerce needs discovery-time pricing, delegated purchase authority, and machine-scale economics. | An assistant agent purchases office supplies within a delegated monthly budget. |
| 11 | Audit | SCITT and Certificate Transparency are transparency services for periodic high-consequence claims; agent audit needs per-agent per-action attribution at wire speed with delegation-chain preservation. | Investigating a payment that went to a blacklisted supplier, tracing back through the delegation chain. |
| 12 | Governance | Contract law scales through human deliberation; agents transact faster than human review; substrate governance binds agent action to accountable natural or legal persons through legal-instrument-grade evidence. | A commercial dispute where a court must determine whether an agent had authority to bind its principal to the contested terms. |

## How the Primitives Compose

The twelve primitives carry different levels of load and stand in a natural dependency structure. Reading the sections in order (1 through 12) reflects that structure. The relationships are worth naming explicitly so the document reads as a coherent frame rather than as twelve independent essays.

**Identity anchors everything.** Every other primitive references the acting agent's identity. Without identity, no other primitive has a subject.

**Delegation frames authority; Authorization checks specific actions.** Delegation is the framework (established at some earlier time); Authorization is the runtime check on any specific action. Both compose with Identity: authority always attaches to a specific identity, and every runtime check references a specific delegation chain.

**Discovery feeds Trust and Authorization.** Discovery returns candidates. Trust filters them. Authorization checks the specific action. The three compose into every "which agent should perform this action" decision, and all three depend on Identity underneath.

**Communication, Session, and Semantics carry the action.** Communication moves messages between endpoints. Session persists coordination state across time. Semantics defines what messages mean. The three compose into every multi-message coordination and inherit Identity and delegation context from earlier primitives.

**Tools extends the coordination surface.** Tools are substrate participants that use the same Identity, Discovery, Semantics, and Communication primitives as agents, with specific constraints (typically stateless, integrity-critical, capability-first-discoverable). The primitive is uniform addressing rather than a separate protocol stack.

**Commerce composes the earlier primitives around money.** Discovery finds merchants. Trust filters them. Delegation frames purchase authority. Communication carries the transaction. Semantics defines the verbs. Commerce is what the earlier primitives look like when money changes hands, with specific properties (discovery-time pricing, machine-scale economics, substrate-level receipts) that human-oriented payment infrastructure was never designed to serve.

**Audit records everything.** Every primitive produces records; Audit is the substrate primitive that makes those records tamper-evident, cross-verifiable, and usable across organizational boundaries. Audit closes the loop between action and later investigation.

**Governance closes the loop with legal-instrument-grade evidence.** Audit produces attribution: cryptographic evidence that a specific agent performed a specific action under a specific delegation. Governance binds attribution to accountable persons that legal systems can act on. Without Governance, cryptographic attribution stops at the substrate boundary and legal action cannot proceed.

The composition matters for how solution proposals get evaluated. Most proposals address one or two primitives at a time. Reading a proposal against the composition frame makes it easier to see which primitives it depends on, which it provides, and which remain unaddressed.

---

## 1. Identity

### Is agent identity needed?

Every existing category of internet participant has some form of identity. Servers have IP addresses. People have email addresses. Companies have domain names. Phone lines have phone numbers. Employees have employee numbers. In each case, the identity serves a real purpose that the deployment could hardly function without.

Do agents need their own identity primitive? A skeptic could argue that agents are software running on servers, and the server already has an IP address. When agent A calls agent B, the call resolves to an IP, just like every other network call today. Introducing an agent identity layer looks at first like anthropomorphizing software. A background process on a server has no identity of its own; why should an agent process?

The counter-argument is inventory at scale. An organization running one agent can identify it by the server that hosts it. An organization running one thousand agents cannot. A single server may host dozens of agents. A single agent may span multiple servers, or move between servers as infrastructure changes. Without a stable identifier tied to the agent itself rather than to the substrate hosting it, the organization loses the ability to answer basic operational questions: which agents exist, which agent took this action, who deployed it, is it still active, has it been retired.

A related and increasingly common frame is agents as employees. Organizations are deploying agents in roles that used to be performed by humans: analyst, customer service representative, procurement clerk, security monitor. Every human in those roles carries an employee identifier that attaches to HR systems, payroll, access control, badge readers, and performance tracking. Agents performing the same functions inherit the same operational requirements. If an agent behaves organizationally as an employee, the organization needs an identifier for that agent for the same reasons it needs identifiers for its human employees: onboarding, role assignment, action attribution, incident investigation, and eventual retirement.

At small scale, agent identity is optional. At scale, it becomes essential. Every serious agent deployment is heading toward scale.

The answer is yes, agent identity is needed. The reasoning is less about the agent itself and more about the deployment context around the agent: managing large agent populations, or agents in employee-like roles, becomes impractical without a stable per-agent identifier.

### Why it is needed

Agent identity gives operators, users, and receivers the ability to distinguish one agent from another as a first-class fact rather than an inference from context. That simple property makes several practical concerns tractable: knowing which agents exist, tracking what each has done, assigning them to roles, managing the lifecycle of the fleet, and connecting downstream primitives (authorization, delegation, trust, audit) to a stable reference. Every other primitive in this document depends on identity as its anchor. Without identity, the rest of the coordination surface has nothing to attach to.

### The core use case: inventory and workforce management at scale

An organization deploys a thousand agents across its operations. Some handle customer service, some perform procurement, some monitor security, some run research tasks. Each agent takes actions on behalf of the organization. The operator needs to answer basic questions:

- Which agents exist?
- What is each agent supposed to do?
- Which agent performed a specific action?
- When was an agent deployed, updated, or retired?

Without a stable per-agent identifier, none of these questions can be answered reliably. Server names, process identifiers, endpoint addresses, and container instance IDs all change when infrastructure changes. Agent identity provides the stable reference point that lets the organization treat its agent fleet as a manageable inventory rather than a collection of anonymous processes.

Two familiar analogies apply. The first is retail: an online store with a thousand products in its catalog assigns each product a SKU. The SKU carries no other information about the product. It is simply the identifier that lets every other system (pricing, inventory, shipping, returns, analytics) attach cleanly to a specific product. The second is the employee number: when an agent takes on a role that used to be performed by a human, the employee identifier model brings a well-understood management framework with it, including hiring, role assignment, performance review, and eventual separation. Both analogies require the same primitive. An organization treating agents as products, or as workers, or as some combination of the two, needs a stable per-agent identifier before any of the higher-level management concerns can be addressed.

Higher-consequence needs (cryptographic verification, delegation lineage, trust scoring, audit trails) build on this base. Without the base, they cannot be built at all.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Verify which organization created an agent
- Tell two similar agents apart
- Track an agent across infrastructure changes (moved servers, changed cloud provider)
- Attribute a specific action to a specific agent
- Retire an agent while preserving its history
- Enforce the agent's declared role
- Prevent one agent from impersonating another
- Enable one agent to introduce another
- Manage many agents in one organization at once

---

## 2. Authorization

### Is agent authorization needed?

The internet already has substantial authorization infrastructure. OAuth 2.0 handles user-to-service authorization at massive scale. SPIFFE handles workload identity for service-to-service authorization. JSON Web Tokens carry scoped claims. Every enterprise identity system supports role-based and attribute-based access control. Frameworks such as Cedar, OPA, and Zanzibar handle policy evaluation. The general problem of "does this actor have authority to perform this action here" has been the subject of decades of work.

Underneath the standards is an even older pattern. Software has always required authorization to run. Operating systems ask permission before installing a package. Code signing verifies the source. Antivirus and endpoint detection systems watch for software behaving outside sanctioned scope. Every deployment of software in every organization for the last several decades has operated within this pattern: a human owner grants authorization to specific software to run, and monitoring watches for deviation from the sanctioned behavior.

Do agents need their own authorization primitive on top of all of that? A skeptic could argue that agents are software, and the existing model already covers them. An organization installs an agent the same way it installs any other application. A human owner grants the agent access to specific resources through the organization's existing IAM system. The agent runs under those permissions. If the agent misbehaves, existing monitoring catches it. When the agent calls an external service, it presents an OAuth token from the organization's identity provider. Standard stuff. Nothing new required.

Human employees fit the same pattern. Every employee in a company has access rights granted by an authorized human at the company. HR onboarding provisions those rights. The organization's access-control systems enforce them. Employees who exceed their authority are subject to well-established processes. Agent access rights, in this framing, are just another instance of the employee access-rights model. An agent taking on employee-like work inherits the employee-authorization pattern; agents change none of that.

At small scale, this framing holds. A single agent running on a single machine with a single owner presenting a single token to a single receiver looks exactly like traditional software, and traditional software authorization is sufficient.

The counter-argument turns on chains and cross-organization scope. An employee's access rights are scoped to their employer's systems. A given employee never sub-delegates their expense authority to another employee who sub-delegates to a vendor's finance system. Agent deployments do exactly this constantly. A user grants an assistant agent authority to book travel. The assistant delegates to a travel-booking service operated by a different organization. The travel-service delegates to a hotel booking system operated by yet another organization. The chain crosses three organizations in a single agent invocation, and each hop needs authority derived from the original grant.

Three problems emerge as a result. First, existing IAM systems were designed for a single organization's employees and applications, and were never built to carry authority across organizational boundaries in a form receivers can verify locally. Second, receivers cannot call back to every identity provider in the chain for every action; the round-trip cost is prohibitive at agent speeds. Third, and most important, the causal chain of authority (who originally authorized this action, and under what constraints) is lost when each hop presents a fresh token issued in isolation. Cryptographic lineage that survives the crossings is what agent authorization requires and what existing systems lack.

There is also a threat-model dimension. When an agent claims a capability and presents a token, the receiver needs to verify more than the token itself. The chain of authority behind the token must also be trustworthy. A capability claim from an agent whose delegation chain traces back to a legitimate principal is a different risk than a capability claim from an agent whose provenance cannot be established. Existing authorization infrastructure verifies the token; it cannot verify the chain. This is why substrate discovery and substrate authorization are architecturally paired: capability claims without lineage are exactly the attack surface a threat model highlights.

The answer is yes, agent authorization is needed as a primitive distinct from generic scoped tokens and traditional IAM. The primitive must carry chain lineage across organizational boundaries, must be verifiable at the receiver without external callbacks, and must support attenuation across hops. Existing infrastructure is one component of the solution rather than the solution itself.

### Why it is needed

Agent authorization gives receivers a way to answer three questions at the point of action, without calling back to any external service: what is this agent authorized to do here, who authorized it, and where in the chain did the authority originate. That combination is what distinguishes an agent authorization primitive from a generic scoped access token or an employee access right. Without it, receivers must trust the immediately preceding hop and lose all visibility into the causal chain of authority. This is unacceptable for high-consequence agent actions such as spending money, executing transactions, or modifying critical state, especially when the chain crosses organizational boundaries and adversarial capability claims are a real risk.

### The core use case: bounded delegation with a paper trail across organizations

An organization gives an assistant agent authority to spend up to $500 per month on travel booking for a specific employee. The assistant discovers that the best available package requires booking through a travel-service operated by a different company, which in turn needs to reserve a specific hotel from a hotel chain and a specific flight from an airline. Three organizations are now in the chain: the assistant's employer, the travel-service, and the hotel chain (the airline is a fourth). The trip proceeds. A month later, the employee's finance team reconciles the corporate card statement and sees a hotel charge for $237. Their job is simple: verify that this charge was authorized, connect it to the delegation that authorized it, and confirm the monthly total remains within the $500 cap.

That simple job is where existing infrastructure breaks down. The corporate card statement shows a merchant name (the hotel) and an amount. Nothing on the statement connects the charge back to the assistant that initiated the booking, the delegation that authorized the assistant, or the $500 monthly ceiling that scopes the delegation. To answer the finance team's question, someone has to email the travel-service vendor to request the booking record. That record references the assistant agent that submitted the booking. To confirm the assistant's authority, someone has to check with the internal agent management system. To confirm the running monthly total, someone has to aggregate charges across every vendor the assistant used that month. What should be one query becomes three phone calls and several days of reconciliation.

OAuth and IAM handle the credential problem at each boundary but lose the causal chain at every hop. When the travel-service requests a hotel reservation on the assistant's behalf, the hotel booking system receives an OAuth token from the travel-service that says "this token is authorized to reserve hotel rooms up to a specific ceiling." The token carries no information about which employee's monthly budget this reservation should draw from, whose approval structure authorized it, or how the reservation relates to any parent authority. Each token is internally consistent within its scope. The chain from the employee's delegation to the assistant to the travel-service to the hotel is severed at every boundary. From the substrate's perspective, four separate authorization events happened, each valid in isolation, none causally connected to any other.

The paper trail is what makes corporate spending authority work at scale in the pre-agent world. A purchase order references its parent approval; the parent approval references the budget line; the budget line references the approved plan. Any auditor examining a specific charge can walk backward through the chain and verify that the charge is within authorized bounds at every level, without needing to call the vendors involved. Agent authorization needs the same property at wire speed, and it needs to work across organizational boundaries where the parent authorization was granted in one system and the child action was enforced in another. Substrate authorization carries the causal chain end-to-end, so the finance team's reconciliation is one query against substrate records rather than three phone calls to three vendors.

Human employee access rights avoid this problem because human employees rarely chain their spending authority across three organizations in one action; when they do, they file expense reports that manually reconstruct the chain. Software authorization avoids this problem because software runs within the boundaries of a single operating system's permission model. Agents cross both boundaries constantly and at machine speed. The primitive is needed for the specific case that emerges when both scale and chained cross-organization delegation are present, and the case is common in every serious agent deployment.

Higher-consequence needs (attenuation semantics, revocation propagation across the chain, cross-organization delegation with different trust anchors, verification against a threat model) build on this base. Without the base, delegation between agents at scale reduces to a chain of independently issued tokens with no causal linkage between them, which fails as delegation in any meaningful sense.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Check whether an agent may perform a specific action
- Preserve the chain of who authorized what across organizational boundaries
- Revoke an agent's authority
- Check cumulative spending against a budget cap
- Delegate authority for a specific type of action
- Delegate a narrower authority than the delegator holds
- Set an authority to expire at a specific time
- Check whether an authorization is still current
- Verify authority without contacting the original authorizer

---

## 3. Delegation

### Is agent delegation needed?

The word "agent" itself embeds the concept of delegation. An agent is one who acts on behalf of another. That relationship, someone asking someone else to perform a task, is delegation. Without delegation, an entity is software executing its programmed code without direction. With delegation, it becomes an agent operating within a principal's mandate. Delegation is what makes an entity an agent at all.

Delegation is well-understood in human affairs. Corporate officers delegate authority to subordinates. Power of attorney lets one person act on another's behalf. Real estate agents are delegated to sell houses. Attorneys are delegated to represent clients. In software, OAuth delegated authorization is one of the most successful protocols on the internet, letting a user grant a service permission to act within specific scopes.

The Authorization section argued that agent authorization must carry chain lineage across organizational boundaries. That argument covered much of what agent delegation looks like at runtime. So do agents really need a separate Delegation primitive on top of the Authorization primitive we just established?

A skeptic could argue no. If Authorization already handles chain lineage and attenuation, then delegation is just the shape authorization takes when multiple hops are involved. Combine the two, reduce complexity, and call it done.

The counter-argument is that delegation and authorization operate on different axes. Delegation is the act of asking. It answers "who asked whom to do this, and for what purpose?" Authorization is the check on permission. It answers "may this specific action happen here, now, in this context?" Delegation is universal for agents; every action an agent takes was delegated to it by someone. Authorization is context-dependent; different actions require different levels, and some actions require none at all.

A concrete example makes the distinction plain. When a personal assistant agent searches public news articles at its principal's request, no authorization is needed (the information is public), but the search still exists because someone asked for it. The delegation is present; the authorization is absent. When the same agent purchases a subscription to a paywalled service using its principal's credit card, both delegation and authorization are present. When the agent, without being asked, begins purchasing subscriptions to random services, neither delegation nor authorization is present, and the agent has stopped acting as an agent at all.

The distinction can be captured in a two-by-two matrix showing how delegation and authorization combine across possible action types:

|                | Authorization required                                                                | No authorization required                                                              |
| -------------- | ------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| **Delegated**   | Legitimate agent action, receiver checks permission before proceeding                 | Legitimate agent action, no permission check needed                                    |
|                | *Agent purchases a paywalled subscription using principal's credit card*              | *Agent searches public news at principal's request*                                    |
| **Undelegated** | Attempted action outside any mandate, receiver should block                           | Software executing code with no principal directing it                                 |
|                | *Entity attempts purchase without being asked; the receiver's authorization check fails* | *Software running without direction; no agent behavior taking place*                   |

The two axes are independent. Agent behavior appears only in the top row: some agent actions require authorization checks, others require none, but every agent action is delegated. The bottom row shows either attempted actions that fall outside any mandate (which receivers should block) or entities that are simply running code with no principal directing them (which lies outside agent behavior entirely).

The real-world parallel makes the axis distinction clearer. A real estate agent has been delegated to sell your house. The delegation is broad: represent you in negotiations, arrange showings, coordinate with buyers. Within that delegation, various actions require various levels of authorization. Some require your explicit sign-off (accepting a specific offer). Others require none (showing the house to interested buyers). Some are prohibited regardless of your delegation (misrepresenting material facts, discriminating against buyers based on protected classes). Delegation opens the door to a range of actions. Authorization determines which specific actions within that range are permissible in specific contexts. The two operate on distinct axes.

Attorneys work the same way. You delegate an attorney to represent you in a matter. Within that delegation, they take many actions (drafting filings, communicating with opposing counsel, making tactical decisions). Some require your specific authorization (settling the case, waiving privilege). Some are automatic within the delegation (routine communications). Some are prohibited regardless of your instructions (subornation of perjury, disclosure of privileged information). Delegation and authorization together produce the space in which the attorney legitimately acts.

Beyond this axis distinction, four specific cases require delegation as a distinct concern that authorization alone cannot cleanly express:

**Pre-authorization.** Grant authority for future actions when the principal will be unavailable. "My assistant may approve invoices under $500 while I am on vacation for the next two weeks." This is delegation established in advance, rather than authorization at the point of action.

**Conditional delegation.** Grant authority that activates based on future events. "If a hotel booking exceeds my monthly cap, my agent may charge the excess to my personal card." The condition is baked into the delegation contract; the receiver evaluates it at runtime against the framework the principal established earlier.

**Transitive delegation.** Grant the right to sub-delegate. "The service I invoke may in turn invoke other services on my behalf, provided each sub-delegation is bounded by the same purpose." Authorization handles a single action. Delegation of delegation is a separate governance decision about who else may act within the frame.

**Temporal and purpose scoping.** Frame authority by time window and purpose rather than by specific action. "For the purpose of managing my child's tuition over the next four years, my agent may authorize related transactions." Purpose scoping cannot be expressed as a list of allowed actions; it requires a framing statement that receivers evaluate case by case.

At small scale, delegation and authorization can be conflated because a single principal typically delegates a single agent to perform a single well-scoped task, and the authorization check reduces to "did the principal actually delegate this?" At scale, with agents delegated for broad purposes across time, delegating to sub-agents, and operating across organizational boundaries, delegation becomes a distinct governance primitive that establishes the frame within which authorization operates.

The answer is yes, delegation is needed as a primitive distinct from authorization. Delegation is the constitutive act that makes an entity an agent, and it operates on a different axis from the authorization check that governs specific actions within the delegated frame.

### Why it is needed

Agent delegation gives principals a way to grant a purpose to an agent, an ongoing mandate to act on the principal's behalf, that persists across time and across many specific actions. Authorization tokens can encode point-in-time permissions for specific actions. Delegation encodes the relationship itself: who delegated whom, for what purpose, with what scope, for how long, and with what conditions on further sub-delegation. Every agent action inherits its purpose from a delegation contract. Authorization checks apply variably depending on the action, but delegation is present in every case. Without delegation as a distinct primitive, agent systems lose the ability to distinguish "acting on behalf of X for purpose Y" from "software running without direction that happens to comply with Y."

### The core use case: pre-authorized action while the principal is unavailable

An executive is leaving on a two-week international trip. During the trip, they will be reachable intermittently but cannot respond to every routine request in real time. They want their assistant agent to keep operations moving without requiring live approval for each action. Before departing, they set up a delegation to the assistant agent that covers:

- Approval of vendor invoices under $2,000 that match previously approved contracts
- Response to project inquiries from known partners
- Scheduling of meetings for after the return date
- Sub-delegation to the accountant's agent for tax-deadline items

This is more than a single authorization. It is a governance act that establishes a framework within which many future authorizations can be evaluated. The delegation records:

- Who is delegating (the executive's identity, cryptographically bound)
- Who is being delegated to (the assistant agent's identity, cryptographically bound)
- What is being delegated (a purpose-scoped set of actions with specific limits)
- When it applies (start and end dates, plus conditional activation rules)
- What sub-delegations are allowed (accountant's agent for tax items, no further)
- How to revoke it (a signed withdrawal that propagates to receivers within a bounded time)

Each specific action the assistant agent takes during the delegation window is subject to authorization checks at receivers where applicable. The receiver evaluates the action against the delegation framework: does the vendor invoice match a previously approved contract? Is the invoice under $2,000? Is the current date within the delegation window? Has the delegation been revoked? All of these questions read the delegation contract established in advance. Some actions during the window require no authorization at all (responding to a general project inquiry, forwarding a public status update), but every action is still delegated: the assistant is acting because the executive asked it to, for a purpose the executive defined.

The corporate analog is direct. When a CEO leaves the office on an extended trip, they typically issue a delegation of authority to a specific officer for specific decisions during the absence. The delegation is a formal act, often documented, often bounded by specific limits and purposes. When the officer signs an approval during the CEO's absence, that signature is authorized by the pre-established delegation. Within the same delegation, the officer takes many actions that require no separate authorization at all: coordinating with staff, following up on prior commitments, communicating with vendors within the delegated scope. Both the delegated actions requiring authorization and the delegated actions requiring none are legitimate expressions of the delegation.

Human employees rarely need explicit delegation primitives at agent scale because human employees typically operate under well-defined roles with pre-existing authority granted through HR processes. When employees exceed their normal authority, they route through explicit approval workflows. Software rarely needs delegation primitives because software runs under the account that installed it and inherits that account's permissions statically, with the software itself having no independent purpose beyond executing its code. Neither model handles the case of an agent operating during a principal's unavailability, with pre-authorized bounded authority that spans time windows and conditional activation, where every action inherits its legitimacy from the initial delegation act. That case is common in agent deployments and grows more common as agents take on employee-like responsibilities that require operating during off-hours, weekends, and vacations.

Higher-consequence needs (cryptographic delegation contracts with legal-instrument weight, revocation propagation across long delegation chains, delegation of the right to delegate under bounded conditions, purpose-scoped authority that outlives specific sessions, cross-organization delegation with different trust anchors) build on this base. Without the base, agent action during principal unavailability reduces to either "the agent cannot act while the principal is offline" or "the agent acts without meaningful bounds," both of which fail the practical requirements of real agent deployments.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Establish authority for an agent to act on someone's behalf
- Delegate while the principal is unavailable (traveling, in surgery, off-duty)
- Delegate for a specific period of time
- Delegate with scope constraints (what the agent may do)
- Delegate with conditional triggers (only if X)
- Create sub-delegations (one agent delegates to another)
- Transfer a delegation to a different agent
- Revoke a delegation before it expires
- Delegate narrower authority through sub-delegation
- Handle delegation when the principal changes (retirement, transfer)

---

## 4. Trust

### Is agent trust needed?

Trust in software systems has a long history. Public key infrastructure uses certificate authorities to verify identity and by extension to establish a chain of trust. TLS certificates encode a trust path from the browser to the site. Code signing lets recipients verify that software comes from a claimed source. Reputation systems on major platforms (eBay ratings, Yelp reviews, Amazon reviews, GitHub stars) let users evaluate whether a specific product, service, or repository is worth engaging with. Insurance ratings agencies produce standardized measures of firm-level trust for the financial sector. Credit bureaus produce standardized measures of individual-level trust for consumer lending.

Do agents need their own trust primitive on top of all of that? A skeptic could argue no. PKI already verifies identity: the agent's certificate proves who it is. Reputation systems already exist for evaluating services: an application can look up the agent's rating on whatever platform tracks it. Trust is subjective anyway; it belongs at the application layer where product decisions live, rather than at a coordination substrate. Combining existing PKI infrastructure with application-layer reputation covers the trust problem.

The counter-argument is that identity and trust answer different questions. Identity answers "who is this?", a factual question about the entity's origin that cryptographic verification can settle definitively. Trust answers "how much should I believe them?", a question about the entity's likely behavior that evidence can inform but never fully settle. Both are necessary; neither substitutes for the other. Knowing that an agent is authentically issued by Company X reveals nothing about whether Company X's agents behave reliably. Knowing that an agent has good reviews on one platform reveals nothing about whether it behaves the same way in a different context.

Application-layer reputation systems fail for agents at scale for four reasons:

1. **Duplication.** Every application reinvents trust independently. Yelp scores mean nothing on eBay. Amazon reviews mean nothing on GitHub. There is no portable trust measure across contexts.

2. **Non-portability.** An agent's reputation in one marketplace fails to follow it into another. A well-behaved shopping agent has to earn its trust from scratch every time it moves into a new domain, which fails to scale to millions of agents operating across many contexts.

3. **Manipulability.** Application-layer reputation is prone to abuse: fake reviews, sybil attacks, purchased ratings, coordinated brigading. Without a substrate-level trust primitive with cryptographic backing, reputation is only as reliable as the platform enforcing it.

4. **Adversarial threat model.** A recent public observation captured the concern precisely: capability claims from agents immediately raise security questions about whether an agent that says it can do something can actually be trusted to do it. Capability claims without a trust primitive underneath are exactly the attack surface. A receiver needs some way to evaluate whether a claimant's capability claim is worth acting on before granting access.

The credit score analogy is direct. A credit score is a standardized, portable, graduated trust measure computed from multiple verification paths (payment history, credit utilization, length of history, credit mix). It carries a graduated value along a defined range. It is fresh. Lenders make consistent, automated decisions using it across the industry. Consumer credit worked poorly before credit bureaus produced this substrate; every lender had to independently assess trustworthiness with limited information. Agent trust is currently in the pre-credit-bureau state: every application must independently assess whether an agent is worth engaging with, using inconsistent evidence.

The threat model dimension makes the primitive urgent. Discovery returns candidates. Authorization checks specific actions. But between the two, some evaluation must happen: which candidates are worth authorizing? Without a trust primitive, that evaluation either happens per-application (duplicated, non-portable) or fails to happen at all (blind acceptance of all discovered candidates). Neither result is acceptable at scale, and neither result is defensible under an adversarial threat model.

The answer is yes, agent trust is needed as a primitive distinct from identity and from application-layer reputation. The primitive must be substrate-level (portable across contexts), verifiable at the receiver (without callbacks), graduated (a value along a defined range rather than binary), and fresh (bounded staleness on trust state).

### Why it is needed

Agent trust gives receivers a standardized way to evaluate whether a claim (of capability, of behavior, of intent) is worth acting on. Identity gives you a name; trust gives you a measure. Authorization gives you scope; trust gives you the evidence to decide whether the scope is worth granting. Delegation gives you the mandate; trust gives you the evidence that the mandate is being executed by a party worth mandating. Every subsequent coordination decision reads trust as an input, even when the decision itself is called something else. Without trust as a distinct primitive, coordination reduces to either blind acceptance of claims (which fails under adversarial conditions) or wholesale rejection of new relationships (which fails to scale beyond hand-curated allowlists).

### The core use case: selecting a trustworthy agent from many claimants

An individual needs an agent to help with tax preparation. They query the substrate and receive twenty agents that claim tax preparation capability. Some are legitimate services with strong track records. Some are inexperienced but honest. Some are outright fraudulent, seeking to harvest sensitive financial data or provide deliberately wrong advice. The individual must decide which agents are trustworthy enough to hire.

Without a trust primitive at the substrate:

- The individual must independently research each agent, reading reviews on whichever platform tracks that agent, checking certifications manually where they exist, and relying on out-of-band signals like domain reputation and word of mouth.
- Each research effort is duplicated for every new agent the individual considers, and none of the research is portable to the next selection decision.
- Fraudulent agents can present professional-looking certificates, buy fake reviews, and appear on paid rating lists. The signal-to-noise ratio is poor.
- The individual has no reliable way to distinguish "verified by an independent authority" from "self-asserted."

With a trust primitive at the substrate:

- Each agent carries a trust score computed from multiple verification paths: professional certification (CPA firms verified by state boards), operational track record (previous transactions logged in transparency logs), independent verification (industry associations that audit member behavior), and organizational backing (which company owns the agent, and what is that company's own trust profile).
- The score is standardized, graduated, and portable. A tax-preparation agent with a high score is trustworthy in the same measurable way regardless of which application queries.
- The individual can filter at discovery time: "return only tax-preparation agents with a trust score above X and freshness within Y hours."
- Fraudulent agents can still appear in the marketplace, but their trust scores reflect the absence of independent verification. The individual sees the difference at discovery time, before granting access, before delegating any authority.

The credit score parallel makes the primitive concrete. A consumer applying for a mortgage rarely researches the lender's assessment methodology themselves. The lender pulls the credit score, applies its own thresholds, and decides. The consumer receives a standardized offer based on a standardized measure. Both parties benefit from a substrate-level trust primitive that no individual application had to build.

The corporate analog is vendor selection. When a company evaluates a new vendor, it uses standardized signals: financial ratings (S&P, Moody's), industry certifications (ISO 27001, SOC 2), insurance ratings, and reference checks. Each signal comes from an independent authority. The evaluation combines them into a decision. Agent trust needs the same properties at wire speed: multiple standardized signals, independent verification, portable across contexts, graduated in value.

Human employees rarely need this specific primitive because the employment relationship itself carries trust context. The employer has HR records, references, background checks, and ongoing performance data. Employees who behave poorly are subject to disciplinary process. Software rarely needs this primitive because software is typically installed by an authorized human who has already made the trust decision at install time. Neither model handles the case of agents encountering each other across organizational boundaries with no prior relationship. That is the common case at scale, and it is the case Trust addresses.

Higher-consequence needs (trust score computation methodology, revocation of trust across multiple verification paths, cross-domain trust anchor composition, trust for anonymous or pseudonymous agents, adversarial-resistance guarantees against sybil and manipulation attacks) build on this base. Without the base, agent coordination at scale reduces to either "trust everyone by default" (which fails immediately under adversarial pressure) or "trust nothing" (which fails to scale beyond hand-curated allowlists).


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Decide whether a capability claim is worth acting on
- Filter search results by trust tier at query time
- Detect reputation manipulation (fake reviews, sybil attacks)
- Combine multiple verification paths into one score
- Require a minimum trust level for certain classes of action
- Downgrade trust when behavior degrades
- Verify certification claims against issuing authorities
- Carry trust across contexts (portable trust)
- Handle trust decay over time
- Tell verified claims apart from self-asserted claims

---

## 5. Discovery

### Is agent discovery needed?

The internet has one dominant discovery mechanism: the Domain Name System. DNS is decades old, universally deployed, and works. Every service on the internet today is discoverable through DNS. A client that knows a domain resolves it to an address and connects. Extensions have accumulated over time: SVCB and HTTPS records for service binding, TXT records for arbitrary metadata, DNSSEC for integrity, DANE for trust anchoring, TLSA records for certificate binding, well-known URI conventions for structured metadata under a domain. Agents are software running on servers; servers live under domains; DNS resolves domains. If agents need to be discovered, extend DNS.

Do agents need their own discovery primitive on top of all of that? A skeptic could argue no. Point DNS records at the agent's endpoint. Publish agent metadata under a well-known path. Use DNSSEC to prove integrity, DANE to anchor trust. This is a well-understood pattern. Nothing new required.

The counter-argument turns on what DNS was designed to answer. DNS answers one specific question: "given a name, find an address." Agent deployments frequently need to answer questions DNS was never designed to serve:

- **Capability-based lookup.** "Given a task I need done, find agents that can do it." The requester has no name to look up. They have a need.
- **Attribute-based filtering.** "Find agents in this industry, in this region, at this trust tier, within this price range." The requester has constraints rather than a name.
- **Identity-first resolution.** "Given a stable Agent-ID that survives infrastructure changes, find the agent's current endpoint." The requester has an identity; DNS resolves names to addresses, but when the agent's identity takes any form other than a domain name, DNS has no place to start.

These are three different questions. DNS handles the first (given a name) well. It handles the next two awkwardly, through extensions and conventions that were bolted on rather than designed in. At small scale, the awkwardness is manageable. At scale, with millions of agents crossing organizational boundaries and needing to be found by capability rather than by name, the paradigm strains.

There is a deeper paradigm assumption most discovery discussions inherit without examining. DNS-first discovery is a publishing model. A domain owner must actively configure records for the agents they want to expose. Nothing is discoverable until someone publishes it. Discovery is a lookup against what someone published. If a domain owner never publishes a record for a given agent, the agent is invisible to DNS-based discovery, regardless of the agent's actual capabilities. And DNS-first discovery treats the domain (or the IP address underneath it) as the primary addressable entity. The agent is a service running under a domain, and the domain is what participants discover, verify, and connect to. When the agent moves between domains (moves companies, changes hosting, gets deployed to a new region), its identity dissociates from its history. Every downstream primitive (identity, authorization, delegation, trust, attribution) has to be reconstructed under the new domain.

Agent-native discovery inverts both assumptions. The Agent-ID is the primary addressable entity. Endpoints and domains are secondary lookup results: they are where the agent currently is, rather than what the agent is. When the agent moves between hosting environments, the Agent-ID persists, and the discovery lookup returns the new endpoint. Identity survives infrastructure change. Every downstream primitive continues to attach to a stable reference. And agents carry metadata about themselves (capabilities, attributes, availability, credentials, trust indicators) as intrinsic properties of the Agent-ID. Discovery becomes scanning and filtering across intrinsic metadata rather than looking up what was published. Adding an agent to the ecosystem makes it discoverable by its properties automatically, without a separate publishing step.

Four specific problems with DNS-first discovery become visible once these paradigm assumptions are named:

1. **No starting-domain problem.** DNS requires a domain to begin. A client that has no domain (a client wanting to find translation agents worldwide, or a client responding to an intent from an anonymous principal) has no place to start. DNS answers the domain-anchored case cleanly and has no answer for the domainless case.

2. **Central-registry paradox.** Cross-organization capability search requires an index of agents by capability. If the index is centralized, it is a single point of control and failure. If the index is federated, no single query has global reach. Existing DNS-based proposals wrestle with this and the wrestling never fully resolves, because DNS was designed around domain hierarchies rather than capability partitions.

3. **Domain-bound identity.** An agent identified by a domain name inherits the domain's history: certificate authorities, DNSSEC anchoring, historical records. Move the agent to a different domain and its identity is a new identity as far as the receiver can tell. Identity should survive infrastructure change; DNS-first identity fails that test.

4. **Static endpoint assumption.** DNS records point to addresses. Agents may move between addresses frequently, may run across multiple addresses simultaneously, may operate through relays and rendezvous points without a stable directly reachable endpoint at all. DNS handles static endpoints natively; dynamic and relay-mediated endpoints require workarounds.

At small scale, DNS-based discovery is sufficient. An organization publishing agents under its own domain, expected to be discovered by clients that know the domain, gets everything it needs from DNS extensions. At scale, with agents crossing organizational boundaries, discoverable by capability rather than by name, and requiring identity that survives infrastructure change, DNS-based discovery reaches its limits.

Four analogies from familiar systems make the design gap concrete. Each one shows a different aspect of what agent discovery needs.

**Yellow Pages.** Before the Yellow Pages, finding a plumber in an unfamiliar city required knowing a plumber by name, or driving around looking for signs. The White Pages offered no help: they were organized by name, and a client with no name had no way in. The Yellow Pages introduced capability-based lookup: plumbers listed themselves under a category, and any client with the need "I need a plumber" could find candidates without knowing any specific plumber's name. The Yellow Pages never replaced the White Pages; both existed side by side because they served different discovery patterns. DNS is the White Pages of the internet. What agents need at scale is the Yellow Pages equivalent alongside it: capability-based lookup that complements name-based lookup rather than replacing it.

**Filesystems.** When a file is added to a filesystem, the filesystem indexes it automatically. Search operations work across intrinsic file metadata: name, type, size, date, tags, extension, and content on filesystems that support content indexing. The file carries the metadata that makes it findable. The user never separately publishes the file to make it discoverable; the user adds it, and the filesystem discovers it. Compare this with a newspaper classified ad: an item is unfindable until the owner publishes an ad describing it. If the owner never publishes, the item stays invisible to buyers, even if it exists and would match a buyer's criteria perfectly. DNS follows the classified-ad model. Agent discovery can follow the filesystem model.

**Music libraries.** When a song is added to a music library, the library scans its metadata tags (artist, album, genre, year, duration, custom labels) and organizes the song into playlists, filters, and search views automatically. The song carries the descriptors that make it discoverable. The user never separately registers the song's genre with a directory service; the genre is intrinsic to the file. Music libraries work because the metadata travels with the media, so adding one song makes it findable through every attribute the metadata expresses. Agent-native discovery can work the same way: metadata about an agent travels with the agent, and adding an agent to the ecosystem makes it findable through every attribute the metadata expresses.

**Email spam filtering.** Much of the email arriving in any given inbox is illegitimate. Spam arrives in inboxes constantly, and on any given day the volume of spam may exceed the volume of legitimate messages. Yet users successfully sort through email because a trust score, in the form of a spam filter, sorts most of the spam automatically. Trusted senders bypass filters. Unknown senders receive intermediate scores. Known bad actors get blocked outright. The receiver only sees messages worth considering. Agent discovery with a substrate trust primitive works the same way: the substrate returns candidates, the trust score filters most of the spam, and the individual sees only candidates worth considering. Without a substrate trust primitive at discovery time, every application must build its own spam filter for agents, and every user must inspect every candidate individually.

The answer is yes, agent discovery is needed as a substrate primitive distinct from DNS. It must support:

- Name-based lookup (given an Agent-ID, find the current endpoint)
- Capability-based lookup (given a task need, find agents that can perform it)
- Attribute-based filtering (industry, region, trust tier, price range, availability)
- Identity-first architecture (Agent-ID as primary, endpoint as secondary, identity persists across infrastructure change)
- Intrinsic metadata (agents carry their descriptors with them, so discovery scans and filters across intrinsic properties rather than against a separately published registry)

### Why it is needed

Agent discovery gives principals a way to find agents that fit their needs, whether the principal already knows the specific agent they want or has only a task and criteria. Traditional DNS handles name-based lookup well. It handles capability-based lookup awkwardly, attribute-based filtering worse, and identity-first resolution barely at all, and it operates entirely within a publishing model that requires domain owners to configure each exposure. Every other primitive in this document depends on discovery working: authorization requires knowing the target, delegation specifies who is being delegated to, trust evaluates candidates, communication needs an endpoint. Discovery is the gateway to every coordination act that follows. Without a substrate primitive that supports lookup across all five discovery patterns, coordination at scale reduces to what DNS can express, and DNS was designed for a different problem.

### The core use case: finding capable agents in an open market

An individual needs help with a specific task, such as translating a legal document from Japanese to English with attention to jurisdiction-specific terminology. They have a clear need with clear criteria: language pair, subject specialization, price range, delivery timeline. They have no specific translation agent in mind. They have no starting domain to query. They have never used a translation agent before.

Without agent discovery at the substrate:

- The individual searches the general web for translation services, sifting through advertisements, seo-optimized pages, and unrelated results.
- Each translation service is discovered independently through its own website. Comparing across services requires visiting each one in turn.
- Trust signals differ across sites. One site displays reviews from one platform; another displays certifications from a different body; a third has neither.
- Cross-organization filtering (agents that specialize in legal Japanese-English translation, priced under a specific ceiling, delivering within a specific timeline) requires reading through many sites manually and holding the criteria in memory.
- The individual has no way to filter by trust tier or by verified capability at query time. Filtering happens after the fact, once the individual has already committed attention to specific candidates.

With agent discovery at the substrate:

- The individual queries the substrate with the criteria directly: "capability: legal-translation, language-pair: ja-en, trust tier: verified or better, price ceiling: $X per page, delivery: within Y days."
- The substrate returns a candidate list of agents that satisfy the constraints. The list may include agents from many different organizations, each identified by a stable Agent-ID rather than by domain.
- Each candidate carries the metadata needed to compare: capability description, verified attributes, current trust score, pricing, availability. The metadata travels with the agent; the substrate scans and filters across it.
- The individual filters, compares, and selects from the candidates without visiting individual websites first. The final selection is made against a normalized view of the market, rather than against whichever candidates showed up in a search-engine ranking.
- The trust score filters most of the low-quality and adversarial candidates before the individual sees the results, in the same way an email spam filter sorts inboxes.
- If a selected agent later moves organizations, the Agent-ID persists. The individual's prior interactions with the agent remain attached to the identity that survived the move.

The restaurant-evaluation pattern is a familiar version of the same trade-off. Given two nearby restaurants, one averaging 3 stars and one averaging 5 stars, most people pick the 5-star option. But volume matters: a restaurant with 500 reviews averaging 3 stars tells a different story than a restaurant with 10 reviews averaging 5 stars. The first has broad evidence at a modest average; the second has thin evidence at a high average. Price factors in as well: a 4-star restaurant at $50 per person compares differently against a 5-star restaurant at $20 per person than either compares against the other in isolation. Humans make these multi-dimensional evaluations regularly and instinctively. Agent discovery needs to support the same evaluation model at wire speed. When Agent A offers a capability at a 5-star trust tier and Agent B offers the same capability for free at a 2-star trust tier, the requester should see capability, trust, price, and evidence volume side by side rather than being forced to select on any single axis. Discovery that returns candidates with intrinsic metadata across multiple dimensions is what makes this evaluation possible.

The corporate analog is B2B procurement. When a company needs a new vendor for a specific service, the procurement team begins without a specific vendor name in mind. They begin with a capability need, a set of constraints (budget, region, compliance regime, certifications), and a criteria list. They query business directories, industry associations, procurement databases, and request-for-proposal networks. Each of these is a form of capability-based discovery: given a need with attributes, return qualified providers. The procurement team then evaluates the candidates against additional criteria (trust, history, references) before selecting a vendor. Agent discovery needs the same properties at wire speed: capability and attribute-based lookup that returns qualified candidates, each carrying enough metadata to support comparison, before any specific relationship is established.

Human employees rarely need agent-scale discovery because they operate within a fixed set of known peers inside a bounded organization. When they need to find someone with a specific skill, they ask a manager or check an internal directory. Software rarely needs agent-scale discovery because software is typically installed with its dependencies pre-configured and its endpoints hardcoded. Neither model handles the case of an entity needing to find capable counterparts across organizational boundaries with no prior relationship. That is the common case at agent scale, and it is what discovery addresses.

The DNS-first approach works cleanly when the requester knows the domain and the domain owner has published a record for the specific agent. It works less cleanly when the requester has only a capability need, works less cleanly still when the agent has no fixed domain or has changed domains, and fails entirely when the agent has metadata that the domain owner never published to DNS. Agent discovery inverts the primary entity and the discovery model together: Agent-ID becomes the addressable substrate identity, and metadata travels with the agent rather than being separately published. This inversion is what enables capability-based lookup at scale, identity persistence across infrastructure changes, cross-organization search without a central registry, and adversarial filtering at query time rather than after the fact.

Higher-consequence needs (adversarial discovery under spam and impersonation pressure, cross-domain federation of discovery substrates, discovery of agents behind relays and rendezvous points, freshness guarantees on capability advertisements, coordination between substrate discovery and application-layer capability descriptions) build on this base. Without the base, agent coordination at scale reduces to whatever DNS-based patterns can express, and the patterns fall short in exactly the ways that matter most as agent populations grow.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Look up a specific agent by Agent-ID (name-based lookup)
- Look up an agent by domain (domain-based lookup)
- Find agents that can solve a specific type of problem (capability-based lookup)
- Find agents matching multiple attributes (region, language, industry)
- Find tools with specific capabilities
- Find agents that can invoke specific tools
- Filter results by trust tier
- Filter results by price ceiling
- Filter results by availability window
- Discover agents that operate through relays (no fixed endpoint)
- Discover agents carrying specific certifications
- Refresh discovery results as metadata changes

---

## 6. Communication

### Is agent communication needed?

The internet has robust communication infrastructure. HTTP handles request-response for the web. WebSockets provide bidirectional streams. gRPC delivers structured RPC with type safety. MQTT handles publish-subscribe for IoT and telemetry. SMTP handles asynchronous messaging. TLS secures everything at the transport layer. JSON and Protobuf handle structured data serialization. Every communication pattern in common use is already covered by a well-supported standard. Agents today use these protocols directly. MCP runs on HTTP. A2A runs on HTTP. ACP runs on HTTP. The current agent ecosystem is built on the existing communication stack, and the stack works.

Do agents need their own communication primitive on top of all of that? A skeptic could argue no, and the case is stronger than it first appears. The current agent ecosystem is the proof of concept. MCP, A2A, and ACP all run on HTTP. All have working implementations. All have growing production use. HTTP's request-response model already handles most coordination patterns. WebSockets extend it to bidirectional streams within the same session model. JWT tokens carry attribution. Cookies persist session state. MIME types have handled multi-modal content for decades. Rather than invent a new coordination substrate that would fragment the ecosystem further, the skeptic argues, standardize conventions on top of HTTP: publish an "agent coordination conventions" specification, define headers for attribution and delegation, adopt JSON schemas for messages. Every runtime already has HTTP client libraries and JSON parsers. The path of least fragmentation is to build on what already works.

The counter-argument earns its ground precisely because the skeptic's case is strong. HTTP does work. Existing agent stacks do have real ecosystems. Building on HTTP is a defensible direction. The problem shows up when the ecosystem grows.

The interoperability tax has a specific shape. Every agent stack that exists today has its own conventions for the coordination primitives that HTTP omits natively: attribution, delegation lineage, session context, semantic verbs, multi-modal binding. MCP has one convention set. A2A has another. ACP has a third. Each set is internally coherent, defined by its authors for its specific ecosystem. Across stacks, an agent from one stack has to bridge to reach an agent from another. Adding a new stack multiplies the translation surfaces: to add stack N, integrations must be built against each of the existing N-1 stacks. The burden grows as N times M for N stacks interacting with M other stacks. This is exactly the quadratic scaling problem HTTP itself avoided at the web layer. HTTP made web coordination possible because every client and server implemented HTTP the same way. Every convention set built on top of HTTP recreates the pre-HTTP fragmentation, just one layer higher.

The deeper architectural point is that HTTP was designed for a different primary payload. HTTP is a content substrate. Its primary payload is documents intended for human consumption. Its content types (HTML, images, video files, PDFs), its caching semantics, its content negotiation, its status codes for resource state (success, redirect, missing resource, server error), and its methods (GET, PUT, POST, DELETE) all serve that purpose. HTTP was designed to move documents from servers to browsers, and the browser renders the document for a human.

Agent communication has different primary needs. The primary payload is intent (what the sender wants to accomplish) plus context (what the receiver needs to fulfill it), rather than content for a human to read. The interaction is bidirectional coordination between two software entities that both understand structured messages, rather than one-way content delivery to a human interface. Attribution matters at every message because both parties are acting on behalf of other principals, and the chain of delegation must remain visible. Multi-modal payloads (voice, video, structured data streams, text) appear alongside message exchange for coordination purposes, rather than as content packages to be delivered.

The pattern shows up whenever a general-purpose protocol is stretched to serve a specialized coordination need. Email over the postal service works, but it stretches paper mail beyond what the postal service was designed to do. Voice over telegraph works, but it stretches telegraph beyond dot-dash. Both of those cases produced dedicated protocols (SMTP for email, phone networks for voice) once the specialized use case grew large enough to justify a purpose-built layer. Agent coordination is now at that scale.

Consider the postal service parallel more directly. The postal system carries envelopes between addresses. Every envelope has attribution (sender address, recipient address), delivery guarantees (first class, certified, express), and coordination properties (return receipts, tracking numbers). The envelope structure is the coordination primitive; the letter inside is the content. The postal service works because both the envelope and the delivery process are purpose-built for the coordination need. If someone tried to deliver mail by attaching letters to newspaper delivery trucks (a content-delivery substrate for newspapers), it would work at small scale, break down at any real volume, and force senders and receivers to reconstruct addressing and delivery reliability at the application layer.

HTTP is the newspaper delivery truck. It moves content from servers to human-facing applications, extremely well. Agent coordination is the mail service that agent-native communication needs to build. The primitive should carry intent structure at the wire, attribution at every message, multi-modal streams natively, and integration with the other substrate primitives (identity, authorization, delegation, trust) as first-class fields rather than as application-layer conventions.

The SMS parallel makes the point at a smaller scale. When SMS emerged in the 1990s, existing communication infrastructure already covered synchronous voice (phone calls) and asynchronous text (email, letters). A skeptic at the time could have argued that SMS was unnecessary: use email for text, use voice calls for real-time coordination, done. But SMS filled a distinct coordination pattern that neither voice calls nor email served well: real-time-ish, bidirectional, message-oriented, attribution-native (the phone number is intrinsic), delivery-confirmed. SMS became one of the most-used communication protocols in history because the coordination pattern was real and existing protocols served it poorly. Agent coordination is in the same position now.

The answer is yes, agent communication is needed as a substrate primitive distinct from HTTP and from application-layer conventions on top of HTTP. The primitive must carry:

- **Structured intent at the wire.** Messages carry semantic verbs (query, delegate, execute, and others) plus typed parameters, so receivers dispatch and audit without parsing prose or reverse-engineering an application-specific format.
- **Attribution end-to-end.** Every message carries verifiable attribution to the sending identity and to the delegation chain behind it. Intermediaries can inspect attribution without decrypting the message payload; receivers can verify attribution independently of any transport session.
- **Bidirectional coordination.** Real-time bidirectional streams are first-class, alongside request-response and asynchronous messaging. Coordination between two agents may span many messages in either direction within a single exchange.
- **Multi-modal payloads.** Voice, video, structured data streams, and text messages coexist within the same coordination context, without requiring separate connections or protocol switches.
- **Substrate integration.** Identity, authorization, delegation, trust, and attribution primitives are carried natively with the message, rather than being reconstructed by the application layer above the transport.

### Why it is needed

Agent communication is the vehicle for every coordination act between agents. Discovery finds a candidate. Trust filters it. Authorization checks the specific action. Delegation frames the mandate. Communication is where the coordination actually happens: the message goes from sender to receiver, carrying with it everything the receiver needs to evaluate and respond. If communication fails to carry the coordination primitives natively, every application must rebuild them. The rebuilding fragments across implementations, breaks interoperability, and creates security gaps at the boundaries between reconstructions. Substrate communication makes coordination properties portable across applications and verifiable end-to-end.

### The core use case: coordinating a task through real-time bidirectional exchange

An assistant agent is working with a travel-service agent to book a business trip on behalf of the assistant's principal. The exchange is a coordinated conversation rather than a single API call:

- Assistant: "Book a trip to Tokyo for my principal, March 15 to 20, direct flights preferred, hotel under $200 per night, total budget $2,500."
- Travel-service: "I have 3 flight options and 5 hotels matching the criteria. Here are the details."
- Assistant: "Let me check flight options 1 and 3 against my principal's calendar."
- Assistant: "Option 3 works. Which of the 5 hotels fits best with that flight's arrival time?"
- Travel-service: "For flight option 3, hotels A and C have availability. Hotel A is closer to the meeting locations you specified in prior bookings."
- Assistant: "Book flight option 3 and hotel A."
- Travel-service: "Confirmed. Total: $1,847. Confirmation numbers and itinerary follow."

Every message in this exchange carries information that the substrate must handle:

- **Who is speaking.** The assistant's identity, verified. The travel-service's identity, verified. The principal's identity, referenced through the assistant's delegation chain.
- **On whose behalf.** The assistant is acting under a delegation from the principal. The delegation chain and its scope are visible on every message.
- **What the intent is.** Book. Check availability. Recommend. Confirm. Each message carries a semantic intent alongside any body data.
- **What the context is.** Prior messages in the exchange, the delegation framework, the principal's stored preferences, the travel-service's prior bookings referenced in the recommendation.
- **What modality.** Structured data (flight options, hotel details, confirmation numbers) interleaved with natural-language coordination text. Voice or video could join the same exchange if the assistant needed to confirm something audibly.

Without a substrate communication primitive:

- The assistant and travel-service must have agreed on a specific API contract in advance (REST endpoints, JSON schemas, parameter names, response formats). Any change to the API requires coordinated updates on both sides.
- The exchange breaks into a series of independent HTTP requests. Each request must carry enough state to reconstruct the coordination context, which typically means large opaque session tokens and cookie-based state management on both sides.
- Attribution is reconstructed from JWT tokens or from application-layer identity headers, and the delegation chain is either lost or must be encoded as an application convention that receivers might parse or ignore.
- Multi-modal payloads require separate channels or protocol switching mid-exchange, which forces the application to manage multiple connections and reassemble the coordination logic across them.
- Trust and authorization decisions happen out-of-band, at the boundaries between individual HTTP requests, with the application layer responsible for maintaining consistency.

With a substrate communication primitive:

- The assistant and travel-service exchange messages using shared semantic verbs (search, evaluate, book, confirm). Both parties understand what each verb means without prior API negotiation. New verbs can be added to the vocabulary as needed, with clear semantics.
- The exchange is a single coordinated session. Context persists across messages naturally, without requiring the application to encode and decode session tokens on every message.
- Attribution rides with every message, cryptographically bound to the sending identity and referencing the delegation chain. Any receiver, and any intermediary, can verify attribution locally.
- Multi-modal payloads flow within the same coordination context. Structured data, natural-language text, voice, and video coexist as first-class message types.
- Substrate primitives (identity, delegation, trust, attribution) are inspected at message-level rather than being reconstructed by the application.

The postal service parallel captures the shift. Under an HTTP-only approach, the assistant is stuffing letters into newspapers hoping the delivery truck brings them to the right person. Under a substrate communication primitive, the assistant is putting letters in envelopes with proper addressing and delivery service, and the postal system handles the coordination. Both approaches move bytes from A to B. Only the second treats the coordination properties (attribution, delivery reliability, addressing, service class) as substrate primitives rather than application concerns.

Human employees rarely need this specific primitive because human coordination already has purpose-built communication channels for different needs. Business meetings for real-time multi-party coordination. Email for asynchronous formal communication. Phone calls for urgent bidirectional coordination. Chat for casual asynchronous coordination. Formal letters and contracts for legal-instrument-grade communication. Each channel evolved for its specific coordination pattern. Software rarely needs this primitive because software components typically call each other through pre-agreed API contracts (function calls, RPC, message queues) with pre-negotiated schemas. Neither model handles the case of agents coordinating across organizational boundaries in real time, exchanging structured intent with delegation lineage intact, across multiple modalities, without pre-negotiated API contracts. That is the common case at agent scale, and it is what agent communication addresses.

The HTTP-and-application-layer approach works cleanly when both parties are running the same agent stack, have agreed on a specific API contract, and are exchanging simple structured messages under a single principal. It works less cleanly when the parties come from different agent stacks with different conventions, when the exchange spans multiple modalities, when delegation chains need to be preserved across many messages, and when new coordination patterns emerge that fell outside the original API design. Substrate communication makes coordination portable across stacks, across modalities, across delegation chains, and across evolving patterns without requiring every application to reinvent the coordination primitives.

Higher-consequence needs (long-lived coordination sessions that survive transport interruption, encrypted multi-modal streams with per-modality trust properties, cross-organization coordination across trust boundaries, real-time media coordination with per-participant attribution, coordination-layer intermediaries that inspect attribution without decrypting payloads) build on this base. Without the base, agent coordination reduces to whatever any two agent stacks can negotiate at the application layer over HTTP, and interoperability across stacks becomes an integration project rather than a substrate property.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Send a structured intent from one agent to another
- Hold a bidirectional conversation across many messages
- Broadcast a coordination message to many recipients
- Mix multi-modal content (voice, video, structured data) in one exchange
- Preserve who is speaking when a message passes through an intermediary
- Support real-time streaming between agents
- Support asynchronous messaging with delivery guarantees
- Handle message ordering and duplicates
- Encrypt messages at the substrate layer
- Coordinate messages from many senders in one exchange

---

## 7. Session

### Is agent session needed?

Session infrastructure has existed on the internet since the earliest web applications. HTTP cookies carry session state across requests. TLS session resumption avoids full handshakes on reconnection. WebSocket persistent connections maintain real-time state between client and server. OAuth refresh tokens keep authorization state alive across long periods. Application-layer session tables in databases hold user state across many interactions. Every serious web application manages session state today, and the tools for managing it are mature.

Do agents need their own session primitive on top of all of that? A skeptic could argue no. Combine HTTP cookies for state, TLS session resumption for cryptographic continuity, WebSocket connections for real-time, and OAuth refresh tokens for auth persistence. The combination covers the session case for any application, agent or otherwise. Nothing new required.

The counter-argument turns on the assumptions built into traditional web session infrastructure. Web sessions were designed for a specific interaction pattern: a human user opens a browser, interacts with a service for minutes or hours, and closes the session when they finish. Cookies persist within that scale. TLS resumption optimizes for reconnection within a short window. WebSocket connections stay open while the browser tab remains active. OAuth refresh tokens extend the pattern but still assume the same shape: single user, single service, session-length measured in hours or perhaps days.

Agent sessions break these assumptions in six specific ways.

First, **duration**. A single agent coordination task may span days, weeks, or months. A market research task waits for external data delivery. A grant application waits for co-signers. A legal filing waits for court schedules. The coordination stays coherent across the wait, but the wait exceeds any timeout a traditional session was designed for.

Second, **endpoint-bound state**. Traditional session state lives at one endpoint (server-side session table, browser cookie jar). Agent sessions frequently span multiple agents in a delegation chain. When an assistant agent delegates a research task to a research agent, which in turn calls a data agent, the coherent coordination context spans three endpoints. Traditional sessions cannot represent this without application-layer coordination code.

Third, **transport fragility**. Cookies invalidate when the browser closes. TLS session resumption tickets expire. WebSocket connections drop under network partition. Traditional session state assumes the underlying transport is roughly continuous during the session. Agent sessions must survive process restarts, container migrations, infrastructure changes, and long dormancy where nothing is transported at all.

Fourth, **cryptographic continuity**. Traditional session tokens can be exchanged, refreshed, or reissued, but there is no built-in mechanism to prove that a resumed session is cryptographically continuous with the original. For high-consequence coordination (approvals, contracts, financial commitments), the receiver needs proof that today's message comes from the same session that started three weeks ago, cryptographically bound, without depending on trust in the server that manages the session table.

Fifth, **transactional semantics**. Web sessions rarely need commit-or-rollback semantics; the browsing user rarely needs to roll back a shopping cart cleanly. Agent coordination often does. When an agent commits a partial purchase across three sub-agents, and one leg fails, the coordination needs to unwind cleanly. Traditional session state offers no primitive for this; each application implements its own transactional semantics on top of session tokens.

Sixth, **suspend and resume**. A long-running agent task may need to pause for hours or days waiting for human input, external event triggers, or scheduled continuation. When the task resumes, it must pick up exactly where it left off, with all coordination context intact, without re-authenticating, re-establishing delegation, or reloading state from scratch. Traditional session infrastructure was designed for continuous use rather than intentional pause-and-resume.

The video game save-state analogy is the cleanest one. When you save a game, you can close the console, come back tomorrow or next month, load the save file, and continue exactly where you left off. Every element of your progress is preserved: your character's inventory, your position in the world, your relationships with non-player characters, your active quests. Load the save file and the game continues as if you had never left. That is the property agent coordination needs. Traditional web sessions have nothing like it; they behave more like a phone call where hanging up ends the conversation and calling back starts a new one.

Bank accounts capture a different aspect. Your account persists across time, across bank employees, across your own devices, across bank system upgrades. The account holds transaction history, balance state, authorized users, and preferences. You can walk into any branch, log into any app, or call any support line, and the account state is available. This is state persistence across time and across access contexts. Traditional web sessions are ephemeral by comparison; the bank account model is what agent sessions need for long-lived coordination.

Medical patient records extend the analogy to multi-party persistence. A patient's medical history persists across visits, providers, hospital systems, insurance changes, and even across decades. Any authorized provider can access the record, add to it, and reference prior entries. The record itself is the coherent state; providers are participants in the record over time. This is closer to what an agent coordination session looks like when multiple agents participate across a long-running task.

The answer is yes, agent session is needed as a substrate primitive distinct from traditional web session infrastructure. The primitive must support:

- **Long-duration persistence.** Coordination sessions that survive intended pauses of days, weeks, or months without losing state.
- **Multi-endpoint span.** Sessions that carry coherent coordination context across multiple agents in a delegation chain.
- **Interruption tolerance.** State that survives transport failure, process restart, infrastructure migration, and long dormancy.
- **Cryptographic continuity.** Resumed sessions provably continuous with the original, verifiable by any receiver without trusting the server that manages the session state.
- **Transactional semantics.** Support for commit-or-rollback where the coordination workflow requires it.
- **Suspend and resume.** First-class operations that pause a session gracefully and resume it with full context preserved.

### Why it is needed

Communication handles individual messages between agents. Session handles state that persists across many messages over time. The two primitives are complementary rather than overlapping: an exchange of five messages may happen entirely within one session or across five separate sessions, and the same substrate must support both patterns. Without a session primitive, every application that coordinates agent tasks over time must build its own state persistence, its own reconnection logic, its own cryptographic continuity proofs, and its own transactional semantics. The rebuilding fragments across applications, breaks interoperability across stacks, and creates security gaps at the boundaries between reconstructions. A substrate session primitive makes long-lived coordination state portable and verifiable end-to-end.

### The core use case: a research task that spans days with human review at key points

An assistant agent is preparing a market research report for its principal. The task will take about a week and involves multiple stages of work interleaved with human input.

**Day 1.** The assistant agent begins the task. It delegates data-gathering to a research agent operated by a subscription intelligence service. The research agent begins pulling data from multiple sources. The assistant agent produces preliminary observations and sends a status update to the principal.

**Day 2.** The principal reviews the preliminary observations overnight and sends feedback in the morning. "Focus more on the enterprise segment. Also, add competitor pricing analysis." The assistant agent receives the feedback, adjusts the research direction, and re-delegates to the research agent with the new criteria.

**Day 3.** The research agent finishes data collection. The assistant agent begins analysis, drafts findings, and identifies two questions that need principal input. It sends the questions to the principal and pauses the coordination.

**Day 4.** The principal is traveling and unavailable for most of the day. The session waits. At the end of the day, the principal responds to the two questions.

**Day 5.** The assistant agent resumes, incorporates the principal's answers, and produces a draft report. It sends the draft to the principal for review.

**Day 6.** The principal reviews the draft, marks up changes, and returns it. The assistant agent works through the revisions.

**Day 7.** Final report delivered.

The entire seven-day workflow is one coherent coordination session. It survives:

- Six overnight pauses (transport connections drop, processes restart)
- One full-day pause while the principal is traveling
- Multiple delegation hops (assistant to research agent and back)
- Infrastructure changes (if the assistant agent moves servers mid-week)
- Multiple message exchanges within each active day

Without a session primitive at the substrate:

- The application must serialize coordination state to a database at the end of each active period and reload it at the start of the next. Every serialization boundary is a potential integrity failure.
- The assistant agent must re-authenticate, re-establish delegation from the principal, and re-verify the research agent's identity at the start of each day. Each re-authentication is a friction point and a place where the coordination might fail to resume.
- The research agent's participation must be tracked separately, in a different session table or state store, since traditional session infrastructure cannot span multiple endpoints coherently.
- Cryptographic proof that today's coordination is continuous with what was set up on day 1 must be constructed from scratch at every resumption. There is no substrate primitive that carries this continuity natively.
- If the assistant agent's process restarts, the application must reconstruct the coordination context from persisted state. Anything that was in memory at the time of the restart may be lost or must be recomputed.

With a session primitive at the substrate:

- The session is a substrate object with a stable identifier that persists across time. Reattaching to it uses the same primitive whether one hour or one week has passed.
- The delegation chain (principal to assistant, assistant to research agent) is bound into the session at establishment. Reattaching preserves the delegation context without requiring re-authentication at each step.
- All participating agents share coherent coordination context through the session, and any participant can reattach and inspect current session state.
- Cryptographic continuity is provided by the substrate: any receiver evaluating a message from the resumed session can verify it is continuous with the session that was established on day 1.
- Suspend and resume are first-class substrate operations. The session pauses gracefully at the end of each active period and resumes at the start of the next, with state intact.

The video game save-state parallel maps directly. On day 1, the assistant agent saves the coordination state to a session. Each day, it loads the save state, continues the work, and saves again. On day 7, the final delivery is the completion of the game. The save state made the whole week-long task tractable as one coherent workflow rather than seven independent restarts.

Human employees rarely need this specific primitive because human work is naturally suspended and resumed by the humans themselves. A researcher stops work at the end of the day, remembers where they left off, and continues in the morning. The state persistence happens inside the researcher's mind and any personal notes they took. Software rarely needs this primitive because software components typically run continuously or complete their work in one execution. When software does need long-lived state, it uses application-specific databases with application-specific schemas, custom to the workflow. Neither model handles the case of coordination that spans multiple agents across time, requires cryptographic proof of continuity, and needs to survive infrastructure change without application-layer reconstruction. That is the common case for any serious long-running agent workflow, and it is what session addresses.

Traditional web session infrastructure works cleanly when the interaction is a single user with a single service over minutes or hours. It works less cleanly when the coordination spans multiple agents, needs to survive intended pauses of days, and requires cryptographic continuity that no application-layer reconstruction can provide. Substrate session makes long-lived coordination state portable across time, across participants, and across infrastructure changes without requiring every application to invent its own persistence layer.

Higher-consequence needs (coordinated sessions across trust boundaries with per-participant state visibility rules, session-level transaction atomicity across delegation chains, session state that outlives specific participating agents through delegation-chain succession, encrypted session state that receivers can decrypt with substrate-level keys, cross-organization session federation) build on this base. Without the base, agent coordination reduces to what application-layer session tokens can express, and application-layer session tokens were designed for a shorter, simpler pattern of interaction.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Maintain state across a coordination that runs for days or weeks
- Pause a session for external input (human approval, awaited event)
- Resume a session with full context intact
- Prove a resumed session is continuous with the original
- Support sessions where multiple agents participate
- Support commit-or-rollback across a session
- Recover a session after a process restart
- Enable session participation by agents from different organizations
- Control which participants see which parts of session state
- Handle session state that outlives specific participants

---

## 8. Semantics

### Is agent semantics needed?

The internet has substantial semantic infrastructure. OpenAPI describes REST API contracts. JSON Schema validates structured data. Protocol Buffers define typed messages. gRPC provides schema-based RPC. GraphQL types queries and responses. The semantic web produced RDF, OWL, and SPARQL for shared meaning through formal ontologies. Modern MCP tool descriptions and A2A agent cards provide machine-readable definitions of what agents can do. Every serious API has a schema; every serious agent framework has tool descriptions; every serious data pipeline validates types. And underneath all of that, natural language processing has become powerful enough that agents can exchange plain text messages and interpret them with large language models on either side.

Do agents need their own semantics primitive on top of all of that? A skeptic could argue no. Combine OpenAPI for contract definition, JSON Schema for validation, MCP tool descriptions for agent capabilities, and LLM interpretation for anything unstructured. This combination covers the semantic problem. Any two agents can either agree on a contract in advance or figure it out through language interpretation at runtime. Nothing new required.

The counter-argument turns on the distinction between structure and meaning. Schema languages describe structure. They specify field names, types, and shapes. They say nothing about what the fields mean or what the message is trying to accomplish. An OpenAPI specification tells you that a POST to /orders takes a JSON body with a customer_id string and an items array; it leaves unspecified what "order" means at the coordination level, what the seller is agreeing to by processing it, or how the same concept relates to a POST to /purchases on another server that takes different field names for essentially the same operation.

Every application defines its own vocabulary. One shopping platform calls the operation "buy." Another calls it "purchase." A third calls it "order." A fourth calls it "reserve" and treats the actual purchase as a separate operation. Each vocabulary is internally coherent but different from every other. Agents from different platforms must either translate between vocabularies or negotiate a shared vocabulary before any coordination can happen. This is per-pair integration work that scales quadratically with the number of platforms.

Natural language processing can bridge the gap, and it currently does bridge the gap in many agent stacks. Agent A sends "please buy 10 units of product X for $50 each." Agent B interprets that natural language, executes the operation, and responds in natural language. The LLM handles the semantic translation on both sides. This works, but it comes at real cost: expensive inference on every message, non-deterministic interpretation that occasionally produces the wrong action, difficulty auditing what actually happened, and no cryptographic binding between the request and the executed action. Language interpretation at every step is a workaround for the absence of a shared substrate vocabulary rather than a design.

The semantic web attempted to solve this at the ontology level. RDF, OWL, and SPARQL let anyone publish a shared ontology and let anyone else adopt it. The vision was that shared meaning would emerge from a distributed graph of interconnected definitions. The vision never became widely deployed reality. The reasons are worth naming. Ontology adoption requires community-scale coordination that rarely materialized. Ontology matching between similar-but-different vocabularies became a research problem in itself. Applications preferred bespoke schemas they controlled over shared ontologies they had to agree on. Twenty-five years after the vision was articulated, the web is still an internet of bespoke schemas rather than an internet of shared meaning.

The counter-argument is that agents need a smaller, more focused version of what the semantic web tried to build: a shared vocabulary of coordination verbs at the substrate level, closed enough to be practical, open enough to extend for domain specialization. Rather than a general-purpose ontology that describes all possible meaning, agents need a small set of coordination primitives that any agent can rely on any other agent to understand.

HTTP itself provides the closest analog. HTTP has methods: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS. That is essentially the entire semantic vocabulary of HTTP, and everyone who touches HTTP knows what each method means without prior negotiation. A GET is a retrieval. A POST is a submission. A DELETE is a removal. HTTP defined these once, at the substrate, and every HTTP client and server implements them with consistent semantics. The methods carry meaning at the wire. Any two HTTP endpoints can coordinate at the method level without discussing what GET means. HTTP's semantic vocabulary is narrow (nine methods) and universal (every HTTP participant understands them). That combination makes coordination possible at scale.

Agent coordination needs the same shape at a different layer. HTTP methods describe content operations (retrieve, submit, remove content). Agent semantic verbs need to describe coordination operations: query for information, discover capabilities, delegate authority, execute action, collaborate on task, purchase a good, confirm a commitment. The exact vocabulary is a design choice, but the property matters more than the specific words. A small closed set of coordination verbs, universally understood, embedded in messages at the wire, enables coordination between any two agents without prior negotiation.

Traffic signs make the point at a more concrete level. A stop sign means stop, everywhere in the world. A one-way arrow means one-way traffic. A pedestrian crossing sign means pedestrians may cross here. Drivers from any country recognize these signs and act on them without translation. The traffic sign vocabulary is small, visual, and universal. It works because every road authority uses the same signs with the same meanings. Coordination among millions of drivers happens through this shared vocabulary. If every country defined its own signs, international driving would require a lookup table.

Aviation English extends the point to safety-critical coordination. Air traffic control worldwide uses a standardized vocabulary of terms and phrases. "Cleared for takeoff" means one thing precisely. "Roger" means received and understood. "Wilco" means will comply. "Mayday" means life-threatening emergency. Pilots and controllers from different countries, different airlines, and different backgrounds coordinate through this vocabulary in real time. The vocabulary is small, closed, and unambiguous. Aviation would be impossible at global scale without it. Air traffic coordination requires the same property agent coordination requires: shared meaning that requires no prior negotiation between specific participants.

Musical notation extends further into the abstract. A note on a staff means the same pitch and duration to any trained musician. A time signature means the same rhythmic structure. A dynamic marking means the same volume. Musicians from any tradition, on any instrument, can read the same score and coordinate a performance. Musical notation is a shared vocabulary that carries meaning without prior negotiation between the composer and the performer. Agent semantics is the coordination equivalent.

The answer is yes, agent semantics is needed as a substrate primitive distinct from application-layer schemas and from language interpretation. The primitive must provide:

- **A closed vocabulary of coordination verbs.** Small enough to be memorable and universally implementable. Focused coordination primitives rather than general-purpose ontology.
- **Universal shared meaning.** Every verb means the same thing to every participant. No per-pair negotiation. No context-dependent interpretation.
- **Wire-level embedding.** Verbs appear as first-class message primitives, so receivers dispatch and audit on the verb without parsing prose or reverse-engineering an application-specific schema.
- **Typed parameters.** Each verb carries typed parameters with defined shapes, so the wire message conveys both what the sender wants and what data supports it.
- **Extensibility for domain specialization.** Domains that need additional vocabulary (medical, legal, financial, industrial) can add specialized verbs without breaking base-vocabulary interoperability.
- **Deterministic interpretation.** Given a verb and its parameters, the receiver's understanding of the message is exact. No language interpretation ambiguity between sender and receiver.

### Why it is needed

Communication carries messages between agents. Semantics defines what those messages mean. The two primitives are complementary: an agent can send a message with the right delivery properties (attribution, session context, real-time flow) and still be misunderstood if the receiver cannot interpret the intent. Semantics is what makes the message actionable. Without shared semantics at the substrate, every agent-to-agent interaction requires either prior contract negotiation (custom API, custom schema, custom vocabulary) or runtime language interpretation (LLM parsing on both sides). Both approaches work at small scale and both fail at agent-population scale. Prior negotiation scales quadratically with the number of participants; language interpretation is expensive, non-deterministic, and hard to audit. A substrate semantics primitive makes coordination between any two agents possible without either burden.

### The core use case: two agents from different organizations completing a purchase without prior integration

An assistant agent at Company A needs to purchase office supplies on behalf of its principal. It discovers a supplier agent operated by Company B through the discovery primitive. The two agents have never interacted before. Neither company has integrated with the other. The assistant agent has authority to complete the purchase within a budget.

Without a substrate semantics primitive:

- Before any coordination can begin, the assistant agent must discover Company B's API contract. It reads through the supplier's OpenAPI specification, learns what operations exist, learns what field names Company B uses, learns what response formats to expect, and adapts its own code to match.
- If Company B uses different vocabulary from Company A (Company B calls it "reserve then commit"; Company A expects "purchase"), the assistant must translate between vocabularies at the application layer.
- Alternatively, the two agents fall back to natural language. The assistant sends "I would like to purchase 10 units of item ABC-123 at your listed price." The supplier's LLM interprets, generates a proposed order, sends it back in natural language. The assistant's LLM interprets the response, extracts the price and terms, and formulates a natural-language confirmation. Each interpretation step costs LLM inference and introduces potential misinterpretation.
- The interpreted actions have no cryptographic binding to the intent. If the supplier later delivers the wrong item, there is no substrate-level record of what was actually requested, only two separately generated natural-language messages and whatever application-layer parsing they produced.
- Company A must build this integration for every supplier it wants to work with. Company B must publish and maintain contracts for every buyer. The integration burden scales with the product of buyers and sellers.

With a substrate semantics primitive:

- The assistant agent sends a QUERY verb with typed parameters (item description, quantity, price constraints). The supplier's response uses a shared PROPOSE verb with typed parameters (offered items, prices, terms).
- Both agents understand what QUERY and PROPOSE mean because the substrate defines them, rather than because the two companies negotiated. Neither had to publish or consume a bespoke contract.
- The assistant sends PURCHASE with the specific proposal it accepts. The supplier confirms with COMMITMENT. Both verbs have precise substrate-defined semantics.
- Every verb is bound cryptographically to the sending agent, and the resulting transaction record contains verifiable substrate-level evidence of what was requested and what was agreed. Dispute resolution can rely on this evidence rather than reconstructing intent from natural language.
- Any assistant agent can coordinate with any supplier agent using the same substrate verbs. The integration burden collapses from N times M (buyers times sellers) to N plus M (each side implements the substrate vocabulary once).

The HTTP methods parallel is direct. Any HTTP client can GET any HTTP resource because both sides understand GET without prior negotiation. If HTTP had never defined GET, POST, PUT, and DELETE at the substrate, every web server would define its own retrieval and submission conventions, and every client would need per-server integration. The web would be a collection of bespoke protocols rather than a shared substrate. HTTP methods made the web work. Agent semantic verbs can make agent coordination work at the same scale.

The traffic sign parallel captures the everyday version. When you drive into a town you have never visited, you understand the traffic signs immediately. Stop means stop. Yield means yield. Speed limit means speed limit. You never need to consult a local translation guide or negotiate with the traffic authority. The shared vocabulary makes driving possible in unfamiliar places. Agent coordination needs the same property: an agent should be able to coordinate with agents it has never met, using shared vocabulary that requires no per-pair negotiation.

Human coordination rarely needs this exact primitive because humans already share natural language, which carries enormous accumulated shared meaning at the cost of ambiguity and interpretation overhead that humans handle gracefully. Software rarely needs this primitive because software components are typically integrated within a single system where the developer defines the vocabulary once for all components. Neither model handles the case of software entities that need to coordinate across organizational boundaries, at wire speed, with cryptographic binding between intent and action, and without either prior integration work or expensive language interpretation. That is the common case at agent scale, and it is what semantics addresses.

The application-layer schema approach and the LLM interpretation approach both work at small scale. The application-layer approach breaks down when the number of participating platforms grows, because every pair needs its own integration. The LLM interpretation approach breaks down when the coordination volume grows, because every message costs inference and introduces interpretation risk. A substrate semantics primitive makes coordination scale linearly rather than quadratically, and makes intent verifiable rather than interpretive.

Higher-consequence needs (domain-specific vocabulary extensions with defined semantics, formal verification of verb behavior in receivers, vocabulary versioning and backward compatibility, semantic overlays that translate between the substrate vocabulary and legacy domain vocabularies, cross-cultural semantic considerations where verb semantics may need to reflect regulatory or cultural context) build on this base. Without the base, agent coordination reduces to either bespoke integrations (application layer) or language interpretation (LLM at every message), and neither scales to the coordination volume agent populations will produce.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Coordinate with an agent you have never worked with before
- Verify that a specific action was requested with specific meaning
- Extend the vocabulary for a specific domain (medical, legal, financial)
- Handle versioning of shared vocabulary with backward compatibility
- Translate between the substrate vocabulary and a legacy vocabulary
- Confirm the receiver understood the request the same way the sender meant
- Handle multi-step workflows (query, propose, negotiate, commit)
- Support explicit refusal (an agent declines a request)
- Support conditional acceptance (accept only if X)
- Coordinate across industries using a shared base vocabulary

---

## 9. Tools

### Is an agent tools primitive needed?

The current agent ecosystem has substantial tool infrastructure. MCP, the Model Context Protocol, is the dominant protocol for exposing tools to agents; every major frontier AI provider supports it. OpenAI function calling and Anthropic tool use provide first-class tool invocation from within model prompts. LangChain and similar frameworks maintain large libraries of pre-integrated tools. Plugin architectures let developers extend IDEs, chat platforms, and browser environments with domain-specific capabilities. REST APIs remain the workhorse of machine-to-machine service invocation. Zapier, Make, and similar platforms provide low-code automation across thousands of pre-integrated services. WebAssembly and similar sandboxing technologies allow tools to run with contained privileges. The tool-invocation space is one of the fastest-moving areas of the entire agent ecosystem.

Do agents need their own tools primitive on top of all of that? A skeptic could argue no. MCP is already widely deployed. It handles capability description, invocation, and result return. Every major agent framework supports it. New tools are being wrapped in MCP servers daily. Adding another primitive layer for tools duplicates work already happening. Combine MCP with the existing agent identity and auth stacks, and the tool problem is solved.

The counter-argument runs on two levels.

First, the tool-versus-agent distinction is increasingly arbitrary. Is Google Maps a tool or an agent? Is a database query an agent invocation? Is a language translation service a tool? Is a fully-featured booking service a tool? The category boundary shifts depending on framing: a "tool" is often a service with a narrower advertised capability, while an "agent" is a service with a broader advertised capability. But at the coordination substrate, both are software entities responding to structured requests with structured responses. Treating them as fundamentally different categories forces the ecosystem to maintain two parallel protocol stacks (one for tools, one for agents) with different identity, discovery, authorization, and semantics on each side. Every application then spends energy bridging between the two stacks whenever a workflow crosses from tool invocation to agent coordination.

Second, tools do have specific concerns that the agent primitives from earlier sections address but deserve to be named explicitly. Tools are attack surface. A compromised tool can exfiltrate data, corrupt state, or execute unauthorized actions in the name of the agent that invoked it. Tool discovery by capability is often the first step in a coordination workflow (an agent needs to send email; it looks for an email-sending capability without knowing any specific tool's name). Tool invocation is typically atomic (call, receive result, done) rather than long-lived (like an agent-to-agent coordination session). Tool descriptions require a specific level of machine-readable precision so agents can select and invoke them correctly. These properties are all handled by the substrate primitives (identity for verification, discovery for capability lookup, semantics for structured invocation, authorization for permitted use, trust for integrity evaluation), but the specific way tools use those primitives matters.

The counter-argument accepts MCP as functional. MCP is a solution to a real problem, and its rapid adoption reflects genuine value. The argument is that treating tools as a separate class of thing, with a separate protocol stack, produces fragmentation that the substrate can eliminate. When tools use the same identity primitives as agents, the same discovery mechanisms, the same authorization framework, the same semantic verbs, and the same communication substrate, several concrete benefits follow. Any agent can invoke any tool without protocol translation. Any tool can compose with any agent workflow. Trust and integrity attestation apply uniformly. Audit trails cross tool and agent invocations without seams. Delegation chains preserve attribution when they pass through tool invocations mid-chain. Discovery returns tools and agents in the same result set when both can satisfy a capability need.

The kitchen analogy captures the idea. A chef coordinates a complex dish through recipes and timing. The recipe calls for both tools (knife, blender, pot) and helpers (sous chef, dishwasher). The chef never uses a separate command system for tools and another for helpers. The same command structure directs both: "chop these onions" whether the receiver is a hand chopping with a knife or a sous chef chopping. The coordination surface is uniform even when the executor varies. Similarly, an agent coordinating a workflow gains nothing from separate protocol stacks for tools and agents. It benefits from a uniform coordination surface where any capable executor (tool or agent) can be addressed the same way.

Unix provides the technical parallel. In Unix, tools like grep, sed, awk, and cat are technically indistinguishable from any other executable at the operating system level. They have process IDs. They read from standard input and write to standard output. They compose through pipes. The kernel treats them the same as any other program. The "tool" concept is about intent and typical usage, rather than about a distinct kernel-level category. This uniformity is why Unix tools compose so effectively into pipelines. If Unix had defined tools as a separate category with a separate calling convention, pipelines would be impossible. Agent tool invocation benefits from the same design choice: tools as first-class substrate participants with the same coordination primitives as any other agent.

The answer is yes, agent tools deserve treatment at the primitive level, though as substrate participants rather than as a separate protocol stack. The primitive is the recognition that tools address specific concerns through the same substrate primitives as agents, with specific properties that shape how each primitive applies:

- **Identity as agents.** Tools carry the same substrate identity as agents. A tool's Agent-ID is the primary addressable reference, cryptographically bound to its origin. This lets the caller verify what it is invoking before granting access.
- **Discovery by capability.** Tools appear in the same capability-based discovery as agents. An agent looking for email-sending capability sees both dedicated email tools and full email-agent services in the same result set, filtered by attributes.
- **Semantics through the same vocabulary.** Tools respond to the same substrate verbs as agents. QUERY, EXECUTE, and similar verbs work whether the receiver is a stateless tool or a stateful agent.
- **Authorization and delegation.** Tools receive delegation chains from calling agents. The tool sees the original principal, the delegation lineage, and the specific authority granted for this invocation. Downstream tool calls carry the same chain forward.
- **Integrity attestation.** Tools carry cryptographic evidence of their implementation. Before invocation, the calling agent can verify that this tool at this endpoint is the expected implementation, rather than a spoof or a compromised replacement.
- **Trust as a filter.** Tools carry trust scores in the same way agents do. High-stakes tool invocations can filter by trust tier at discovery time.

### Why it is needed

Communication carries messages, semantics defines them, delegation frames authority, and trust filters candidates. Tools use every one of these primitives, but they use them under specific constraints that make explicit treatment worthwhile. If tools are handled through a separate protocol stack, the ecosystem fragments into agent coordination on one side and tool invocation on the other, with bridge code between them. If tools use the same substrate primitives as agents, coordination stays uniform: an agent invoking a tool looks like an agent invoking another agent, and the same guarantees apply. The primitive is really about extending the coordination surface uniformly to non-agent capabilities rather than treating them as a separate category requiring its own infrastructure.

### The core use case: composing multiple tools and an external agent in one workflow

An assistant agent needs to schedule a meeting for its principal with a partner at another organization. The workflow crosses three coordination targets: a calendar tool inside the principal's environment, an external agent representing the partner, and an email tool for sending confirmations. Each target has a different role, and yet all three operate on behalf of the same principal under the same delegation, and the outcome should compose into a single audit trail with an intact delegation chain.

Without treating tools as substrate participants:

- The assistant agent maintains three separate protocol stacks. The calendar tool is exposed through MCP or a REST API. The partner's agent is reached through A2A or whatever agent-to-agent convention the partner supports. The email tool has its own SDK or REST interface. Three protocol stacks, three integration surfaces.
- Each stack has its own identity model. The calendar tool authenticates through OAuth against the calendar provider. The partner's agent verifies identity through A2A conventions with its own certificate structure. The email tool uses vendor-specific credentials. Three identity models to manage, verify, and rotate.
- The delegation from principal to assistant lives in each stack differently. OAuth scopes express it one way for the calendar tool. A2A carries a different attribution model for the partner's agent. The email tool may carry no delegation context at all. Nothing preserves the delegation lineage across the tool-to-agent and agent-to-tool boundaries in the workflow.
- If the partner's agent proposes new times that require calendar changes, the assistant must translate between A2A message formats and calendar-tool API formats manually. Every crossing between stacks is a translation surface where bugs, semantic drift, or lost attribution can occur.
- Audit records fragment across three log formats stored in three separate systems. Reconstructing what happened later requires correlating logs by timestamp and by best-guess request parameters, hoping the timestamps agree and the correlations hold.
- Integrity attestation happens per stack. If any participant is compromised (a spoofed email service, a hijacked calendar integration, a fraudulent partner agent), each verification path uses different evidence and different assumptions. The assistant has no uniform way to determine whether the participants it is coordinating with are what they claim to be.

With tools as substrate participants:

- All three coordination targets use the same substrate primitives. The calendar tool responds to substrate verbs (QUERY for availability, EXECUTE for event creation). The partner's agent responds to substrate verbs. The email tool responds to substrate verbs. The assistant coordinates the whole workflow through one primitive vocabulary.
- The delegation chain from principal to assistant flows uninterrupted through every step. Each participant sees the principal, the delegation lineage, and the specific scope authorized for its participation in this workflow.
- Identity and integrity attestation work uniformly. The assistant verifies each participant through the same substrate mechanism before granting access to workflow context. A spoofed email service, hijacked calendar integration, or fraudulent partner agent fails the same integrity check, at the same layer, with the same evidence structure.
- The audit trail is a single coherent record. When the principal or an auditor later asks what happened, one record shows the entire workflow: which tools were invoked, which external agent participated, what each step contributed, and what the final outcome was. Reconstruction happens by reading one substrate record rather than correlating three application-layer logs.
- Composition scales linearly. Adding a fourth participant (a scheduling assistant, a video-conferencing tool, a document-generation agent) uses the same substrate primitives. The workflow accommodates growth without adding integration surfaces.

The fragmentation cost has a name worth calling out explicitly: it is an integration tax that grows with the product of the number of tool protocols and the number of agent protocols an ecosystem uses. Every combination of a tool protocol with an agent protocol requires bridging code. Every bridge is a translation surface. Every translation surface is a place where attribution can be lost, where semantic drift can accumulate, or where integrity checks can weaken. Uniform substrate treatment collapses the product to a sum: each participant implements the substrate primitives once, and every combination composes without new bridging code.

The Unix parallel makes the shift concrete. Consider composing a pipeline: `cat file.txt | grep pattern | sort | uniq -c | sort -rn`. Every element in this pipeline is technically a distinct program. Some are simple utilities (cat, sort); some are more sophisticated (grep with pattern matching). At the kernel level, they are all processes with the same interface: read from stdin, write to stdout, exit with a status. The pipeline works because the operating system treats them uniformly. If cat used one calling convention, grep another, and sort a third, the pipeline would require translation between each stage. Unix works because uniform primitives make composition trivial. Agent tool invocation benefits from the same design principle at the coordination substrate.

The office assistant parallel captures the human version. An executive assistant coordinates a meeting by using various resources: a calendar, an email system, a phone, a document repository. From the assistant's perspective, these are all resources they draw on to accomplish the task. The assistant never thinks in terms of "human coordination protocol" versus "system tool protocol." They use whichever resource is appropriate, and the same task-management structure covers all of them. Agent coordination through a substrate that treats tools and agents uniformly reflects the same intuition.

Human coordination rarely needs this specific primitive because humans have hands that can pick up tools and voices that can direct other humans through the same natural language interface. Software rarely needs this primitive because software systems typically integrate their tools statically, at compile or configuration time, and the tool boundary is invisible at runtime. Neither model handles the case of an agent dynamically discovering and invoking capabilities at runtime, across organizational boundaries, with cryptographic integrity attestation and delegation lineage preservation. That is the common case at agent scale, and it is what a substrate approach to tools addresses.

The separate-protocol-stack approach works cleanly when the ecosystem is small enough that any given agent operates within a single stack. As the ecosystem grows and workflows span multiple domains, the bridging cost multiplies. Uniform substrate treatment eliminates the bridging cost and makes tool invocation a first-class part of the same coordination fabric as agent-to-agent interaction.

Higher-consequence needs (formal supply-chain attestation for tool implementations, sandboxing and containment guarantees at substrate level, tool-versioning semantics with backward compatibility guarantees, tool composition patterns that let agents build higher-level tools out of substrate primitives, cross-organizational tool sharing with proper attribution and revenue distribution) build on this base. Without the base, agent tool use fragments into a growing collection of protocol-specific integrations, each with its own security assumptions, its own trust properties, and its own composition rules. The fragmentation limits both the reach of individual agents and the resilience of the ecosystem as a whole.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Find a tool by what it can do rather than by its name
- Invoke a tool while carrying the delegation chain from the principal
- Verify a tool is the expected implementation (unaltered, unspoofed)
- Compose multiple tools in one workflow
- Mix tools and agents freely in one workflow
- Contain tool execution within defined boundaries
- Handle tool versioning and backward compatibility
- Share tools across organizations
- Enable tools to coordinate with other tools
- Verify a tool's identity separately from where it is hosted

---

## 10. Commerce

### Is agent commerce needed?

The internet has substantial commerce infrastructure. Payment card networks (Visa, Mastercard, American Express) process billions of transactions annually. Bank-to-bank transfer systems (ACH in the US, SEPA in Europe, wire transfer globally) move value at scale. Payment gateways (Stripe, Adyen, Square, PayPal, Braintree) provide developer-friendly APIs to accept payments. E-commerce platforms (Shopify, WooCommerce, Magento) let merchants sell online. B2B payment systems (NACHA, ISO 20022) handle enterprise-scale transactions. Modern financial APIs (Plaid, Open Banking) enable account access and payment initiation. Cryptocurrency networks (Bitcoin, Ethereum, stablecoin systems) offer programmable money at global scale. Every serious commerce use case has infrastructure available, mature and well-documented, ready to integrate.

Do agents need their own commerce primitive on top of all of that? A skeptic could argue no. Agents can invoke Stripe like any other application. They can hold credentials, initiate payments, and process refunds through the existing infrastructure. Every payment gateway offers structured APIs that agents can consume. Nothing new required.

The counter-argument is that every existing commerce system was designed around a specific assumption: transactions are initiated by humans. Payment gateways expect a human clicking a button or filling out a form. E-commerce platforms display product information in ways optimized for human eyes: images, marketing copy, navigation menus, discount banners. Merchant identity is verified through processes designed for regulatory compliance with human-run businesses. Transaction receipts are formatted for human reading. Dispute resolution processes assume humans initiate disputes and provide narrative evidence. Every layer of the stack reflects the human-initiated assumption in its design choices.

Agents introduce a different pattern. Agents transact at machine speed, at machine volumes, across organizational boundaries, on behalf of principals who are absent at transaction time. The commerce infrastructure they need has different properties than human commerce infrastructure has evolved to provide.

The first difference is pricing at discovery time. Human commerce assumes a human will look at a product page, evaluate the price, and decide whether to buy. Agent commerce needs pricing available before the agent commits attention to a specific vendor. When an assistant agent needs to buy office supplies, the workflow should look like: query the substrate for suppliers matching capability and budget constraints, evaluate the returned candidates, select one, transact. The "evaluate the price" step needs to happen at discovery rather than after the agent has already invested attention in a specific merchant's product catalog. This requires prices to be machine-readable, signed by the merchant, and available as part of the discovery result rather than as a separate lookup.

The second difference is delegated purchase authority. When an assistant agent buys office supplies on behalf of a principal, the merchant needs to verify both that the payment credential is valid and that the agent has authority to make this purchase on this principal's behalf. Existing payment infrastructure verifies the credential (the card number or bank account) alone. The delegation chain from the principal to the agent to the specific purchase stays unverified. Delegation as a substrate primitive (from §3) provides this. Commerce as a substrate primitive needs to compose with delegation so that purchase authority carries the same chain-lineage properties as any other delegated action.

The third difference is cryptographic transaction records. Payment gateways issue receipts, but the receipt is in the gateway's proprietary format, stored in the gateway's proprietary systems, disputed through the gateway's proprietary processes. If Stripe processes the transaction, the record lives at Stripe. If PayPal processes it, the record lives at PayPal. If the merchant later denies the transaction happened, the buyer relies on the payment provider's records rather than on evidence they hold independently. Agent commerce at scale needs transaction records that both parties hold, signed cryptographically, verifiable independently of any specific payment provider. This is what merchant identity and substrate-level transaction receipts provide.

The fourth difference is machine-scale transaction volumes. Existing payment infrastructure carries per-transaction costs designed around human-scale transactions. Stripe charges roughly 2.9% plus $0.30 per transaction. That model works for a $50 purchase; it fails for a $0.001 API access charge. Agent-to-agent commerce may involve micro-transactions at massive volumes: fractional cents per data query, tiny amounts per computation call, small fees per compositional workflow step. Existing payment networks cannot handle these economics. Substrate-level commerce needs to accommodate transaction models that human-oriented payment infrastructure was never designed to serve.

The fifth difference is dispute and refund handling. When something goes wrong in a human transaction, the buyer files a complaint with the merchant, the merchant investigates, and if unresolved the buyer escalates to the payment provider for a chargeback. This process assumes a human buyer with narrative capacity to explain what went wrong. Agent commerce needs dispute resolution based on structured evidence: what was requested (with signed capability description and price), what was delivered (with signed confirmation), what terms applied (with signed agreement). The substrate should generate this evidence naturally as part of the transaction rather than reconstruct it after the fact from application logs.

The vending machine analogy captures part of the shift. A vending machine performs machine-scale commerce with no human at the merchant side of the transaction. It publishes prices visibly, accepts payment through a standard mechanism, delivers the product, and provides a receipt if requested. The interaction is structured, deterministic, and completes without human involvement on the merchant side. Agent commerce can look like a vending-machine interaction: capabilities published with prices, transactions completed through a substrate-standard mechanism, cryptographic evidence generated as part of the interaction.

The grocery store barcode analogy captures another dimension. Every item in a grocery store carries a machine-readable barcode encoding a stock keeping unit identifier. The register scans items, looks up prices in a database, computes total, processes payment through a card reader, and prints a receipt. The entire checkout is machine-mediated after the customer places items on the belt. Agents transacting with merchants can work the same way when the substrate provides the equivalent of the barcode (machine-readable capability descriptions), the register (structured price lookup and total computation), and the card reader (substrate-level payment mechanism).

The B2B procurement analogy captures the delegation dimension. When a company purchases supplies, the transaction typically involves a purchase order authorized by a specific person (or role) at the buying company, signed by an authorized representative at the selling company, and generating an invoice that references the purchase order. Every step carries attribution and creates a paper trail. Disputes reference the paper trail rather than requiring reconstruction from memory or generic account records. Agent commerce needs the same properties at wire speed: purchase order equivalents that carry delegation lineage, signed acceptances from the merchant, invoices that reference the delegated authority, and transaction receipts that any auditor can trace end-to-end.

The answer is yes, agent commerce is needed as a substrate primitive distinct from existing payment infrastructure. The primitive must support:

- **Machine-readable pricing at discovery.** Prices published as first-class attributes on capability descriptions, signed by the merchant, evaluable before commitment.
- **Delegated purchase authority.** Purchase authority uses the same delegation and revocation primitives as any other agent action, so merchants can verify the authority chain rather than only the payment credential.
- **Substrate-level transaction receipts.** Cryptographically signed evidence of what was requested, delivered, and agreed, held by both parties and verifiable independently of any payment provider.
- **Merchant identity as substrate primitive.** Merchants carry substrate identity with the same properties as agent identity, so buyers can verify merchant claims independently of platform-specific merchant IDs.
- **Machine-scale transaction economics.** Support for micro-transactions and high-volume commerce that human-oriented payment infrastructure cannot serve efficiently.
- **Structured dispute evidence.** Transaction records generated as part of the interaction, in formats designed for machine dispute resolution, referenced by any auditor without depending on cooperation from specific payment providers.

### Why it is needed

Commerce is coordination with money attached. Every other primitive matters more when money changes hands. Identity matters because the buyer needs to know who they are paying. Trust matters because fraudulent merchants have direct financial incentive. Delegation matters because the buyer's authority to spend has scope and limits. Discovery matters because the buyer needs to find capable merchants within budget. Communication matters because the transaction itself is a coordinated exchange. Audit matters because transactions may need to be reconstructed later. Without substrate commerce, every agent-to-merchant interaction reinvents these compositions at the application layer, and each reinvention is an integration point where interoperability breaks and dispute evidence weakens. Substrate commerce lets the coordination primitives compose naturally around transactions.

### The core use case: an assistant agent purchasing office supplies within a delegated budget

An organization gives an assistant agent authority to spend up to $500 per month on office supplies for a specific department. The assistant agent needs to discover suppliers, evaluate them, select one, and complete a purchase. The workflow crosses organizational boundaries (the assistant belongs to the buying organization, the supplier is a separate business), involves delegated authority (the assistant acts on behalf of the department, which acts on behalf of the organization), and generates financial records that must be traceable and disputable later.

Without a substrate commerce primitive:

- The assistant agent must integrate with each supplier's e-commerce system separately. If Supplier A uses Shopify, the assistant integrates with Shopify's storefront APIs. If Supplier B uses a proprietary system, the assistant integrates with that system.
- Product catalogs are HTML pages designed for human browsing, or JSON APIs with vendor-specific schemas. Comparing prices across suppliers requires the assistant to parse different formats.
- Payment goes through whichever gateway the supplier has integrated (Stripe, PayPal, Adyen, or others). The assistant either holds credentials for many gateways or works through a payment orchestration layer that adds another integration point.
- The transaction receipt is whatever format the payment gateway generates. The assistant stores it and the buying organization's finance system has to parse the receipt for accounting purposes.
- If something goes wrong (wrong item shipped, quality issue, non-delivery), the dispute process depends on the specific merchant's policies and the specific payment provider's chargeback rules. Evidence lives with the merchant or the payment provider rather than with the buyer independently.

With a substrate commerce primitive:

- The assistant agent queries the substrate for suppliers matching the required capability (office supplies), the region (relevant to shipping), the budget ceiling ($500 monthly, minus already-spent amount), and the trust tier the department requires.
- The substrate returns candidate suppliers with machine-readable capability descriptions, signed price manifests, current availability, and delivery terms. All information is verifiable at the point of discovery without visiting individual supplier websites.
- The assistant evaluates candidates using the same trust-plus-attribute pattern as any other agent selection. It selects the best fit based on capability match, trust score, price, and delivery timeline.
- The purchase transaction uses substrate verbs (QUERY, PROPOSE, PURCHASE, COMMITMENT). The assistant's purchase message carries the delegation chain from organization to department to assistant, so the supplier verifies the authority independently of the payment credential.
- The supplier's confirmation message carries substrate merchant identity, verified against the same trust primitives used at discovery. The transaction record is cryptographically signed by both parties.
- Both parties hold the complete transaction record: what was requested, what was offered, what was agreed, what the terms were, what confirmation numbers were issued. The record is verifiable end-to-end without depending on either party's private systems.
- If a dispute arises, both parties reference the same signed evidence. The organization's finance team can trace the transaction back through the delegation chain to the original authorization. The supplier can prove what was ordered and confirmed. Resolution proceeds from evidence rather than from narrative reconstruction.

The vending machine parallel captures the operational shift. The organization treats each supplier as a substrate-accessible vending machine: prices published, transactions completed through standard mechanisms, receipts generated automatically. The assistant does the equivalent of walking up to the machine, checking the price on the display, inserting the delegated authority (rather than physical currency), receiving the product, and getting a signed receipt. The whole interaction completes at machine speed without human involvement on the supplier's side. What made vending machines work at physical scale was standardization: predictable interfaces, transparent pricing, deterministic transactions. What makes agent commerce work at internet scale is the substrate equivalent.

Human commerce rarely needs this specific primitive because humans already handle the human-oriented layer of the current stack: they read product pages, evaluate options through personal judgment, and initiate transactions through familiar interfaces. Software commerce rarely needs this primitive because software components are typically integrated with specific vendors at design time; runtime purchase discovery is uncommon in traditional software. Neither model handles the case of an agent discovering and transacting with previously-unknown merchants at runtime, across organizational boundaries, on behalf of principals who are absent at transaction time. That is the common case at agent scale, and it is what substrate commerce addresses.

The existing payment infrastructure works cleanly when a specific application integrates with a specific merchant using a specific payment gateway, all decided in advance. It fragments quickly when workflows span many merchants, when the merchant selection happens at runtime through discovery, when delegation chains need to be preserved through the payment step, and when transaction evidence must be verifiable independently of any payment provider. Substrate commerce makes agent transactions portable across merchants, verifiable across parties, and integrable with the other coordination primitives.

Higher-consequence needs (cross-currency substrate transactions with real-time exchange rate binding, subscription and recurring payment semantics that survive delegation-chain changes, revenue-share attribution across composed agent workflows, escrow and staged-release payment patterns, tax-jurisdiction attribution for cross-border transactions, refund and chargeback semantics with substrate-level verification) build on this base. Without the base, agent commerce reduces to whatever integrations any specific agent stack maintains with any specific payment provider, and the interoperability needed for open agent markets fails to emerge.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Find a merchant with machine-readable pricing at query time
- Purchase within a delegated budget
- Handle very small transactions at very high volume
- Generate transaction receipts held cryptographically by both parties
- Resolve disputes with substrate-level evidence
- Handle recurring payments even when the delegation chain changes
- Support escrow and staged-release payments
- Handle cross-currency transactions
- Attribute revenue-share across composed workflows
- Attribute tax-jurisdiction responsibility for cross-border transactions

---

## 11. Audit

### Is agent audit needed?

The internet has substantial audit infrastructure. Application-layer logging is universal: syslog, structured JSON logs, and log aggregation platforms (Splunk, Elastic, Datadog, Loki) collect activity records across every serious system. Security Information and Event Management platforms (Splunk Enterprise Security, IBM QRadar, ArcSight, Microsoft Sentinel) aggregate logs across an organization's systems for security monitoring and compliance reporting. Cloud providers offer built-in audit trails (AWS CloudTrail, GCP Cloud Audit Logs, Azure Activity Log) that record every API call in cloud environments. Compliance frameworks (SOX, HIPAA, PCI-DSS, GDPR) impose specific audit requirements with well-established reporting patterns. Blockchain networks provide immutable transaction ledgers with cryptographic guarantees. Certificate Transparency (RFC 6962) established the transparency-log pattern for TLS certificate issuance. SCITT (RFC 9943, Supply Chain Integrity, Transparency, and Trust) generalizes the transparency-log pattern for supply chain integrity claims. Sigstore provides signing infrastructure for software supply chain artifacts. Verifiable data structures work in COSE and elsewhere provides the cryptographic primitives for tamper-evident records.

Do agents need their own audit primitive on top of all of that? A skeptic could argue no. SCITT was published as an IETF standard in 2025. It supports append-only signed statements with transparency proofs. Combine SCITT for high-consequence records, application logging for routine activity, SIEM for aggregation, and CloudTrail for cloud API access. The combination covers every audit case an application needs. Nothing new required.

The counter-argument runs at two levels.

At the layer level, most existing audit infrastructure is application-layer. Application logs are written by the application itself, in whatever format the application chose, with whatever attribution the application recorded. The application controls the logs. If the application is buggy, the logs may be incomplete. If the application is compromised, the logs may be falsified. If the application is decommissioned, the logs may be lost. SIEM aggregation helps by centralizing logs, but it depends on applications to send logs faithfully and on the SIEM operator to preserve them accurately. Cloud audit trails are more reliable within one cloud provider's environment, but they cover only actions that go through that provider's API and leave gaps where activity crosses provider boundaries or happens at layers below the API.

At the design level, existing audit infrastructure was built for use cases that differ from agent coordination in specific ways. Compliance frameworks are periodic and coarse-grained: quarterly SOX reports, annual HIPAA audits, event-driven GDPR data-access records. SCITT is designed for supply chain claims where each claim is a discrete high-consequence event (a software artifact release, a supplier certification). Certificate Transparency records certificate issuance events, one per certificate. Blockchain records transactions, one per state change on the chain. None of these were designed for per-agent per-action attribution at wire speed with delegation-chain preservation across organizational boundaries.

Agent audit needs specific properties that follow from what agents actually do:

The first is cryptographic attribution to the acting agent. Application logs typically say "process 12345 wrote this line" or "user X performed action Y." Agent audit needs the record to say, cryptographically and verifiably, "agent A (with this specific Agent-ID) performed this specific action at this specific time under this specific delegation from principal P." The attribution is bound to the agent's substrate identity, verifiable by anyone with the agent's public key, and independent of whether the logging infrastructure is trusted.

The second is delegation-chain preservation. When agent A delegates to agent B, and agent B invokes tool C, and tool C makes an external call, the audit record for the external call needs to preserve the whole chain: original principal, agent A, agent B, tool C. Application logs typically record only the immediate caller. SCITT records claims yet lacks native encoding for the causal chain that led to the claim. Substrate audit needs the chain because accountability questions ("who really authorized this?") depend on being able to walk the chain back to the origin.

The third is selective disclosure. Investigation of a specific incident should never require disclosure of unrelated activity by the same agent or principal. If an auditor is investigating whether agent A performed action X on date D, the audit substrate should support proving that specific claim (that action X happened or that no such action occurred) without revealing the whole history of agent A's other actions. Verifiable data structures (Merkle trees, transparency logs) support this through inclusion proofs, but the design has to make selective disclosure a first-class property.

The fourth is per-agent hash chaining. Each agent's sequence of actions should form a tamper-evident hash-chained record, so that inserting, deleting, or reordering actions after the fact leaves cryptographic evidence. This is a common pattern in high-integrity systems (git commits form hash chains; blockchain transactions form hash chains) but has to be built into the substrate audit primitive to work uniformly across all agent activity.

The fifth is cross-boundary verification. Audit evidence should be verifiable across organizational boundaries without requiring cooperation from the entity being audited. If an external auditor investigates an incident that crossed from Company A's agent to Company B's agent to Company C's tool, they should be able to verify what happened at each step from the substrate records rather than depending on each company to voluntarily produce logs in a mutually agreed format.

The notary journal analogy captures the core idea. In many jurisdictions, notaries are legally required to keep a chronological journal of every notarization they perform. The journal contains, for each entry, the notary's identity, the date and time, the type of notarization, the identity of the parties involved, and a signature. The journal is a per-notary, chronological, tamper-evident record that has legal weight independent of any central authority. If a dispute arises about whether a specific document was notarized, the journal provides the evidence. The journal never becomes a central registry; each notary keeps their own. The journal never functions as a summary; it is the primary record. Substrate agent audit has the same shape: per-agent, chronological, tamper-evident, cryptographically self-authenticating, with legal-instrument-grade weight in dispute resolution.

The chain of custody analogy captures the cross-boundary property. In evidence handling, each transfer of physical evidence from one custodian to another is recorded and signed. The record follows the evidence. Any party at any point in the chain can look back and see who has held the evidence, when transfers occurred, and whether any handoff was undocumented. Chain of custody makes evidence usable in court because it preserves the causal chain from collection to presentation. Agent audit needs the same property: each agent's participation in a workflow is recorded in a way that follows the workflow, so anyone examining the workflow later can trace what happened at each step across whatever organizational boundaries the workflow crossed.

The aviation black box analogy captures the completeness dimension. Every commercial aircraft carries a flight data recorder that captures continuous, detailed information about the aircraft's state and the flight crew's actions. When an incident happens, investigators recover the black box and reconstruct exactly what occurred. The black box records without selection; it captures everything, and investigators query the record for the specific information relevant to the incident. The record is tamper-resistant by design because the value of the black box depends on trusting its contents. Agent audit at high-consequence layers needs the same completeness property: enough detail preserved that investigators can reconstruct specific incidents from the record.

The answer is yes, agent audit is needed as a substrate primitive distinct from application-layer logging and from higher-level transparency services like SCITT. The primitive must provide:

- **Wire-level attribution records.** Every substantive action produces an audit record at the substrate layer, cryptographically bound to the acting agent's identity, generated as part of the action rather than reconstructed later from application logs.
- **Delegation-chain preservation.** Every audit record carries the delegation chain that produced the action, so investigators can walk from any action back to the originating principal.
- **Per-agent hash chaining.** Each agent's sequence of actions forms a tamper-evident hash-chained record, so tampering with any historical entry leaves cryptographic evidence.
- **Selective disclosure.** The substrate supports proofs that a specific action occurred (or that no such action occurred) without requiring disclosure of unrelated activity by the same agent.
- **Cross-boundary verifiability.** Audit evidence is verifiable across organizational boundaries without depending on cooperation from the entity being audited.
- **Composition with transparency services.** Where high-consequence records need to be publicly verifiable, the substrate composes cleanly with existing transparency services (SCITT, CT) rather than replacing them.

### Why it is needed

Every other primitive in this document produces records. Identity creates identifiers. Authorization issues credentials. Delegation records contracts. Trust computes scores. Discovery returns candidate lists. Communication carries messages. Session persists state. Semantics defines meaning. Tools handle invocations. Commerce generates transactions. Without a substrate audit primitive, all of these records live in whatever application-layer format their respective applications chose, aggregated in whatever ways their operators decided, preserved for whatever periods their retention policies specified. When an investigation later asks what actually happened, the answer depends on whoever holds the relevant application logs. Substrate audit makes the records themselves substrate primitives, tamper-evident, cross-verifiable, and independent of any specific application layer above them. It is what turns the coordination substrate from a real-time coordination surface into a coordination surface with reliable memory.

### The core use case: investigating what happened when an agent decision went wrong

An organization deploys agents to handle a range of business processes. One morning, the finance team discovers that a payment authorization went to a supplier that should have been blacklisted after a prior compliance incident. The payment cleared. Money moved. Someone made this happen, or something made this happen, and the organization needs to understand exactly what occurred.

Investigation requires answering several questions in sequence:

- Which specific agent submitted the payment authorization?
- Under what delegation was that agent operating?
- What information did the agent see when it made the decision?
- Did the agent check the blacklist, and what response did the blacklist service return?
- Did any delegation upstream authorize the payment despite the blacklist, or did the check fail silently?
- Was the blacklist database current at the time of the check?
- Are there other actions the agent took that raise similar concerns?

Without a substrate audit primitive:

- The investigation begins by requesting logs from the applications involved. Each application produces logs in its own format, at whatever granularity its developers chose, with whatever attribution its architecture supported.
- The payment system's logs show that a payment was authorized, but the attribution is to a service account rather than to a specific agent under a specific delegation.
- Whether the agent framework's logs preserve which specific delegation was active when the decision happened depends on the specific framework implementation. Reconstructing the delegation chain requires piecing together records from multiple systems that use different identifiers.
- The blacklist service's logs show that a check was made, but linking that check to the specific payment decision requires correlation by timestamp and by request parameters, with reliability that varies across implementations.
- If any of the involved systems have rotated logs, been decommissioned, or been affected by a bug that dropped log entries, the corresponding evidence is unavailable.
- Cross-organizational aspects (the supplier is an external party) require the external organization's cooperation to produce their own logs. If the supplier is uncooperative, the internal investigation stalls.
- The whole investigation depends on trusting that every application's logs are complete and unaltered. This trust is warranted for well-run applications but hard to verify from outside the application.

With a substrate audit primitive:

- Every action taken by the agent produced a substrate-level audit record cryptographically bound to the agent's Agent-ID, containing the specific action, the delegation chain that authorized it, the input parameters, the substrate verb invoked, the target agent or tool, and a timestamp.
- The audit records form a per-agent hash chain. The investigator can request the specific record for the payment authorization and verify the record's integrity, without trusting the storage system that holds it.
- The record shows the full delegation chain: originating principal, downstream delegations, current delegation. The investigator traces the chain to see where authority came from at each hop.
- The record shows what the agent invoked immediately before the payment authorization: a QUERY to the blacklist service, the parameters used, the substrate identity of the blacklist service, the response the blacklist service returned, and the timestamp. If the blacklist service returned "blocked" and the payment happened anyway, the investigator sees this immediately.
- If the blacklist service is operated by an external organization, the substrate audit record from the query includes the blacklist service's own signature on the response. The investigator verifies the response cryptographically without needing the external organization's cooperation.
- Selective disclosure lets the investigator prove exactly what happened for this specific payment without exposing unrelated activity by the same agent or principal.

The notary journal parallel maps directly. If a document appears with a notary's stamp, an investigator can request the notary's journal for the date and time in question. The journal shows whether the notarization occurred, who was present, what document was notarized, and the notary's contemporaneous notes. The journal is the primary evidence. Substrate audit records serve the same role for agent action: the primary evidence lives in a per-agent chronological tamper-evident record, and investigation queries the record for the specific event under examination.

The chain of custody parallel captures the multi-hop case. If evidence was collected at a scene, transferred to a lab, analyzed by a specialist, and presented in court, the chain of custody documentation shows each transfer, each custodian, and each period of possession. Any missing link makes the evidence inadmissible. Substrate audit for agent workflows preserves the same chain: which agent held the coordination context, what actions each agent took, what handoffs happened between agents, and what tools each agent invoked. Any missing link is visible in the record.

Human employees rarely need this specific substrate primitive because human action is typically bounded by physical presence, workplace policies, and the natural friction of manual work. When investigation is required, existing tools (interviews, documents, digital forensics on specific systems) are adequate for the scale involved. Software rarely needs this primitive because software components typically run inside single organizations with their own logging and their own compliance frameworks. Neither model handles the case of agent action that crosses organizational boundaries, executes at machine speed, involves multi-hop delegation chains, and requires cross-verifiable evidence for high-consequence disputes. That is the common case at agent scale, and it is what substrate audit addresses.

The application-layer logging and centralized transparency approaches work cleanly when the audit scope is bounded by one application's activity or by one high-consequence event stream. They fragment when the scope needs to span many agents, many delegation chains, many organizations, and many transaction types. Substrate audit makes evidence portable across boundaries, verifiable across parties, and integrable with the other coordination primitives naturally.

Higher-consequence needs (formal legal-instrument-grade audit records for regulatory compliance, cross-jurisdictional audit federation with mutual verification agreements, real-time compliance monitoring across delegation chains, verifiable time-of-action attestations for time-sensitive regulatory reporting, integration with existing transparency services (SCITT, CT) for high-consequence public records, privacy-preserving audit that lets regulated agents demonstrate compliance without disclosing sensitive operational data) build on this base. Without the base, agent activity leaves records only where applications happen to log them and only in formats those applications happen to use. Investigation, compliance, and dispute resolution reduce to trusting whoever holds the relevant logs, and trust is difficult to establish across organizational boundaries at agent scale.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Investigate what a specific agent did at a specific time
- Trace an action back through the delegation chain to its origin
- Verify that a claimed action actually happened
- Prove either that an action occurred or that no record exists for it
- Support audit across organizations
- Monitor compliance in real time across delegation chains
- Prove compliance without exposing unrelated operational data
- Provide hash-chained per-agent action sequences
- Integrate with existing transparency services (SCITT, Certificate Transparency)
- Support long-term audit archival with tamper evidence

---

## 12. Governance

### Is agent governance needed?

Existing legal and regulatory infrastructure for accountability is substantial. Contract law provides the framework for binding parties to negotiated terms across essentially every jurisdiction. Corporate signing authority defines which specific officers can bind a corporation to specific classes of commitment. Legal-entity identifier systems (LEI, D-U-N-S, Companies House registrations) provide standardized identifiers for legal persons. Digital signature laws (eIDAS in the European Union, ESIGN Act and UETA in the United States, similar frameworks across Asia and elsewhere) give electronic signatures the same legal weight as wet-ink signatures for most classes of transaction. Product liability law holds manufacturers and distributors accountable for harm caused by defective products, including software products. Emerging AI-specific regulation (the EU AI Act, various US state AI laws, sectoral regulations in finance and healthcare) begins to establish specific compliance requirements for AI-enabled systems. Regulatory enforcement bodies (financial regulators, consumer protection agencies, data protection authorities) have jurisdiction, investigative capacity, and enforcement power.

Do agents need their own governance primitive on top of all of that? A skeptic could argue no. Every legal framework required for accountable commerce already exists. Agents are software, and software has always been governed by product liability and contract law. The company that deploys the agent is the accountable party. When something goes wrong, existing legal mechanisms handle it. Adding a substrate governance primitive complicates a domain already well-served by centuries of legal development.

The counter-argument turns on the scale mismatch between existing legal instruments and agent action. Contract law was designed around human deliberation. Each contract is explicitly negotiated, reviewed, and signed by parties who are physically or digitally present. This scales through human attention: a party can only be a party to as many contracts as its human representatives can review. Corporate signing authority follows the same pattern: officers can bind the corporation to as many commitments as they can personally attend to. Agents transact at rates that exceed any human's review capacity, on behalf of principals who are absent at transaction time. The scaling assumption underlying contract law breaks down when the acting party is an agent operating at machine speed.

Product liability treats software as a product. This works when the software has predictable behavior specified by its author, and the harm caused by failures maps to defective-product frameworks (a bug caused incorrect output, and the manufacturer is on the hook for damages resulting from that defect). Agents complicate the product framing because they make decisions on behalf of principals, enter into commitments with third parties, and produce outcomes that emerge from the interaction of the agent's design with the specific delegation and specific circumstances. The line between "the product malfunctioned" and "the agent made a bad decision within its authorized scope" becomes hard to draw. Product liability was designed for tools; agents behave more like delegated representatives, and existing law lacks a clean primitive for that intermediate category.

Digital signature laws provide the closest existing analog to what substrate governance needs. eIDAS, ESIGN, and their counterparts explicitly give electronic signatures legal weight equivalent to wet-ink signatures. They did this by defining a substrate-level primitive (the electronic signature, with defined technical properties) and having legal systems recognize that primitive as evidence of the signer's intent. Substrate governance for agents needs the same shape: a substrate-level primitive that binds agent action to an accountable natural or legal person, with legal systems recognizing the primitive as evidence of the accountable person's authorization.

Emerging AI regulation is filling some of this space, but with a different focus. The EU AI Act regulates categories of AI applications by risk level and imposes compliance requirements. Sectoral regulation in finance and healthcare imposes domain-specific compliance requirements on AI-enabled systems. These frameworks regulate outcomes and processes; they leave the substrate-level mechanism for binding agent action to accountable persons unaddressed. They can require that such a mechanism exist, and increasingly they do, but the mechanism itself remains an open substrate question.

The gap between attribution and accountability is worth naming directly. The audit primitive (from §11) provides attribution: cryptographic evidence of which agent performed which action under which delegation. Attribution answers "what happened, and who did it at the substrate level." Governance answers a different question: "who is responsible for this action in a way that legal systems can act on?" Attribution alone tells an investigator that agent A executed transaction T under delegation D. Governance is what binds agent A, or the delegation chain behind it, to a natural or legal person who can be sued, subpoenaed, regulated, or held liable in a specific jurisdiction. Without that bind, cryptographic attribution stops at the substrate boundary and legal action cannot proceed.

The power of attorney analogy captures the shape of what substrate governance provides. A power of attorney is a legal instrument that binds actions taken by an appointed representative to the principal who appointed them. The principal remains legally responsible for actions the representative takes within the granted scope. When a signed power of attorney is presented, courts and other institutions treat the representative's actions as if the principal had taken them personally. The instrument itself is what makes the delegation legally durable and enforceable. Substrate governance for agents needs to produce the equivalent: a legally durable, enforceable bind between agent action and an accountable person.

The notarization analogy captures the evidentiary weight. A notary's stamp and journal entry create a legal-instrument-grade record that a specific action (a signature, an oath, a document acknowledgment) occurred at a specific time with a specific party present. Notarized documents are treated as strong evidence in court because the notarization mechanism was designed to produce evidence with legal weight. Substrate governance for agents needs to produce records with similar evidentiary weight: substrate-level evidence that specific actions were authorized by specific accountable persons, in a form legal systems recognize.

The corporate signing officer analogy captures the delegation dimension. Corporate law defines which officers (CEO, CFO, authorized signatories) can bind a corporation to specific classes of commitment. When one of these officers signs a contract on behalf of the corporation, the corporation is legally bound rather than the officer personally. The mechanism works because corporate law recognizes the officer's authority as an extension of the corporation's legal personhood. Substrate governance for agents extends this pattern: agents bound to a corporation through substrate governance can commit the corporation to specific classes of action, and the corporation is legally bound rather than the agent (or the agent's developer) being personally on the hook.

The ship captain analogy captures the cross-jurisdictional dimension. A ship's captain, operating in a foreign port far from the shipping company's headquarters, can bind the company to contracts (for cargo, for repairs, for port fees) that the company must honor. Maritime law developed this pattern over centuries because commerce across jurisdictions required a way for on-scene representatives to act with legally durable authority. Substrate governance for agents needs the cross-jurisdictional property built in: an agent operating in a different jurisdiction than its principal should still be able to bind the principal in ways that are recognized where the action occurred and in the principal's home jurisdiction.

The answer is yes, agent governance is needed as a substrate primitive distinct from existing legal frameworks and from emerging AI regulation. The primitive must provide:

- **Accountability anchor.** Every agent participating in coordination is bound to a natural or legal person who is accountable for the agent's actions under existing legal frameworks. The bind is verifiable at the substrate layer.
- **Legal-instrument-grade evidence.** Substrate records of authorization, delegation, and action produce evidence with the same weight in legal proceedings as notarized documents, digitally signed contracts, or corporate signing officer resolutions.
- **Cross-jurisdictional operation.** The substrate primitive is designed to compose with legal frameworks in multiple jurisdictions, so agents operating across borders can produce evidence usable in each relevant jurisdiction.
- **Delegation-chain accountability.** Where delegation chains connect an acting agent to an ultimate principal, the accountability primitive follows the chain, so the principal remains accountable for actions the agent takes within the delegated scope.
- **Enforceable revocation and transfer.** Accountability can be transferred (a subsidiary sold to another company, an agent reassigned from one principal to another) or revoked (a delegation withdrawn) through mechanisms the substrate supports and legal systems can act on.
- **Composition with existing legal frameworks.** The primitive complements contract law, digital signature law, corporate law, and emerging AI regulation rather than replacing them. Substrate governance provides the substrate-level bind that existing legal frameworks can recognize and act on.

### Why it is needed

Every other primitive in this document supports what agents can do. Governance supports what agents are responsible for. Attribution tells you the agent's action was cryptographically bound to its identity. Delegation tells you the chain of authority that produced the action. Trust tells you the agent's track record. Audit tells you the action is verifiable after the fact. But none of these primitives, alone or together, answer the question a court, regulator, or aggrieved party must answer: who is responsible for this in a way legal systems can act on? Without substrate governance, agent coordination produces action without accountability, and existing legal frameworks either force impractical constraints (every action requires human sign-off, which fails to scale) or default to broad-brush liability that discourages beneficial deployment. Substrate governance makes agent coordination legally durable at scale. It is what lets independent agents remain accountable to natural or legal persons even while operating at machine speed across organizational boundaries.

### The core use case: a commercial dispute over agent authority to bind its principal

An organization gives its assistant agent authority to enter into procurement contracts within a defined scope. The assistant enters into a contract with a supplier for a significant purchase. When the shipment arrives, one term in the contract becomes disputed. The supplier claims the assistant agreed to shipping terms that transfer risk at the port of origin. The buyer's finance team disputes this, arguing the assistant lacked authority to accept those specific terms. Both parties are in the same jurisdiction. The commercial value is significant enough that formal legal action is possible. The court needs to answer a specific question: did the assistant have authority to bind the buyer to the disputed terms? That question is what governance addresses.

Without a substrate governance primitive:

- The buyer must establish, through evidence the buyer controls, that its assistant lacked authority to agree to the disputed shipping terms. The evidence lives in the buyer's application logs, the buyer's agent configuration, and the buyer's internal authorization records.
- The supplier must establish that its agent reasonably relied on the terms the buyer's assistant appeared to accept. The supplier's evidence lives in the supplier's application logs and the supplier's agent's records of the exchange.
- Neither party has substrate-level evidence of the other party's authorization structure. The buyer cannot prove that its principal never authorized those shipping terms with evidence the court will accept as conclusive.
- The court must sort through application-layer records from two separate systems, in two different formats, with two different authorization models, and determine which party's account is more credible.
- The proceeding is expensive, slow, and depends heavily on the specific court's willingness to interpret novel evidence about agent-mediated transactions.

With a substrate governance primitive:

- The buyer's assistant carries substrate-level evidence of the specific delegation it was operating under. The delegation specifies which classes of terms the assistant may accept, what commitments are within scope, and which specific human or organizational principal is accountable for actions within that scope.
- The supplier's agent carries the equivalent evidence for its side. Both parties' delegation records were generated as part of the substrate coordination rather than reconstructed after the fact.
- The audit records for the transaction (from §11) include the delegation chains as they applied at each step of the exchange. If the buyer's assistant accepted terms that fell outside its delegated scope, the substrate evidence shows this directly. If the terms were within scope, the substrate evidence shows this too.
- The delegation evidence is legal-instrument-grade in the same way a signed power of attorney is legal-instrument-grade. The court recognizes substrate governance records as evidence of authorization, because the substrate primitive was designed to compose with the digital signature laws already recognized in that jurisdiction.
- The accountable natural or legal persons are identifiable directly from the substrate records. The buyer's assistant is bound to the buying company. The supplier's agent is bound to the supplying company. Neither the agents themselves nor their developers are directly on the hook; the accountable legal persons are visible in the substrate.
- The proceeding, whether in court, arbitration, or regulatory review, uses substrate evidence as the primary record. Application logs remain relevant but as supplementary evidence.

The cross-border extension follows directly. If the buyer and supplier are in different jurisdictions, substrate governance evidence works the same way in each jurisdiction, because the primitive was designed to compose with the digital signature frameworks (eIDAS, ESIGN, and their counterparts) that already recognize substrate-level electronic evidence across borders. Enforcement across jurisdictions still requires a treaty basis, mutual recognition of judgments, or an arbitration clause, but the evidence itself is portable in a way that application-layer logs cannot match. Cross-border adds jurisdictional variation on top of the substrate mechanism rather than requiring a different substrate mechanism.

The power of attorney parallel maps directly. When a power of attorney is presented in a legal proceeding, the court treats the representative's actions as if the principal had taken them personally, within the scope granted in the instrument. Substrate governance records for agent action provide the equivalent evidence: the agent's action was taken within a specific scope granted by a specific principal, and the principal is bound to the action in the same way a principal is bound to actions taken by an appointed representative. The instrument itself makes the delegation legally durable across time and jurisdictions.

The digital signature parallel maps to the substrate mechanism itself. eIDAS and ESIGN never replaced signatures; they defined a substrate-level primitive (the electronic signature, with specific technical properties) and had legal systems recognize the primitive as evidence of the signer's intent. Before those laws, electronically-signed contracts were legally uncertain in many jurisdictions. After them, electronic signatures became a durable substrate primitive that commerce at scale could rely on. Substrate governance for agents is the equivalent step for agent-mediated commerce: a substrate-level primitive with specific technical properties that legal systems can recognize as evidence of the accountable person's authorization.

Human coordination handles accountability through the mechanisms named above (contract law, corporate signing authority, notarization, digital signatures) because human coordination scales through human deliberation. Software coordination handles accountability through product liability and vendor contracts because software components typically operate under specific vendor relationships. Neither model handles the case of agents transacting at machine speed across organizational boundaries, with delegation chains spanning multiple parties, in jurisdictions that vary in their treatment of AI-mediated action. That is the common case at agent scale, and it is what substrate governance addresses.

The existing legal frameworks and emerging AI regulation approach work cleanly when transactions are between well-known parties operating under pre-negotiated terms with clear human oversight of each significant action. They fragment when agents transact at scale with parties they discover at runtime, when delegation chains cross jurisdictions, and when the volume of transactions exceeds what human review can practically cover. Substrate governance makes agent coordination legally durable at scale without requiring every transaction to fall through human hands or every jurisdiction to reinvent the accountability mechanism.

Higher-consequence needs (jurisdiction-specific compliance overlays for regulated industries, cross-border mutual recognition frameworks for substrate governance records, substrate-level compliance monitoring for regulated agent categories, transfer and revocation of accountability across corporate transitions, integration with existing legal-entity identifier systems for corporate accountability, legal treatment of composed agent workflows where multiple accountable persons participate) build on this base. Without the base, agent coordination reduces to the accountability mechanisms that existing frameworks provide, which were built for human-scale deliberation and vendor-scale software relationships. Neither scales to what agent populations are producing now, and legal systems will impose their own solutions if a substrate mechanism fails to emerge. The choice is between substrate governance built collaboratively across the ecosystem and regulatory frameworks imposed by individual jurisdictions in response to specific incidents. Substrate governance is the option that keeps agent coordination broadly viable across the widest range of use cases.


### Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Bind an agent's action to a natural or legal person accountable for it
- Provide legal-instrument-grade evidence of authorization for court proceedings
- Support cross-jurisdictional recognition of substrate evidence
- Transfer accountability across corporate transitions (mergers, sales, restructuring)
- Revoke accountability through delegation withdrawal
- Support jurisdiction-specific compliance requirements
- Integrate with existing legal-entity identifier systems (LEI, D-U-N-S)
- Handle composed workflows where multiple accountable persons participate
- Support agent action under regulated industry frameworks (finance, healthcare)
- Enable substrate-level compliance monitoring for regulated agent categories

---

## How to Read and Use This Document

The primitives and analyses above are one architect's view. They reflect the author's judgment about which primitives matter for a coordination substrate that agent systems require at scale. Readers will disagree with specific selections. That is expected.

This document is offered as a common frame for evaluating agent standards proposals. When reading a new draft, working group scope, or BoF charter, one useful test is: which of these primitives does the proposal address? What use case within the primitive does it solve? Does the proposal justify the primitive it addresses, or is the primitive assumed? A proposal that names its primitive, names the use case, and grounds both in a real deployment need is easier to evaluate than one that describes solution mechanics without stating what problem the mechanics address.

The document is deliberately protocol-agnostic. Multiple protocols may address the same use case. A specific protocol may address use cases across multiple primitives; another may address a single use case in depth. Neither shape is inherently correct. The framing exists to make comparison tractable.

The document is deliberately opinionated. Consensus documents converge on the least controversial framing, which is often the least useful. This document takes positions the author is prepared to defend and welcomes correction where the positions turn out to be wrong.

## Feedback

Corrections, disagreements, and additions are welcome. Commentary is best framed as a specific claim about a specific primitive or use case, so that the framing can be refined iteratively rather than argued in aggregate.
