# 3. Delegation

## Is agent delegation needed?

The word "agent" itself embeds the concept of delegation. An agent is one who acts on behalf of another. That relationship, someone asking someone else to perform a task, is delegation. Without delegation, an entity is software executing its programmed code without direction. With delegation, it becomes an agent operating within a principal's mandate. Delegation is what makes an entity an agent at all.

Delegation is well-understood in human affairs. Corporate officers delegate authority to subordinates. Power of attorney lets one person act on another's behalf. Real estate agents are delegated to sell houses. Attorneys are delegated to represent clients. In software, OAuth delegated authorization is one of the most successful protocols on the internet, letting a user grant a service permission to act within specific scopes.

The Authorization section argued that agent authorization must carry chain lineage across organizational boundaries. That argument covered much of what agent delegation looks like at runtime. So do agents really need a separate Delegation primitive on top of the Authorization primitive we just established?

A skeptic could argue no. If Authorization already handles chain lineage and attenuation, then delegation is just the shape authorization takes when multiple hops are involved. Combine the two, reduce complexity, and call it done.

The counter-argument is that delegation and authorization operate on different axes. Delegation is the act of asking. It answers "who asked whom to do this, and for what purpose?" Authorization is the check on permission. It answers "may this specific action happen here, now, in this context?" Delegation is universal for agents; every action an agent takes was delegated to it by someone. Authorization is context-dependent; different actions require different levels, and some actions require none at all.

A concrete example makes the distinction plain. When a personal assistant agent searches public news articles at its principal's request, no authorization is needed (the information is public), but the search still exists because someone asked for it. The delegation is present; the authorization is absent. When the same agent purchases a subscription to a paywalled service using its principal's credit card, both delegation and authorization are present. When the agent, without being asked, begins purchasing subscriptions to random services, neither delegation nor authorization is present, and the agent has stopped acting as an agent at all.

The distinction can be captured in a two-by-two matrix showing how delegation and authorization combine across possible action types:

|                | Authorization required                                                                | No authorization required                                                              |
| -------------- | ------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| **Delegated**   | Legitimate agent action, receiver checks permission before proceeding                 | Legitimate agent action, no permission check needed                                    |
|                | *Agent purchases a paywalled subscription using principal's credit card*              | *Agent searches public news at principal's request*                                    |
| **Undelegated** | Attempted action outside any mandate, receiver should block                           | Software executing code with no principal directing it                                 |
|                | *Entity attempts purchase without being asked; the receiver's authorization check fails* | *Software running without direction; no agent behavior taking place*                   |

The two axes are independent. Agent behavior appears only in the top row: some agent actions require authorization checks, others require none, but every agent action is delegated. The bottom row shows either attempted actions that fall outside any mandate (which receivers should block) or entities that are simply running code with no principal directing them (which lies outside agent behavior entirely).

The real-world parallel makes the axis distinction clearer. A real estate agent has been delegated to sell your house. The delegation is broad: represent you in negotiations, arrange showings, coordinate with buyers. Within that delegation, various actions require various levels of authorization. Some require your explicit sign-off (accepting a specific offer). Others require none (showing the house to interested buyers). Some are prohibited regardless of your delegation (misrepresenting material facts, discriminating against buyers based on protected classes). Delegation opens the door to a range of actions. Authorization determines which specific actions within that range are permissible in specific contexts. The two operate on distinct axes.

Attorneys work the same way. You delegate an attorney to represent you in a matter. Within that delegation, they take many actions (drafting filings, communicating with opposing counsel, making tactical decisions). Some require your specific authorization (settling the case, waiving privilege). Some are automatic within the delegation (routine communications). Some are prohibited regardless of your instructions (subornation of perjury, disclosure of privileged information). Delegation and authorization together produce the space in which the attorney legitimately acts.

Beyond this axis distinction, four specific cases require delegation as a distinct concern that authorization alone cannot cleanly express:

**Pre-authorization.** Grant authority for future actions when the principal will be unavailable. "My assistant may approve invoices under $500 while I am on vacation for the next two weeks." This is delegation established in advance, rather than authorization at the point of action.

**Conditional delegation.** Grant authority that activates based on future events. "If a hotel booking exceeds my monthly cap, my agent may charge the excess to my personal card." The condition is baked into the delegation contract; the receiver evaluates it at runtime against the framework the principal established earlier.

**Transitive delegation.** Grant the right to sub-delegate. "The service I invoke may in turn invoke other services on my behalf, provided each sub-delegation is bounded by the same purpose." Authorization handles a single action. Delegation of delegation is a separate governance decision about who else may act within the frame.

**Temporal and purpose scoping.** Frame authority by time window and purpose rather than by specific action. "For the purpose of managing my child's tuition over the next four years, my agent may authorize related transactions." Purpose scoping cannot be expressed as a list of allowed actions; it requires a framing statement that receivers evaluate case by case.

At small scale, delegation and authorization can be conflated because a single principal typically delegates a single agent to perform a single well-scoped task, and the authorization check reduces to "did the principal actually delegate this?" At scale, with agents delegated for broad purposes across time, delegating to sub-agents, and operating across organizational boundaries, delegation becomes a distinct governance primitive that establishes the frame within which authorization operates.

The answer is yes, delegation is needed as a primitive distinct from authorization. Delegation is the constitutive act that makes an entity an agent, and it operates on a different axis from the authorization check that governs specific actions within the delegated frame.

## Why it is needed

Agent delegation gives principals a way to grant a purpose to an agent, an ongoing mandate to act on the principal's behalf, that persists across time and across many specific actions. Authorization tokens can encode point-in-time permissions for specific actions. Delegation encodes the relationship itself: who delegated whom, for what purpose, with what scope, for how long, and with what conditions on further sub-delegation. Every agent action inherits its purpose from a delegation contract. Authorization checks apply variably depending on the action, but delegation is present in every case. Without delegation as a distinct primitive, agent systems lose the ability to distinguish "acting on behalf of X for purpose Y" from "software running without direction that happens to comply with Y."

## The core use case: pre-authorized action while the principal is unavailable

An executive is leaving on a two-week international trip. During the trip, they will be reachable intermittently but cannot respond to every routine request in real time. They want their assistant agent to keep operations moving without requiring live approval for each action. Before departing, they set up a delegation to the assistant agent that covers:

- Approval of vendor invoices under $2,000 that match previously approved contracts
- Response to project inquiries from known partners
- Scheduling of meetings for after the return date
- Sub-delegation to the accountant's agent for tax-deadline items

This is more than a single authorization. It is a governance act that establishes a framework within which many future authorizations can be evaluated. The delegation records:

- Who is delegating (the executive's identity, cryptographically bound)
- Who is being delegated to (the assistant agent's identity, cryptographically bound)
- What is being delegated (a purpose-scoped set of actions with specific limits)
- When it applies (start and end dates, plus conditional activation rules)
- What sub-delegations are allowed (accountant's agent for tax items, no further)
- How to revoke it (a signed withdrawal that propagates to receivers within a bounded time)

Each specific action the assistant agent takes during the delegation window is subject to authorization checks at receivers where applicable. The receiver evaluates the action against the delegation framework: does the vendor invoice match a previously approved contract? Is the invoice under $2,000? Is the current date within the delegation window? Has the delegation been revoked? All of these questions read the delegation contract established in advance. Some actions during the window require no authorization at all (responding to a general project inquiry, forwarding a public status update), but every action is still delegated: the assistant is acting because the executive asked it to, for a purpose the executive defined.

The corporate analog is direct. When a CEO leaves the office on an extended trip, they typically issue a delegation of authority to a specific officer for specific decisions during the absence. The delegation is a formal act, often documented, often bounded by specific limits and purposes. When the officer signs an approval during the CEO's absence, that signature is authorized by the pre-established delegation. Within the same delegation, the officer takes many actions that require no separate authorization at all: coordinating with staff, following up on prior commitments, communicating with vendors within the delegated scope. Both the delegated actions requiring authorization and the delegated actions requiring none are legitimate expressions of the delegation.

Human employees rarely need explicit delegation primitives at agent scale because human employees typically operate under well-defined roles with pre-existing authority granted through HR processes. When employees exceed their normal authority, they route through explicit approval workflows. Software rarely needs delegation primitives because software runs under the account that installed it and inherits that account's permissions statically, with the software itself having no independent purpose beyond executing its code. Neither model handles the case of an agent operating during a principal's unavailability, with pre-authorized bounded authority that spans time windows and conditional activation, where every action inherits its legitimacy from the initial delegation act. That case is common in agent deployments and grows more common as agents take on employee-like responsibilities that require operating during off-hours, weekends, and vacations.

Higher-consequence needs (cryptographic delegation contracts with legal-instrument weight, revocation propagation across long delegation chains, delegation of the right to delegate under bounded conditions, purpose-scoped authority that outlives specific sessions, cross-organization delegation with different trust anchors) build on this base. Without the base, agent action during principal unavailability reduces to either "the agent cannot act while the principal is offline" or "the agent acts without meaningful bounds," both of which fail the practical requirements of real agent deployments.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Establish authority for an agent to act on someone's behalf
- Delegate while the principal is unavailable (traveling, in surgery, off-duty)
- Delegate for a specific period of time
- Delegate with scope constraints (what the agent may do)
- Delegate with conditional triggers (only if X)
- Create sub-delegations (one agent delegates to another)
- Transfer a delegation to a different agent
- Revoke a delegation before it expires
- Delegate narrower authority through sub-delegation
- Handle delegation when the principal changes (retirement, transfer)

---

[← Authorization](02-authorization.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Trust →](04-trust.md)
