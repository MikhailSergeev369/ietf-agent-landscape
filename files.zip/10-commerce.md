# 10. Commerce

## Is agent commerce needed?

The internet has substantial commerce infrastructure. Payment card networks (Visa, Mastercard, American Express) process billions of transactions annually. Bank-to-bank transfer systems (ACH in the US, SEPA in Europe, wire transfer globally) move value at scale. Payment gateways (Stripe, Adyen, Square, PayPal, Braintree) provide developer-friendly APIs to accept payments. E-commerce platforms (Shopify, WooCommerce, Magento) let merchants sell online. B2B payment systems (NACHA, ISO 20022) handle enterprise-scale transactions. Modern financial APIs (Plaid, Open Banking) enable account access and payment initiation. Cryptocurrency networks (Bitcoin, Ethereum, stablecoin systems) offer programmable money at global scale. Every serious commerce use case has infrastructure available, mature and well-documented, ready to integrate.

Do agents need their own commerce primitive on top of all of that? A skeptic could argue no. Agents can invoke Stripe like any other application. They can hold credentials, initiate payments, and process refunds through the existing infrastructure. Every payment gateway offers structured APIs that agents can consume. Nothing new required.

The counter-argument is that every existing commerce system was designed around a specific assumption: transactions are initiated by humans. Payment gateways expect a human clicking a button or filling out a form. E-commerce platforms display product information in ways optimized for human eyes: images, marketing copy, navigation menus, discount banners. Merchant identity is verified through processes designed for regulatory compliance with human-run businesses. Transaction receipts are formatted for human reading. Dispute resolution processes assume humans initiate disputes and provide narrative evidence. Every layer of the stack reflects the human-initiated assumption in its design choices.

Agents introduce a different pattern. Agents transact at machine speed, at machine volumes, across organizational boundaries, on behalf of principals who are absent at transaction time. The commerce infrastructure they need has different properties than human commerce infrastructure has evolved to provide.

The first difference is pricing at discovery time. Human commerce assumes a human will look at a product page, evaluate the price, and decide whether to buy. Agent commerce needs pricing available before the agent commits attention to a specific vendor. When an assistant agent needs to buy office supplies, the workflow should look like: query the substrate for suppliers matching capability and budget constraints, evaluate the returned candidates, select one, transact. The "evaluate the price" step needs to happen at discovery rather than after the agent has already invested attention in a specific merchant's product catalog. This requires prices to be machine-readable, signed by the merchant, and available as part of the discovery result rather than as a separate lookup.

The second difference is delegated purchase authority. When an assistant agent buys office supplies on behalf of a principal, the merchant needs to verify both that the payment credential is valid and that the agent has authority to make this purchase on this principal's behalf. Existing payment infrastructure verifies the credential (the card number or bank account) alone. The delegation chain from the principal to the agent to the specific purchase stays unverified. Delegation as a substrate primitive (from [§3](03-delegation.md)) provides this. Commerce as a substrate primitive needs to compose with delegation so that purchase authority carries the same chain-lineage properties as any other delegated action.

The third difference is cryptographic transaction records. Payment gateways issue receipts, but the receipt is in the gateway's proprietary format, stored in the gateway's proprietary systems, disputed through the gateway's proprietary processes. If Stripe processes the transaction, the record lives at Stripe. If PayPal processes it, the record lives at PayPal. If the merchant later denies the transaction happened, the buyer relies on the payment provider's records rather than on evidence they hold independently. Agent commerce at scale needs transaction records that both parties hold, signed cryptographically, verifiable independently of any specific payment provider. This is what merchant identity and substrate-level transaction receipts provide.

The fourth difference is machine-scale transaction volumes. Existing payment infrastructure carries per-transaction costs designed around human-scale transactions. Stripe charges roughly 2.9% plus $0.30 per transaction. That model works for a $50 purchase; it fails for a $0.001 API access charge. Agent-to-agent commerce may involve micro-transactions at massive volumes: fractional cents per data query, tiny amounts per computation call, small fees per compositional workflow step. Existing payment networks cannot handle these economics. Substrate-level commerce needs to accommodate transaction models that human-oriented payment infrastructure was never designed to serve.

The fifth difference is dispute and refund handling. When something goes wrong in a human transaction, the buyer files a complaint with the merchant, the merchant investigates, and if unresolved the buyer escalates to the payment provider for a chargeback. This process assumes a human buyer with narrative capacity to explain what went wrong. Agent commerce needs dispute resolution based on structured evidence: what was requested (with signed capability description and price), what was delivered (with signed confirmation), what terms applied (with signed agreement). The substrate should generate this evidence naturally as part of the transaction rather than reconstruct it after the fact from application logs.

The vending machine analogy captures part of the shift. A vending machine performs machine-scale commerce with no human at the merchant side of the transaction. It publishes prices visibly, accepts payment through a standard mechanism, delivers the product, and provides a receipt if requested. The interaction is structured, deterministic, and completes without human involvement on the merchant side. Agent commerce can look like a vending-machine interaction: capabilities published with prices, transactions completed through a substrate-standard mechanism, cryptographic evidence generated as part of the interaction.

The grocery store barcode analogy captures another dimension. Every item in a grocery store carries a machine-readable barcode encoding a stock keeping unit identifier. The register scans items, looks up prices in a database, computes total, processes payment through a card reader, and prints a receipt. The entire checkout is machine-mediated after the customer places items on the belt. Agents transacting with merchants can work the same way when the substrate provides the equivalent of the barcode (machine-readable capability descriptions), the register (structured price lookup and total computation), and the card reader (substrate-level payment mechanism).

The B2B procurement analogy captures the delegation dimension. When a company purchases supplies, the transaction typically involves a purchase order authorized by a specific person (or role) at the buying company, signed by an authorized representative at the selling company, and generating an invoice that references the purchase order. Every step carries attribution and creates a paper trail. Disputes reference the paper trail rather than requiring reconstruction from memory or generic account records. Agent commerce needs the same properties at wire speed: purchase order equivalents that carry delegation lineage, signed acceptances from the merchant, invoices that reference the delegated authority, and transaction receipts that any auditor can trace end-to-end.

The answer is yes, agent commerce is needed as a substrate primitive distinct from existing payment infrastructure. The primitive must support:

- **Machine-readable pricing at discovery.** Prices published as first-class attributes on capability descriptions, signed by the merchant, evaluable before commitment.
- **Delegated purchase authority.** Purchase authority uses the same delegation and revocation primitives as any other agent action, so merchants can verify the authority chain rather than only the payment credential.
- **Substrate-level transaction receipts.** Cryptographically signed evidence of what was requested, delivered, and agreed, held by both parties and verifiable independently of any payment provider.
- **Merchant identity as substrate primitive.** Merchants carry substrate identity with the same properties as agent identity, so buyers can verify merchant claims independently of platform-specific merchant IDs.
- **Machine-scale transaction economics.** Support for micro-transactions and high-volume commerce that human-oriented payment infrastructure cannot serve efficiently.
- **Structured dispute evidence.** Transaction records generated as part of the interaction, in formats designed for machine dispute resolution, referenced by any auditor without depending on cooperation from specific payment providers.

## Why it is needed

Commerce is coordination with money attached. Every other primitive matters more when money changes hands. Identity matters because the buyer needs to know who they are paying. Trust matters because fraudulent merchants have direct financial incentive. Delegation matters because the buyer's authority to spend has scope and limits. Discovery matters because the buyer needs to find capable merchants within budget. Communication matters because the transaction itself is a coordinated exchange. Audit matters because transactions may need to be reconstructed later. Without substrate commerce, every agent-to-merchant interaction reinvents these compositions at the application layer, and each reinvention is an integration point where interoperability breaks and dispute evidence weakens. Substrate commerce lets the coordination primitives compose naturally around transactions.

## The core use case: an assistant agent purchasing office supplies within a delegated budget

An organization gives an assistant agent authority to spend up to $500 per month on office supplies for a specific department. The assistant agent needs to discover suppliers, evaluate them, select one, and complete a purchase. The workflow crosses organizational boundaries (the assistant belongs to the buying organization, the supplier is a separate business), involves delegated authority (the assistant acts on behalf of the department, which acts on behalf of the organization), and generates financial records that must be traceable and disputable later.

Without a substrate commerce primitive:

- The assistant agent must integrate with each supplier's e-commerce system separately. If Supplier A uses Shopify, the assistant integrates with Shopify's storefront APIs. If Supplier B uses a proprietary system, the assistant integrates with that system.
- Product catalogs are HTML pages designed for human browsing, or JSON APIs with vendor-specific schemas. Comparing prices across suppliers requires the assistant to parse different formats.
- Payment goes through whichever gateway the supplier has integrated (Stripe, PayPal, Adyen, or others). The assistant either holds credentials for many gateways or works through a payment orchestration layer that adds another integration point.
- The transaction receipt is whatever format the payment gateway generates. The assistant stores it and the buying organization's finance system has to parse the receipt for accounting purposes.
- If something goes wrong (wrong item shipped, quality issue, non-delivery), the dispute process depends on the specific merchant's policies and the specific payment provider's chargeback rules. Evidence lives with the merchant or the payment provider rather than with the buyer independently.

With a substrate commerce primitive:

- The assistant agent queries the substrate for suppliers matching the required capability (office supplies), the region (relevant to shipping), the budget ceiling ($500 monthly, minus already-spent amount), and the trust tier the department requires.
- The substrate returns candidate suppliers with machine-readable capability descriptions, signed price manifests, current availability, and delivery terms. All information is verifiable at the point of discovery without visiting individual supplier websites.
- The assistant evaluates candidates using the same trust-plus-attribute pattern as any other agent selection. It selects the best fit based on capability match, trust score, price, and delivery timeline.
- The purchase transaction uses substrate verbs (QUERY, PROPOSE, PURCHASE, COMMITMENT). The assistant's purchase message carries the delegation chain from organization to department to assistant, so the supplier verifies the authority independently of the payment credential.
- The supplier's confirmation message carries substrate merchant identity, verified against the same trust primitives used at discovery. The transaction record is cryptographically signed by both parties.
- Both parties hold the complete transaction record: what was requested, what was offered, what was agreed, what the terms were, what confirmation numbers were issued. The record is verifiable end-to-end without depending on either party's private systems.
- If a dispute arises, both parties reference the same signed evidence. The organization's finance team can trace the transaction back through the delegation chain to the original authorization. The supplier can prove what was ordered and confirmed. Resolution proceeds from evidence rather than from narrative reconstruction.

The vending machine parallel captures the operational shift. The organization treats each supplier as a substrate-accessible vending machine: prices published, transactions completed through standard mechanisms, receipts generated automatically. The assistant does the equivalent of walking up to the machine, checking the price on the display, inserting the delegated authority (rather than physical currency), receiving the product, and getting a signed receipt. The whole interaction completes at machine speed without human involvement on the supplier's side. What made vending machines work at physical scale was standardization: predictable interfaces, transparent pricing, deterministic transactions. What makes agent commerce work at internet scale is the substrate equivalent.

Human commerce rarely needs this specific primitive because humans already handle the human-oriented layer of the current stack: they read product pages, evaluate options through personal judgment, and initiate transactions through familiar interfaces. Software commerce rarely needs this primitive because software components are typically integrated with specific vendors at design time; runtime purchase discovery is uncommon in traditional software. Neither model handles the case of an agent discovering and transacting with previously-unknown merchants at runtime, across organizational boundaries, on behalf of principals who are absent at transaction time. That is the common case at agent scale, and it is what substrate commerce addresses.

The existing payment infrastructure works cleanly when a specific application integrates with a specific merchant using a specific payment gateway, all decided in advance. It fragments quickly when workflows span many merchants, when the merchant selection happens at runtime through discovery, when delegation chains need to be preserved through the payment step, and when transaction evidence must be verifiable independently of any payment provider. Substrate commerce makes agent transactions portable across merchants, verifiable across parties, and integrable with the other coordination primitives.

Higher-consequence needs (cross-currency substrate transactions with real-time exchange rate binding, subscription and recurring payment semantics that survive delegation-chain changes, revenue-share attribution across composed agent workflows, escrow and staged-release payment patterns, tax-jurisdiction attribution for cross-border transactions, refund and chargeback semantics with substrate-level verification) build on this base. Without the base, agent commerce reduces to whatever integrations any specific agent stack maintains with any specific payment provider, and the interoperability needed for open agent markets fails to emerge.

## Additional use cases

This primitive covers many specific scenarios. The list below is illustrative and welcomes additions.

- Find a merchant with machine-readable pricing at query time
- Purchase within a delegated budget
- Handle very small transactions at very high volume
- Generate transaction receipts held cryptographically by both parties
- Resolve disputes with substrate-level evidence
- Handle recurring payments even when the delegation chain changes
- Support escrow and staged-release payments
- Handle cross-currency transactions
- Attribute revenue-share across composed workflows
- Attribute tax-jurisdiction responsibility for cross-border transactions

---

[← Tools](09-tools.md) &nbsp;·&nbsp; [README](README.md) &nbsp;·&nbsp; [Audit →](11-audit.md)
